# Summary of changes for run 43682f4c-5814-4751-a89a-5da497915cc1
## P50U — ultraweak topology and normality bridge (infrastructure only)

Created exactly one new file, `AristotleCandidates/UltraweakNormality.lean`. No other file was edited; P50's `normal` (WOT) field is untouched and retained as the stronger input certificate. `lake build AristotleCandidates.UltraweakNormality` succeeds; the file contains no `sorry`, `admit`, `axiom`, `opaque`, `unsafe`, or `implemented_by`, and the exported theorems depend only on `propext`, `Classical.choice`, `Quot.sound`.

### 1. Checked infrastructure developed in the packet

- `UltraweakCoeff H` — the coefficient data `x : ℕ → H`, `y : ℕ → (H →L[ℂ] ℂ)` with `Summable (fun n => ‖x n‖ * ‖y n‖)`.
- `UltraweakCoeff.summable_apply` — the series `∑ n, y n (T (x n))` converges absolutely for every bounded `T` (bound `‖y n‖·‖T‖·‖x n‖`).
- `UltraweakCoeff.eval` — its sum, with `eval_zero`, `eval_add`, `eval_smul` (linearity in `T`).
- `UltraweakCoeff.single x y` / `eval_single` — the one-term coefficient datum with `eval = y (T x)`.
- `UltraweakCoeff.scalarSeries` / `eval_scalarSeries` — a genuinely infinite absolutely summable coefficient datum, showing the family is not merely the finitely supported one.
- `UltraweakCLM H` — the type copy of `H →L[ℂ] H`, with `toUltraweak`, `UltraweakCLM.toCLM`, `toCLM_toUltraweak`, `toUltraweak_toCLM`, `toCLM_injective`, and the bijection `ultraweakEquiv`; conversion never changes the underlying operator.
- `UltraweakCLM.inducingFn` and `UltraweakCLM.instTopologicalSpace` — **the ultraweak topology**, defined as `TopologicalSpace.induced inducingFn Pi.topologicalSpace` where `inducingFn T c = c.eval T.toCLM` ranges over *all* absolutely summable matrix-coefficient series. It is not an alias for WOT, SOT or the norm topology.
- `UltraweakCLM.continuous_inducingFn`, `UltraweakCLM.continuous_eval` (each coefficient series is continuous by construction), `UltraweakCLM.continuous_of_forall_eval`.

### 2. The topology direction (declarations requested by the acceptance criteria)

- `UltraweakCLM.toWOT`, `UltraweakCLM.toWOT_apply`, `UltraweakCLM.toWOT_symm` — the identity map onto the WOT copy.
- **`UltraweakCLM.continuous_toWOT`** — continuity of the identity map from the ultraweak topology to WOT, proved via `ContinuousLinearMapWOT.continuous_of_dual_apply_continuous` by realizing each WOT generator `T ↦ y (T x)` as `UltraweakCoeff.single x y`.
- `IsUltraweaklyContinuous φ` — predicate on complex-linear functionals on `B(H)`: continuity of `fun T : UltraweakCLM H => φ T.toCLM`.
- **`IsUltraweaklyContinuous.of_wot`** — WOT-continuous ⇒ ultraweakly continuous; the term is literally `h.comp UltraweakCLM.continuous_toWOT`, so the topology comparison appears in the proof term.
- `cornerTau_ultraweakContinuous` — P50's compressed vector functional `tau_q` is ultraweakly continuous.

### 3. Theorem exported in the intended form

- `IsFaithfulUltraweakNormalTracialCorner` — same fields as P50's conclusion except that `normal_ultraweak` is *literally* `IsUltraweaklyContinuous (cornerTau q Ω).toLinearMap`; with `tracial_corner`, `faithful_corner` readings on `q M q`, and `of_isFaithfulNormalTracialCorner` converting any P50 conclusion.
- `ultraweak_normal_faithful_corner_trace` — the exported upgrade of `NormalFaithfulCornerTrace.normal_faithful_corner_trace`, with *exactly* the same P50 hypotheses (finite-codespace system `D`, decreasing projection tower, norm-closed represented algebra `A` between the finite stages and their closure, commuting complement `B`, dense-vector premise). No ultraweak-continuity or normality hypothesis is accepted as input.

### 4. Remaining gaps

- The comparison proved is one-directional (ultraweak ⇒ WOT continuity), which is all the normality upgrade needs; the converse and the identification of the ultraweak topology with a predual weak-* topology are not developed, and no predual is constructed.
- `UltraweakCLM H` carries only its topology and conversion bijection here; no topological-vector-space instances are installed on the copy.
- Plan-forbidden downstream claims are absent: no new traciality/faithfulness argument, no projection finiteness or fullness, no central type-III exclusion, no global trace or weight, no Lane-H statement.

Work is committed and pushed.
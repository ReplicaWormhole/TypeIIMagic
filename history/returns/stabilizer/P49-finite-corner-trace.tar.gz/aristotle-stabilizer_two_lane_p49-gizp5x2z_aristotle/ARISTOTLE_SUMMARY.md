# Summary of changes for run 77f02cc4-2096-4f34-a09d-47c9a693c2d6
## P49 — finite-stage trace and compressed quasi-local corner

Created exactly one new file, `AristotleCandidates/FiniteCornerTrace.lean` (739 lines). `lake build AristotleCandidates.FiniteCornerTrace` succeeds with **no errors, no warnings, no `sorry`/`admit`/`axiom`/`opaque`/`unsafe`/`implemented_by`**; every registered theorem depends only on `propext`, `Classical.choice`, `Quot.sound`. The rest of the project still builds.

### Plan alignment
Package `P49`, lane `G`. Source basis `main.tex:1196-1335` (with `1130-1195` for the finite-stage identities it quotes). Predecessors used: **P47** `CenterFiniteProjectionCore` and **P48** `GeneralLatticeProjectionTower`, both already integrated; also the existing finite density/trace modules (`FiniteDensityMatrix`, `DensityPartialTrace`, `OneQubitPartialTrace`) and the algebraic inductive-limit completion (`ConcreteQuasilocalCStarModel`). Forbidden downstream claims are **not** made anywhere: no normality, no faithfulness on a von Neumann corner, no fullness or finiteness of `q`, no global trace/weight on `M_Γ`, no type-III statement. Kaplansky density and the double commutant are not used; the tracial identity is proved on the *norm-closed* compressed quasi-local C\*-algebra only.

### Exact trace declarations
Checked infrastructure: `tauVec`, `compressL`, `cornerTau` (the compressed functional as a *continuous* linear functional, so the manuscript's "τ_q is bounded" step is structural), with `cornerTau_star_mul_self`/`cornerTau_nonneg` (positivity), `cornerTau_one` (normalization), `compressL_mem_corner` (the compression lands in P47's corner `qMq`), `eqOn_closure_prod`, and the P48-based `limitProj_apply_self`.

Theorems recovered in the manuscript's intended form (all conditional on the named premises below):
- `trace_density_sandwich_comm` — eq. `eq:local_traciality`, `Tr(ρ P a P b P) = Tr(ρ P b P a P)` for `ρ = c·P`;
- `stabilizerCodeDensity`, `trace_stabilizerCodeDensity`, `trace_groupAverage_eq`, `posSemidef_smul_of_isIdempotent` — the explicit finite codespace density `ρ = (|G|/dim)·P` with trace 1 and positivity;
- `FiniteCodespaceSystem.vector_state_stageProj` (`ω(P_n)=1`) and `FiniteCodespaceSystem.stageProj_apply_self` (`p_n Ω = Ω`, derived, not assumed), `inner_self_eq_one`/`norm_eq_one`;
- `FiniteCodespaceSystem.stage_cyclic` — finite-stage cyclicity (eqs. `eq:local_state` + `eq:local_traciality`);
- `CompatibleFiniteCodespaceSystem.trace_density_incl` — density compatibility `ρ_n = Tr_{Γ_{n+1}\Γ_n} ρ_{n+1}` in functional form; `range_pi_monotone`;
- `tendsto_tauVec_sandwich` and `cornerTau_cyclic_of_stage` — the strong-limit passage to `q` (Lemma `lem:finite-trace`);
- `CornerTracialOn`, `CornerTracialOn.closure` — Lemma `lem:cstar_trace` (norm-density extension);
- `cornerTracialOn_iUnion_range`, `cornerTracialOn_quasilocalCStarAlgebra` — traciality on the project's concrete quasi-local C\*-algebra;
- `CompatibleFiniteCodespaceSystem.cornerTracialOn_stage/_closure` and the packaged **`CompatibleFiniteCodespaceSystem.finite_corner_trace`**: τ_q is cyclic, normalized and positive on any operator set inside the norm closure of the finite-stage operators.
- `qubitPureMixedDensity_trace_succEmbedding` — the project's own explicit finite-stage densities satisfy the compatibility shape assumed by the structure.
- `sanityRep`, `sanitySystem`, `sanitySystem_isDecreasingProjTower` — a concrete model satisfying every field and the tower premise, so the conditional theorem is provably non-vacuous.

### Assumptions (all explicit Lean fields/premises, never axioms)
1. `FiniteCodespaceSystem`: stage star representations `π_n`; hermitian idempotent code projections `P_n`; densities `ρ_n = weight n · P_n`; `Tr ρ_n = 1`; the GNS vector-state identity `⟪Ω, π_n(x)Ω⟫ = Tr(ρ_n x)` (assumed, not constructed).
2. `CompatibleFiniteCodespaceSystem`: stage inclusions with `π_{n+1} ∘ incl_n = π_n`.
3. `IsDecreasingProjTower` for the stage projections (Lemma `lema:proj_inequality`), supplied as a premise since the density fields alone do not imply it.
4. For the C\*-level statement: the norm-density premise `S ⊆ closure (⋃ₙ range π_n)`.
Derived rather than assumed: `‖Ω‖ = 1`, `p_n Ω = Ω`, `q Ω = Ω`, positivity and normalization of τ_q.

### Deviation from the displayed proof
The manuscript passes to the limit using joint strong continuity of multiplication on bounded sets. Since `q Ω = Ω`, strong convergence `p_n → q` (already proved in P48) alone suffices; the easier route is used and the conclusion is unchanged.

### Remaining obstruction (open, not claimed)
Extending τ_q from the compressed quasi-local C\*-algebra to `q M_Γ q` needs Kaplansky density and normality, which the pinned Mathlib does not provide; that is P50's gate and is deliberately left untouched here.

The Properties table lists the definitions and the twelve proved theorems above with their statements and assumptions.
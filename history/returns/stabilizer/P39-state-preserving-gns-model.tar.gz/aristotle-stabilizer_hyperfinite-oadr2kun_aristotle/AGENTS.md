# Manuscript-Only Context Policy

## Source authority

For manuscript-facing statements, the sole mathematical source is
`sources/manuscript/main.tex`.
The local summary and locator record is `SOURCE-CONTRACT.md`. Do not modify
the manuscript from this project.

Every claim described as coming from the manuscript must identify an exact
line range in `main.tex`. Repository history, earlier chat context, and other
artifacts are not substitute sources.

## Context firewall

Do not introduce, assume, or attribute to the manuscript any gLU,
refinement, layer-coherence, or finite-coordinate construction unless it is
present in the cited manuscript lines or is explicitly introduced as a new
auxiliary assumption. A Lean file compiling does not make its unstated
physical or operator-algebraic hypotheses part of the manuscript.

Classify each item as one of:

1. **manuscript-derived**: exact source locator and no stronger conclusion;
2. **auxiliary assumption**: explicitly labelled and used only conditionally;
3. **Lean infrastructure**: reusable formal mathematics that makes no source
   claim; or
4. **legacy exploratory work**: retained for reference but unavailable as
   support for a manuscript-derived assertion.

`CONTEXT-LEDGER.md` records the current legacy items.

## Current formalization boundary

The target discussed in the manuscript is the short-range regional-algebra
statement at `main.tex:1740-1752`; its proposed proof is at
`main.tex:1891-2004`. Keep separate the asserted algebraic identification,
the product-state/GNS steps, the unformalized operator-algebraic completion and
spatial tensor-product steps, and the trace conclusion. A tracial state is
appropriate only for the finite pure-sector case. The infinite pure-sector
target instead calls for a faithful normal semifinite trace/weight when the
required hypotheses and von Neumann infrastructure are supplied.

## Aristotle task packets

Every new task under `aristotle_tasks/` must begin with exactly one context
declaration:

- `Source basis: main.tex:<line range>` for a manuscript-facing task; or
- `Infrastructure only:` for reusable Lean material that makes no manuscript
  claim.

It must then list every auxiliary assumption, state its exact Lean target, and
say whether its conclusion is conditional. A task may not cite a legacy
artifact as its source basis. Use `aristotle_tasks/TEMPLATE.md` for new
packets.

## Verification and reporting

Report Lean compilation separately from mathematical validation. For each
manuscript-facing milestone, state which source clauses are represented, which
assumptions remain external, and which analytic/von Neumann-algebraic claims
are not yet formalized in the pinned Mathlib version.

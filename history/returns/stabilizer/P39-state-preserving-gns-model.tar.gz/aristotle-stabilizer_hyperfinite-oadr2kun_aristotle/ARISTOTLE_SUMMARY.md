# Summary of changes for run dbe0fca4-1fdb-4e6e-8d48-9b8986a71827
## P39 — state-preserving C⋆ `alpha` and GNS transport

I created the single owned module `AristotleCandidates/StatePreservingGNSModel.lean`. `lake build AristotleCandidates.StatePreservingGNSModel` succeeds; the file contains no `sorry`/`admit`/`axiom`, and the exported results depend only on `propext`, `Classical.choice`, `Quot.sound`.

### 1. Checked infrastructure developed in the packet

* `RegionalConcreteCompletionData` — the bundle in which the **source** C⋆-completion is *constructed*, not assumed: it is the P38 concrete closed operator range `quasilocalCStarAlgebra rho rho_compat` of the representation of the algebraic source direct limit induced by the supplied compatible finite-stage representations, together with its canonical dense embedding. Proved from it: the extension formula on the whole algebraic limit (`alphaCStar_sourceEmbed`) and its inverse form, isometry/continuity and norm preservation of the supplied extension, uniqueness of the extension among continuous maps with the finite-stage formula, the quasilocality description of the concrete algebra as the closure of the union of the finite-stage operator ranges and as the least closed star-subalgebra with that property, conditional faithfulness of the concrete embedding, and the identification `(stageElem i x).val = rho i x`.
* `eq_of_stage_formulas` / `funext_of_stage_formulas` — **equality from dense finite-stage formulas**: continuous functionals (resp. continuous maps into the regional completion) agreeing on every concrete finite-stage operator `rho i x` are equal.
* `opStatePreserving` — a fully worked one-stage instance (constant system of bounded operators on ℂ, identity stage representations, spectral order, vector state at 1) showing the whole hypothesis bundle, including order structures and states, is simultaneously satisfiable, so nothing proved is vacuous.

### 2. Theorem recovered (conditional on explicit premises)

`StatePreservingData` adds the supplied regional/source states with the exact state-preservation identity `sourceState a = targetState (alphaCStar a)`. From it I proved: the **continuous state pullback** (`sourceState_eq_pullback`, `continuous_sourceState`); the **finite-stage formula** `sourceState (stageElem i x) = S.omega i (stageEquiv i x)` and its dense-limit form `sourceState ∘ sourceEmbed = pulledBackState`; uniqueness of the source state among continuous functionals with those values; and the **canonical GNS unitary** with inner-product/norm preservation, the intertwining formula along `alphaCStar` (and its inverse and finite-stage forms), the conjugation star-algebra equivalence, and transport of the algebraic centralizer and bicentralizer — all routed through the existing GNS bridge. `state_preserving_gns_package` collects these.

### 3. Exact unfinished geometric input (explicit hypotheses, listed in the module docstring)

* the finite adapted-coordinate data (local isotropic subspace `W_Γ = W ∩ V_Γ`, adapted symplectic basis `{z_i, x_i}`, and the resulting finite-stage star-equivalences with their coherence with the connecting maps) — supplied via the regional limit datum;
* the finite-stage operator representations `rho` on a supplied Hilbert space, their compatibility and (where used) injectivity;
* the regional C⋆-completion, its dense embedding, and the boundedness that lets `alpha` extend, i.e. `alphaCStar` with its finite-stage formula;
* the states: the positive unital continuous regional state, the source state, and the state-preservation identity; the manuscript's density-matrix formula enters only through the supplied finite-stage expectations.

### 4. Boundary respected

Nothing here constructs the manuscript's finite adapted-coordinate data, and no normality, von Neumann closure/bicommutant, quasi-equivalence, tensor-product decomposition, factor type, hyperfiniteness, trace or weight is asserted; the commutants are the purely algebraic centralizers. All work is committed and pushed.
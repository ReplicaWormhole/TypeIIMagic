# Plan: state-preserving C-star route to the regional factor theorem

## Objective

Formalize, from the manuscript's actual finite-support adapted-coordinate data,
a state-preserving C-star isomorphism from the quasi-local Pauli algebra to the
regional algebra.  Obtain the represented von Neumann algebra equivalence by
the canonical GNS unitary, then apply an independently established product
factor classification.

The source basis is exclusively `SOURCE-CONTRACT.md` and the cited manuscript
locators.  In particular, no gLU/refinement/layer-coherence premise is allowed
unless later added explicitly as a new auxiliary assumption.

## Current position

The project already has checked conditional interfaces for:

1. finite Pauli/stabilizer coordinates and pure/mixed states;
2. algebraic direct limits, their induced algebraic equivalence `alpha`, and
   compatible state transport;
3. supplied C-star completions and a supplied C-star extension of `alpha`;
4. GNS transport for supplied compatible C-star states; and
5. supplied normal/product-factor transport.

These are scaffolding.  They do not discharge the manuscript-specific finite
coordinate construction or the product-factor classification.

## Phase A — exact finite coordinate theorem

**Goal:** Replace abstract finite-stage star equivalences by maps constructed
from a finite restriction of the adapted symplectic basis.

1. Specify a finite region/exhaustion and the finite Pauli label spaces.
2. Define the coordinate map from the adapted `z_i,x_i` data.
3. Prove the Pauli multiplier and star equations, including the required phase
   correction.
4. Prove the map is a finite-stage complex star-algebra equivalence.
5. Prove its stabilizer membership criterion and the finite product-state
   expectation formula.

**Gate A:** no supplied finite-stage star equivalence remains in the finite
manuscript theorem; only explicitly stated finite adapted-coordinate data does.

## Phase B — coherence and quasi-local C-star isomorphism

**Goal:** Construct the actual C-star isomorphism `alpha`, rather than assume
an algebraic or completed extension.

1. Prove the Phase-A maps commute exactly with all finite-region inclusions.
2. Form the algebraic direct-limit star equivalence.
3. Specify the quasi-local C-star completions as inductive-limit completions.
4. Prove the algebraic map is isometric on the dense quasi-local subalgebras.
5. Extend it uniquely to a C-star star-algebra equivalence
   `alpha : P_quasilocal ≃⋆ₐ[ℂ] A_regional`.

**Gate B:** P23 and P25 are instantiated by proved data, not used as supplied
interfaces.

## Phase C — state identity and GNS transport

**Goal:** Prove the regional state pulled back by `alpha` is the pure/mixed
product state.

1. Check equality on finite Pauli-word bases using Phase A's stabilizer
criterion.
2. Prove compatibility under inclusions and hence equality on the quasi-local
C-star algebra by density/continuity.
3. Instantiate the existing C-star/GNS bridge to obtain the canonical GNS
unitary and its intertwining identity.
4. Use conjugation by that unitary to identify the represented von Neumann
algebras.

**Gate C:** do not use a separate quasi-equivalence/normal-folium argument.
It is unnecessary once the state-preserving C-star isomorphism is proved.

## Phase D — product representation classification

**Goal:** Independently prove or source the product-state representation
theorem.

1. Split coordinate indices into pure and mixed sectors.
2. Establish the infinite-product GNS factorization.
3. Identify the pure sector as `B(K_pure)`.
4. Identify the mixed sector as a finite matrix factor when finite, or the
hyperfinite `II_1` factor when infinite.
5. Establish the spatial tensor-product identification of the product
representation.

**Gate D:** every analytic theorem is either formalized against a supported
Mathlib API or recorded as an exact external theorem with source locator and
explicit hypothesis.

## Phase E — theorem and trace corollaries

1. Transport the Phase-D product classification through the Phase-C GNS
unitary to the regional von Neumann algebra.
2. State the finite-pure and infinite-pure cases separately.
3. Finite pure sector: derive the normalized tracial-state conclusion.
4. Infinite pure sector: state the faithful normal semifinite trace/weight
conclusion; do not call it a tracial state.
5. Audit every conclusion against `main.tex:1740-1752` and record any required
manuscript correction separately.

## Parallelization

Until Phase B is blocked on a single coherent-coordinate construction, run in
parallel:

- finite phase/cocycle verification;
- finite adapted-coordinate/stabilizer-state verification;
- finite inclusion/coherence lemmas;
- Mathlib/API feasibility audits for C-star inductive limits and GNS products;
- product mixed-sector classification/source work.

Do not parallelize mutually dependent attempts at the same global `alpha`.
Each new Aristotle packet must use `aristotle_tasks/TEMPLATE.md` and state its
source basis plus every auxiliary assumption.

## Exit criterion

Call the manuscript theorem formally established only when Gates A--D are
discharged and Phase E compiles without substituting supplied interfaces for
the central finite-coordinate, C-star-extension, state-identity, or
product-classification claims.

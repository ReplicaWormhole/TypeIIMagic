# Canonical manuscript context

The canonical manuscript entry point and its bibliography files are
included under `manuscript/`.
Read `manuscript/main.tex` for the canonical source text.
Read `AUTONOMY_POLICY.md` before beginning. The packet names a milestone,
but permits necessary local theory and a different proof route. Do not
silently strengthen claims or add unstated analytic hypotheses.

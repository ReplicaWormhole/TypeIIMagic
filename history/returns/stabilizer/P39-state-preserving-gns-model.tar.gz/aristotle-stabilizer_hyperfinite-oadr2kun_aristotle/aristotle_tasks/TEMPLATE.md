# P?? — concise task title

## Context declaration

Use exactly one of the following:

- **Source basis:** `main.tex:<start>-<end>`
- **Infrastructure only:** explain the reusable Lean component and state that
  no manuscript claim is being formalized.

## Mathematical target

State the exact theorem or definition in ordinary mathematics, then give the
exact Lean declaration to produce. Do not state a stronger result than the
cited source clause.

## Auxiliary assumptions

List every assumption not explicitly supplied by the source basis. Mark the
result conditional when this list is nonempty. In particular, list any
completion, star-isomorphism, product-GNS, normality, spatial tensor-product,
factor-type, or trace hypothesis.

## Files and imports

Specify files Aristotle may edit or create and the pinned imports it should
use. Do not alter existing unrelated artifacts.

## Acceptance criteria

- The declared Lean target compiles with the project toolchain.
- No `sorry`, `admit`, or new axiom is introduced.
- The response reports the exact command run and remaining mathematical
  assumptions.

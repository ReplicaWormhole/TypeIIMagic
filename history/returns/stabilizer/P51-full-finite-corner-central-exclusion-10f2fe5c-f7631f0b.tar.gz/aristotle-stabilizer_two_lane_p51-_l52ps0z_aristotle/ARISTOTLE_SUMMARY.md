# Summary of changes for run f7631f0b-1a3e-4192-9a2d-ecfe3f8c4419
## P51 — full finite corner and central type-III exclusion

I created exactly one new file, `AristotleCandidates/FullFiniteCornerCentralExclusion.lean`, importing P47 (`CenterFiniteProjectionCore`) and P50 (`NormalFaithfulCornerTrace`). `lake build AristotleCandidates.FullFiniteCornerCentralExclusion` succeeds; the file contains no `sorry`, `admit`, `axiom`, `opaque`, `unsafe`, or `implemented_by`, and every exported theorem depends only on `propext`, `Classical.choice`, `Quot.sound`.

### The theorem containing the nonzero finite projection `zq`

`AristotleCandidates.FullFiniteCornerCentralExclusion.central_summand_nonzero_finite_projection`

Given the P50 faithful normal tracial corner state `IsFaithfulNormalTracialCorner M q Ω`, fullness of `q`, and a nonzero central projection `z` of `M`, it concludes simultaneously:
`z * q ≠ 0`, `M.IsProjection (z * q)`, `ProjLe (z*q) z`, `ProjLe (z*q) q`, `M.IsFiniteProjection (z * q)`, `z * q ∈ centralSummand M z`, and `IsFiniteProjectionIn (centralSummand M z) (z * q)` — i.e. a nonzero projection that is finite both in `M` and relative to the summand `z M`.

### Classification of results

**(1) Checked infrastructure developed in the packet.** Set-relative comparison theory for a reduced algebra, since Mathlib's `VonNeumannAlgebra H` is necessarily unital on all of `H`: `centralSummand M z` (the summand as a set of operators), `MvNEquivIn`, `IsFiniteProjectionIn`, the project-local type-III obstruction predicate `IsTypeIIILike` (no nonzero finite projection), the monotonicity lemma `isFiniteProjectionIn_of_isFiniteProjection`, and the corner-membership lemma for partial isometries `mem_corner_of_mvNEquiv_projLe`.

**(2) Theorems recovered in the manuscript's intended form** (source basis `main.tex:1456-1536`):
- `isFiniteProjection_of_faithfulNormalTracialCorner` — Lemma `lem:finite_corner_finite_global`: a faithful tracial corner state forces `q` to be a finite projection of `M`. The manuscript argument is followed as written (`tau_q(vv*) = tau_q(v*v) = tau_q(q) = 1`, then faithfulness on the projection `q - vv*`).
- `isFull_of_dense_cyclic_vectors` — Proposition `prop:fullness`: `q` is full in `M = A''`.
- `central_summand_nonzero_finite_projection` and `not_isTypeIIILike_centralSummand` — Theorem `thm:finite_projections_exist` and its type-III exclusion form.
- `full_finite_corner_central_exclusion` — the exported form taking exactly the P50 input data and returning finiteness of `q`, fullness of `q`, and the per-summand conclusion.

**(3) Extra assumptions.** None beyond the P50 premises. Fullness uses only two of them, both manuscript clauses: `hB` (the complementary algebra commutes with `A`, eq. `eq:M-commutes-complement`) and `hdense` (the vectors `b a Ω` span a dense subspace, eq. `eq:dense_states`). No global trace or weight is assumed or manufactured; the only tracial datum is the P50 corner state. `sanity_full_finite_corner_central_exclusion` witnesses that the full hypothesis bundle is simultaneously satisfiable, so the exported theorem is not vacuous.

**(4) Open obstructions.** The reduced algebra `z M` is handled as a set of operators rather than as a von Neumann algebra on `z H`, because the pinned Mathlib has no reduced-algebra/cut-down construction for `VonNeumannAlgebra`; finiteness relative to `z M` is proved in the stronger form (finite in all of `M`, hence finite relative to `z M`).

### Plan alignment

Lane G, predecessors P47 and P50 only. No direct integral, no trivial-center claim, no global faithful normal semifinite weight, and no Lane-H tensor factorization appears anywhere in the file. The Lane-G requirement of a nonzero finite *projection* (not merely a finite-dimensional subalgebra) in every nonzero central summand is met.

All work is committed and pushed.
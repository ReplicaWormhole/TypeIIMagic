# Summary of changes for run 9cf226e6-e758-4671-af7e-ad76379c01ad
## P60R — standard positive-cone semifiniteness for the full-corner weight

Only `AristotleCandidates/FullCornerSemifiniteWeight.lean` was edited (imports unchanged: `Mathlib`, `AristotleCandidates.FullFiniteCornerCentralExclusion`, `AristotleCandidates.UltraweakNormality`). No manuscript, P51, or P50U file was touched, and no new axiom, `sorry`, `admit`, `opaque`, `unsafe`, or `implemented_by` was introduced.

### Commands run
- `lake build AristotleCandidates.FullCornerSemifiniteWeight` — passes (whole dependency chain, 8060 jobs).
- `rg "sorry|admit|axiom|opaque|unsafe|implemented_by"` on the file — no matches.
- `#print axioms` on the new and exported results — only `propext`, `Classical.choice`, `Quot.sound`.

### New checked infrastructure (§8b, all proved here)
- `posSqrt x = cfc Real.sqrt x` with `posSqrt_isSelfAdjoint`, `posSqrt_star`, `posSqrt_mul_self` (`x^{1/2} x^{1/2} = x` for positive `x`, via the pinned Mathlib continuous functional calculus and nonnegativity of the spectrum), `posSqrt_mem` (the square root lies in `M`, proved from the bicommutant characterisation plus commutation of the functional calculus), `posSqrt_ne_zero`.
- `compressedSub v N x = x^{1/2} p_N x^{1/2}` with `compressedSub_eq_star_mul_self` (`= (p_N x^{1/2})^* (p_N x^{1/2})`), `compressedSub_isPositive`, `compressedSub_mem`, `compressedSub_le` (order inequality `≤ x`, proved from `x - y_N = ((1-p_N)x^{1/2})^*((1-p_N)x^{1/2})`), `globalWeight_compressedSub_lt_top` (finite weight, derived from the existing tracial law and the finite compression `p_N x p_N`), `exists_compressedSub_ne_zero`, `eq_zero_of_partialProj_mul_eq_zero`.
- `globalWeight_faithful_positiveCone` and `globalWeight_mono_le` (monotonicity in the operator order).

### Theorem recovered in the intended form
`globalWeight_semifinite_positiveCone` states literally
`∀ x ∈ M, x.IsPositive → x ≠ 0 → ∃ y ∈ M, y.IsPositive ∧ y ≠ 0 ∧ y ≤ x ∧ globalWeight q Ω v y < ⊤`,
with `≤` the Mathlib operator (Loewner) order. This is standard semifiniteness, not a compression statement.

### Repaired exports
- The public domain is now `positiveCone M = {x | x ∈ M ∧ x.IsPositive}`; the extended weight is `ℝ≥0∞`-valued and is not presented as a linear functional on arbitrary operators.
- `IsGlobalFaithfulNormalSemifiniteTrace` is now a structure whose fields are exactly the proved laws on that cone: additivity, positive homogeneity, order monotonicity, traciality, faithfulness, normality (monotone-supremum law), corner restriction to the P50U corner trace, partial-sum values, standard `semifinite`, and the retained certificate.
- The old `globalWeight_semifinite` is retained under the honest name `globalWeight_finite_compressions` (both as a theorem and as the `finite_compressions` field), documented as a certificate that is not by itself standard semifiniteness.
- `full_corner_global_semifinite_weight` and `full_finite_corner_globalized_weight` now state only laws actually proved.

### Retained assumption and provenance
The results remain conditional on the explicit `ComparisonFamily` structure (partial isometries of `M`, source projections below `q`, pairwise orthogonal range projections with partial sums converging strongly to `1`, and `v 0` normalized to `q`) together with P50U's `IsFaithfulUltraweakNormalTracialCorner`. No claim is made that fullness alone yields the comparison family or a global weight; the σ-finite comparison theorem remains the open source obstruction, recorded in §9 and in the file header. No direct-integral, Lane-H factorization, or later-gate claim appears. The header now records the P51 provenance correction: P51 is accepted (`reviews/P51-full-finite-corner-central-exclusion-recovery.md`), so the earlier provenance objection is withdrawn, and this packet does not alter P51's no-central-type-III result.

All work is committed and pushed.
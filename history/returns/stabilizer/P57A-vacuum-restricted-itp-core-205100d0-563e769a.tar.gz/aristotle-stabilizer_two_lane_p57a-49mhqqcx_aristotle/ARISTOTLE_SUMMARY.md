# Summary of changes for run 563e769a-0e9b-4395-9895-e03c81c26851
## P57A — vacuum-restricted infinite-tensor pre-Hilbert core

Created exactly one new file, `AristotleCandidates/VacuumRestrictedInfiniteTensorProduct.lean` (no other project file was modified). `lake build AristotleCandidates.VacuumRestrictedInfiniteTensorProduct` succeeds with no warnings, the file contains no `sorry`, `admit`, `axiom`, `opaque`, `unsafe`, or `implemented_by`, and the exported results depend only on `propext`, `Classical.choice`, `Quot.sound`.

### Provenance (requested confirmation)

The packet nominated the external file `bound_beating/formalize_itp/Formalization/InfiniteTensorProductHilbert.lean` as a port source. **That path does not exist in this workspace**, so no code could be copied from it; the module was therefore developed from scratch against this repository's pinned Mathlib. It imports Mathlib only — no external project is imported or referenced in code — and none of the excluded wrappers (`VacuumRestrictedITPInnerProductAxioms`, `ITPCompletionAxioms`, `canonicalVacuumRestrictedITPInnerProductAxioms`) or any analogue appears. **No completed infinite tensor-product Hilbert space is claimed**; the development stops before any quotient or completion, and makes no GNS, spatial von Neumann tensor product, factor-classification, or manuscript-facing state claim. This is category (1), checked infrastructure.

### Contents (all proved)

Assumptions are exactly the generic ones allowed: `[DecidableEq ι]`, `NormedAddCommGroup (E i)` + `InnerProductSpace ℂ (E i)` for each mode, and the unit-vacuum hypothesis `⟪Ω i, Ω i⟫ = 1` where it is needed.

- `VacuumTensor Ω` — elementary tensors equal to `Ω i` outside a finite active set; `kern` — the finite-product kernel over the union of the active sets; `kern_eq_prod_of_subset` — the kernel is computed by the product over any finite mode set containing both active sets (uses the vacuum normalization); `conj_kern`.
- `ITPSpan Ω` — the algebraic finite span (free complex vector space on elementary tensors); `itpInner` — its sesquilinear extension, with support-independent evaluation lemmas (`itpInner_eq_sum₂`, `itpInner_eq_sum`, `itpInner_single`, `itpInner_eq_finiteMode`).
- **Finite-mode realization** (`exists_finiteMode_realization`, and its kernel form `exists_finiteMode_realization_kern`): every finite family of mode-vector families, relative to a finite mode set `s`, is realized by vectors in a finite tensor-product Hilbert space whose inner products are exactly the finite mode products `∏_{i∈s} ⟪u a i, u b i⟫`. This rests on a proved per-mode coordinate theorem (`exists_gram_coords`) obtained from an orthonormal basis of the finite-dimensional span.
- **Positivity on an arbitrary finite linear combination**: `sum_prod_inner_nonneg` and `itpInner_nonneg` (`0 ≤ itpInner x x` in the complex order, so reality is included), with `re_itpInner_nonneg` for the Mathlib core interface.
- Conjugate symmetry `conj_itpInner_symm`, additivity `itpInner_add_left`, scalar compatibility `itpInner_smul_left`.
- Exports: `itpCore : PreInnerProductSpace.Core ℂ (ITPSpan Ω)` and the algebraic vacuum `vacuumVector` with `itpInner_vacuumVector : itpInner Ω Ω = 1`.
- A small concrete instance (`ι = ℕ`, `E i = ℂ`, `Ω i = 1`) is included as a non-degeneracy check.

### Mathlib gaps encountered and how they were closed

The pinned Mathlib has an inner product space structure on the *binary* tensor product only; there is no inner product on `PiTensorProduct`, and no Schur/Hadamard positive-semidefiniteness theorem. Rather than postulate either, the finite tensor factor is realized concretely as `EuclideanSpace ℂ (∀ i : s, Fin (m i))` built from per-mode orthonormal coordinates, and positivity is derived from that realization as a genuine norm square. This is a proof-route substitution, not a weakening: both required theorems (finite-mode realization, positivity on a general finite linear combination) are explicit proved statements.

### Deviations from the packet text

One hypothesis was dropped as unnecessary: `itpInner_vacuumVector` holds without the normalization hypothesis, since the vacuum tensor has empty active set. The hypothesis remains where it is genuinely load-bearing (`kern_eq_prod_of_subset`, `itpInner_nonneg`, `itpCore`, `exists_finiteMode_realization_kern`). No hypothesis was added anywhere.

No forbidden downstream claim is made, and no predecessor package is used: the module is self-contained shared infrastructure, as required by its `Plan alignment` section.

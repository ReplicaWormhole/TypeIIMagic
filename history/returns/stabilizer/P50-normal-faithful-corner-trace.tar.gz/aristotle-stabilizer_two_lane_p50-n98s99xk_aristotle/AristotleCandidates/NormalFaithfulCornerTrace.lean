import Mathlib
import AristotleCandidates.FiniteCornerTrace
import AristotleCandidates.KaplanskyDensity

/-!
# P50 — the faithful normal tracial state on the von Neumann corner `q M_Γ q`

**Source basis:** `main.tex:1336-1455` (Proposition `prop:normal-trace` together with the
displayed net computation preceding it, and Proposition `prop:faithful`).

**Plan alignment.**  Package `P50`, lane `G`.  Predecessors used, both integrated and
locally audited: `P49` (`AristotleCandidates.FiniteCornerTrace`) for the compressed vector
functional `tau_q` and its cyclicity on the compressed quasi-local C⋆-algebra, and `P49C`
(`AristotleCandidates.KaplanskyDensity`) for bounded Kaplansky approximation, the compressed
corner approximants and the jointly indexed bounded product convergence.  Neither the
bicommutant theorem nor Kaplansky density appears here as an assumption: both are *proved*
upstream and are only *used*.

The gate discharged is exactly: extend `tau_q` from the compressed C⋆-algebra to the von
Neumann corner `q M_Γ q` and prove that it is a faithful normal finite **tracial state**
there.

**Forbidden downstream claims, made nowhere in this file.**  No fullness of `q`, no
statement about central summands, no global trace or weight on `M_Γ`, and no type-III
exclusion.  (Finiteness of `q`, which the manuscript deduces from this proposition, is a
`P51` matter and is not asserted here either.)

## Set-up

`M_Γ` is modelled as the bicommutant `A''` (`StarSubalgebra.vonNeumannGenerated`, from the
`P47`/bicommutant core) of a *norm-closed* unital star subalgebra `A ⊆ B(H)`, which is the
represented quasi-local C⋆-algebra `π_ω(𝒜_Γ)` of the manuscript.  All representation,
support, commutation, cyclicity and density premises are collected in two structures and
are listed in their docstrings; nothing is supplied as an axiom or as an unproved interface.

## Main results

* `CornerData.cornerTracialOn_vonNeumann` — **traciality on all of `q M_Γ q`** by bounded
  strong approximation (`main.tex:1290-1312`).
* `CornerData.tau_mul_comm` — the same statement for genuine corner elements.
* `CornerData.tau_apply`, `CornerData.tau_q`, `CornerData.tau_star_mul_self` — the
  vector-functional realization, normalization `tau_q(q) = 1` and positivity.
* `CornerData.tau_tendsto_of_wotTendsto` / `CornerData.tau_tendsto_of_stronglyTendsto` —
  **normality**: `tau_q` is continuous along weak-operator (hence σ-weakly, hence strongly)
  convergent nets, because it is the restriction of a vector functional.
* `FaithfulCornerData.faithful` — **faithfulness** by the manuscript's
  dense-vector/commuting-complement argument.
* `FaithfulCornerData.isFaithfulNormalTracialState` — the packaged conclusion, stated with
  the project-local predicate `IsFaithfulNormalTracialStateOnCorner`.

## Remaining non-analytic premises

They are precisely the fields of `CornerData` and `FaithfulCornerData`; see their
docstrings.  In particular, the *only* things assumed about the manuscript's concrete
situation are: the represented algebra is a norm-closed unital star subalgebra of `B(H)`;
`q` is a projection of `A''` fixing the unit vector `Ω`; `tau_q` is cyclic on the
compressions of `A` (this is the output of `P49`); the complementary algebra `B` commutes
with `A`; and the vectors `a b Ω` span a dense subspace of `H`.
-/

universe u v

namespace AristotleCandidates
namespace NormalFaithfulCornerTrace

open Filter Topology
open scoped InnerProductSpace
open AristotleCandidates.FiniteCornerTrace

variable {H : Type u} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]

/-! ## §1  The manuscript specialization data -/

/-- **The corner data of `main.tex:1336-1455`.**

* `A` is the represented quasi-local C⋆-algebra `π_ω(𝒜_Γ)`: a *norm-closed* unital star
  subalgebra of `B(H)`.  (Norm closedness is the C⋆-completion hypothesis; it is what
  `P49C`'s Kaplansky theorem needs.)
* `q` is the strong-limit code projection of `P48`, assumed self-adjoint, idempotent and an
  element of the von Neumann algebra `M_Γ = A''`.
* `Ω` is the GNS vector, a unit vector fixed by `q` (`main.tex` Lemma `lem:q_exists`).
* `cstar_tracial` is exactly the conclusion of `P49`: the compressed vector functional is
  cyclic on the compressions of the C⋆-algebra `A`.

No global trace, no normality and no faithfulness is assumed. -/
structure CornerData (H : Type u) [NormedAddCommGroup H] [InnerProductSpace ℂ H]
    [CompleteSpace H] where
  /-- The represented quasi-local C⋆-algebra `π_ω(𝒜_Γ)`. -/
  A : StarSubalgebra ℂ (H →L[ℂ] H)
  /-- It is norm closed, i.e. it really is a C⋆-algebra of operators. -/
  isClosed_A : IsClosed (A : Set (H →L[ℂ] H))
  /-- The limit code projection. -/
  q : H →L[ℂ] H
  /-- `q` is self-adjoint. -/
  isSelfAdjoint_q : IsSelfAdjoint q
  /-- `q` is idempotent. -/
  isIdempotent_q : q * q = q
  /-- `q` lies in `M_Γ = A''`. -/
  q_mem : q ∈ StarSubalgebra.vonNeumannGenerated A
  /-- The GNS vector. -/
  Ω : H
  /-- `q Ω = Ω`. -/
  q_apply_Ω : q Ω = Ω
  /-- `Ω` is a unit vector. -/
  inner_Ω : ⟪Ω, Ω⟫_ℂ = 1
  /-- **Output of `P49`**: cyclicity of `tau_q` on the compressed C⋆-algebra. -/
  cstar_tracial : CornerTracialOn q Ω (A : Set (H →L[ℂ] H))

namespace CornerData

variable (d : CornerData H)

/-- The von Neumann algebra `M_Γ = A''`. -/
noncomputable def M : VonNeumannAlgebra H := StarSubalgebra.vonNeumannGenerated d.A

/-- The von Neumann corner `q M_Γ q`, as the non-unital star subalgebra of `P47`. -/
noncomputable def corner : NonUnitalStarSubalgebra ℂ (H →L[ℂ] H) :=
  VonNeumannAlgebra.corner d.M d.isSelfAdjoint_q

/-- The compressed functional `tau_q(x) = ⟪Ω, q x q Ω⟫` of `P49`. -/
noncomputable def tau : (H →L[ℂ] H) →L[ℂ] ℂ := cornerTau d.q d.Ω

theorem mem_M_iff {x : H →L[ℂ] H} :
    x ∈ d.M ↔ x ∈ Set.centralizer (Set.centralizer (d.A : Set (H →L[ℂ] H))) := by
  constructor
  · intro hx
    have : x ∈ (StarSubalgebra.vonNeumannGenerated d.A : Set (H →L[ℂ] H)) := hx
    rwa [StarSubalgebra.coe_vonNeumannGenerated] at this
  · intro hx
    have : x ∈ (StarSubalgebra.vonNeumannGenerated d.A : Set (H →L[ℂ] H)) := by
      rwa [StarSubalgebra.coe_vonNeumannGenerated]
    exact this

theorem mem_M_of_mem_A {a : H →L[ℂ] H} (ha : a ∈ d.A) : a ∈ d.M :=
  StarSubalgebra.mem_vonNeumannGenerated_of_mem ha

theorem q_mem_M : d.q ∈ d.M := d.q_mem

theorem mem_corner_iff {x : H →L[ℂ] H} :
    x ∈ d.corner ↔ x ∈ d.M ∧ d.q * x = x ∧ x * d.q = x := Iff.rfl

theorem mem_M_of_mem_corner {x : H →L[ℂ] H} (hx : x ∈ d.corner) : x ∈ d.M := hx.1

/-- The compression `q x q` of an element of `M_Γ` lies in the corner. -/
theorem compress_mem_corner {x : H →L[ℂ] H} (hx : x ∈ d.M) : d.q * x * d.q ∈ d.corner :=
  VonNeumannAlgebra.mul_mul_mem_corner
    (M := d.M) (p := d.q) ⟨⟨d.isIdempotent_q, d.isSelfAdjoint_q⟩, d.q_mem⟩ hx

/-- `q` is the unit of its corner: `q x q = x` there. -/
theorem compress_eq_self {x : H →L[ℂ] H} (hx : x ∈ d.corner) : d.q * x * d.q = x := by
  rw [hx.2.1, hx.2.2]

theorem q_mem_corner : d.q ∈ d.corner :=
  ⟨d.q_mem, d.isIdempotent_q, d.isIdempotent_q⟩

/-! ## §2  The vector-functional realization, positivity and normalization -/

/-- **Vector-functional realization.**  Because `q Ω = Ω` and `q` is self-adjoint, the
compressed functional is *literally* the vector functional `x ↦ ⟪Ω, x Ω⟫`.  This is the fact
the manuscript uses for normality. -/
theorem tau_apply (x : H →L[ℂ] H) : d.tau x = ⟪d.Ω, x d.Ω⟫_ℂ := by
  have h : (d.q * x * d.q) d.Ω = d.q (x d.Ω) := by
    show d.q (x (d.q d.Ω)) = d.q (x d.Ω)
    rw [d.q_apply_Ω]
  show ⟪d.Ω, (d.q * x * d.q) d.Ω⟫_ℂ = _
  rw [h, ← ProjectionTower.inner_isSelfAdjoint d.isSelfAdjoint_q, d.q_apply_Ω]

/-- **Positivity.** -/
theorem tau_star_mul_self (x : H →L[ℂ] H) : d.tau (star x * x) = (‖x d.Ω‖ : ℂ) ^ 2 := by
  have h := cornerTau_star_mul_self d.isSelfAdjoint_q d.Ω x
  rw [d.q_apply_Ω] at h
  exact h

theorem tau_nonneg (x : H →L[ℂ] H) : 0 ≤ (d.tau (star x * x)).re := by
  rw [d.tau_star_mul_self]
  simp only [← Complex.ofReal_pow, Complex.ofReal_re]
  positivity

theorem tau_isReal (x : H →L[ℂ] H) : (d.tau (star x * x)).im = 0 := by
  rw [d.tau_star_mul_self]
  simp [pow_two, Complex.mul_im]

/-- **Normalization at the unit `q` of the corner**, `main.tex:1313-1316`. -/
theorem tau_q : d.tau d.q = 1 := by
  rw [d.tau_apply, d.q_apply_Ω, d.inner_Ω]

/-- Normalization at the ambient unit; the two agree since `q Ω = Ω`. -/
theorem tau_one : d.tau 1 = 1 := cornerTau_one d.q_apply_Ω d.inner_Ω

/-- `tau_q(x* x) = 0` forces `x Ω = 0`. -/
theorem apply_Ω_eq_zero {x : H →L[ℂ] H} (h : d.tau (star x * x) = 0) : x d.Ω = 0 := by
  have h' : ((‖x d.Ω‖ : ℂ)) ^ 2 = 0 := by rw [← d.tau_star_mul_self]; exact h
  have hc : (‖x d.Ω‖ : ℂ) = 0 := (pow_eq_zero_iff (n := 2) (by norm_num)).1 h'
  have hn : ‖x d.Ω‖ = 0 := by exact_mod_cast hc
  exact norm_eq_zero.1 hn

/-! ## §3  Traciality on the whole von Neumann corner

This is the manuscript's Proposition `prop:normal-trace`: bounded Kaplansky approximants for
`a, b ∈ M_Γ`, compressed and multiplied along the joint index, converge strongly, and the
vector functional is continuous at `Ω`. -/

/-- **Traciality on `q M_Γ q`** (`main.tex:1290-1312`).  For all `x, y ∈ M_Γ`,
`tau_q((q x q)(q y q)) = tau_q((q y q)(q x q))`. -/
theorem cornerTracialOn_vonNeumann :
    CornerTracialOn d.q d.Ω (d.M : Set (H →L[ℂ] H)) := by
  intro x hx y hy
  have hx' : x ∈ Set.centralizer (Set.centralizer (d.A : Set (H →L[ℂ] H))) :=
    d.mem_M_iff.1 hx
  have hy' : y ∈ Set.centralizer (Set.centralizer (d.A : Set (H →L[ℂ] H))) :=
    d.mem_M_iff.1 hy
  obtain ⟨l, hne, hc₁, hc₂⟩ :=
    KaplanskyDensity.exists_net_compression_product d.isClosed_A
      d.isSelfAdjoint_q.star_eq d.isIdempotent_q hx' hy'
  haveI := hne
  have hcont : Continuous fun z : H => ⟪d.Ω, z⟫_ℂ := (innerSL ℂ d.Ω).continuous
  have t₁ : Tendsto
      (fun p : {a : H →L[ℂ] H | a ∈ d.A ∧ ‖a‖ ≤ ‖x‖} ×
          {b : H →L[ℂ] H | b ∈ d.A ∧ ‖b‖ ≤ ‖y‖} =>
        tauVec d.Ω ((d.q * (p.1 : H →L[ℂ] H) * d.q) * (d.q * (p.2 : H →L[ℂ] H) * d.q))) l
      (𝓝 (tauVec d.Ω ((d.q * x * d.q) * (d.q * y * d.q)))) :=
    (hcont.tendsto _).comp (hc₁ d.Ω)
  have t₂ : Tendsto
      (fun p : {a : H →L[ℂ] H | a ∈ d.A ∧ ‖a‖ ≤ ‖x‖} ×
          {b : H →L[ℂ] H | b ∈ d.A ∧ ‖b‖ ≤ ‖y‖} =>
        tauVec d.Ω ((d.q * (p.2 : H →L[ℂ] H) * d.q) * (d.q * (p.1 : H →L[ℂ] H) * d.q))) l
      (𝓝 (tauVec d.Ω ((d.q * y * d.q) * (d.q * x * d.q)))) :=
    (hcont.tendsto _).comp (hc₂ d.Ω)
  have key : ∀ p : {a : H →L[ℂ] H | a ∈ d.A ∧ ‖a‖ ≤ ‖x‖} ×
      {b : H →L[ℂ] H | b ∈ d.A ∧ ‖b‖ ≤ ‖y‖},
      tauVec d.Ω ((d.q * (p.1 : H →L[ℂ] H) * d.q) * (d.q * (p.2 : H →L[ℂ] H) * d.q)) =
        tauVec d.Ω ((d.q * (p.2 : H →L[ℂ] H) * d.q) * (d.q * (p.1 : H →L[ℂ] H) * d.q)) :=
    fun p => d.cstar_tracial _ p.1.2.1 _ p.2.2.1
  exact tendsto_nhds_unique (t₁.congr key) t₂

/-- **Traciality in corner form.**  `tau_q(X Y) = tau_q(Y X)` for `X, Y ∈ q M_Γ q`. -/
theorem tau_mul_comm {X Y : H →L[ℂ] H} (hX : X ∈ d.corner) (hY : Y ∈ d.corner) :
    d.tau (X * Y) = d.tau (Y * X) := by
  have h := d.cornerTracialOn_vonNeumann X hX.1 Y hY.1
  rw [d.compress_eq_self hX, d.compress_eq_self hY] at h
  rw [d.tau_apply, d.tau_apply]
  exact h

/-! ## §4  Normality

`tau_q` is the restriction of a vector functional, hence continuous for the weak operator
topology — a fortiori σ-weakly continuous, i.e. normal — and in particular continuous along
strongly convergent nets. -/

/-- **Normality, weak-operator form.**  If a net converges to `x` in the weak operator
topology, then `tau_q` of the net converges to `tau_q x`.  This is strictly stronger than
σ-weak (normal) continuity. -/
theorem tau_tendsto_of_wotTendsto {ι : Type v} {l : Filter ι} {T : ι → H →L[ℂ] H}
    {x : H →L[ℂ] H}
    (h : Tendsto (fun i => ContinuousLinearMap.toWOT (RingHom.id ℂ) H H (T i)) l
      (𝓝 (ContinuousLinearMap.toWOT (RingHom.id ℂ) H H x))) :
    Tendsto (fun i => d.tau (T i)) l (𝓝 (d.tau x)) := by
  rw [ContinuousLinearMapWOT.tendsto_iff_forall_inner_apply_tendsto] at h
  simpa [d.tau_apply, ContinuousLinearMap.toWOT_apply] using h d.Ω d.Ω

/-- **Normality, strong form.**  `tau_q` is continuous along strongly convergent nets; this
is the form used to transport limits from the compressed C⋆-algebra. -/
theorem tau_tendsto_of_stronglyTendsto {ι : Type v} {l : Filter ι} {T : ι → H →L[ℂ] H}
    {x : H →L[ℂ] H} (h : StrongOperator.StronglyTendsto l T x) :
    Tendsto (fun i => d.tau (T i)) l (𝓝 (d.tau x)) := by
  simp only [d.tau_apply]
  exact ((innerSL ℂ d.Ω).continuous.tendsto _).comp (h d.Ω)

/-- **Normality, continuity form.**  `tau_q` is a weak-operator continuous functional. -/
theorem tau_continuous_wot :
    Continuous fun T : H →WOT[ℂ] H =>
      d.tau ((ContinuousLinearMap.toWOT (RingHom.id ℂ) H H).symm T) := by
  have h : Continuous fun T : H →WOT[ℂ] H =>
      (InnerProductSpace.toDual ℂ H d.Ω) (T d.Ω) :=
    ContinuousLinearMapWOT.continuous_dual_apply (σ := RingHom.id ℂ) (E := H) (F := H)
      d.Ω (InnerProductSpace.toDual ℂ H d.Ω)
  simpa [d.tau_apply, InnerProductSpace.toDual_apply_apply] using h

end CornerData

/-! ## §5  Faithfulness data and the faithfulness proof -/

/-- **The additional faithfulness premises of `main.tex:1355-1420`.**

* `B` is the represented complementary algebra `π_ω(𝒜_{Γᶜ})`.  The only thing assumed about
  it is that it commutes with `A` — this is the manuscript's
  `M_Γ = π_ω(𝒜_Γ)'' ⊆ π_ω(𝒜_{Γᶜ})'`.
* `dense_span` is the manuscript's density statement: the vectors `π_ω(a) π_ω(b) Ω`
  (`a ∈ 𝒜_Γ`, `b ∈ 𝒜_{Γᶜ}`) span a dense subspace of the GNS space.  This is the exact
  cyclicity-of-the-global-vector premise; no separating property is assumed. -/
structure FaithfulCornerData (H : Type u) [NormedAddCommGroup H] [InnerProductSpace ℂ H]
    [CompleteSpace H] extends CornerData H where
  /-- The represented complementary algebra `π_ω(𝒜_{Γᶜ})`. -/
  B : Set (H →L[ℂ] H)
  /-- It commutes with `A`. -/
  B_commutes : B ⊆ Set.centralizer (A : Set (H →L[ℂ] H))
  /-- The vectors `a b Ω` span a dense subspace. -/
  dense_span : Dense
    ((Submodule.span ℂ
      {ξ : H | ∃ a ∈ (A : Set (H →L[ℂ] H)), ∃ b ∈ B, ξ = a (b Ω)} : Submodule ℂ H) :
        Set H)

namespace FaithfulCornerData

variable (d : FaithfulCornerData H)

/-- Step 1 of `main.tex:1370-1392`: `tau_q(x* x) = 0` forces `x* Ω = 0` as well, by
traciality. -/
theorem star_apply_Ω_eq_zero {x : H →L[ℂ] H} (hx : x ∈ d.toCornerData.corner)
    (h : d.toCornerData.tau (star x * x) = 0) : (star x) d.Ω = 0 := by
  have hstar : star x ∈ d.toCornerData.corner := star_mem hx
  have h2 : d.toCornerData.tau (star (star x) * star x) = 0 := by
    rw [star_star]
    rw [d.toCornerData.tau_mul_comm hx hstar]
    exact h
  exact d.toCornerData.apply_Ω_eq_zero h2

/-- Step 2 of `main.tex:1370-1392`: `x y Ω = 0` for every `y` in the corner.  The
manuscript's square-root argument is replaced by the equivalent (and shorter) traciality
computation `‖x y Ω‖² = tau_q(x y y* x*) = ⟪x* Ω, y y* x* Ω⟫ = 0`. -/
theorem apply_corner_apply_Ω {x y : H →L[ℂ] H} (hx : x ∈ d.toCornerData.corner)
    (hy : y ∈ d.toCornerData.corner) (h : d.toCornerData.tau (star x * x) = 0) :
    x (y d.Ω) = 0 := by
  have hxy : x * y ∈ d.toCornerData.corner := mul_mem hx hy
  have hstarxy : star (x * y) ∈ d.toCornerData.corner := star_mem hxy
  have hstarx : (star x) d.Ω = 0 := d.star_apply_Ω_eq_zero hx h
  have hz : (star (x * y)) d.Ω = 0 := by
    rw [star_mul]
    show (star y) ((star x) d.Ω) = 0
    rw [hstarx, map_zero]
  have hcomm := d.toCornerData.tau_mul_comm hstarxy hxy
  have h0 : d.toCornerData.tau ((x * y) * star (x * y)) = 0 := by
    rw [d.toCornerData.tau_apply]
    show ⟪d.Ω, (x * y) ((star (x * y)) d.Ω)⟫_ℂ = 0
    rw [hz, map_zero, inner_zero_right]
  have h1 : d.toCornerData.tau (star (x * y) * (x * y)) = 0 := by
    rw [hcomm]; exact h0
  have := d.toCornerData.apply_Ω_eq_zero h1
  simpa using this

/-- Step 3 of `main.tex:1393-1400`: `x π_ω(a) Ω = 0` for `a ∈ A`. -/
theorem apply_A_apply_Ω {x a : H →L[ℂ] H} (hx : x ∈ d.toCornerData.corner) (ha : a ∈ d.A)
    (h : d.toCornerData.tau (star x * x) = 0) : x (a d.Ω) = 0 := by
  have haM : a ∈ d.toCornerData.M := d.toCornerData.mem_M_of_mem_A ha
  have hcomp : d.q * a * d.q ∈ d.toCornerData.corner := d.toCornerData.compress_mem_corner haM
  have h1 : x ((d.q * a * d.q) d.Ω) = 0 := d.apply_corner_apply_Ω hx hcomp h
  have h2 : (d.q * a * d.q) d.Ω = d.q (a d.Ω) := by
    show d.q (a (d.q d.Ω)) = d.q (a d.Ω)
    rw [d.q_apply_Ω]
  rw [h2] at h1
  have h3 : x (d.q (a d.Ω)) = (x * d.q) (a d.Ω) := rfl
  rw [h3, hx.2.2] at h1
  exact h1

/-- Step 4 of `main.tex:1401-1418`: `x` annihilates the dense set of vectors
`π_ω(a) π_ω(b) Ω`, using that `x ∈ M_Γ = A''` commutes with `B ⊆ A'`. -/
theorem apply_dense_vector {x a b : H →L[ℂ] H} (hx : x ∈ d.toCornerData.corner)
    (ha : a ∈ d.A) (hb : b ∈ d.B) (h : d.toCornerData.tau (star x * x) = 0) :
    x (a (b d.Ω)) = 0 := by
  have hbc : b ∈ Set.centralizer (d.A : Set (H →L[ℂ] H)) := d.B_commutes hb
  have hab : a * b = b * a := hbc a ha
  have hxb : b * x = x * b :=
    (d.toCornerData.mem_M_iff.1 hx.1) b hbc
  have hxa : x (a d.Ω) = 0 := d.apply_A_apply_Ω hx ha h
  have hmul : x * a * b = b * (x * a) := by
    calc x * a * b = x * (a * b) := by rw [mul_assoc]
      _ = x * (b * a) := by rw [hab]
      _ = (x * b) * a := by rw [mul_assoc]
      _ = (b * x) * a := by rw [hxb]
      _ = b * (x * a) := by rw [mul_assoc]
  have happ : (x * a * b) d.Ω = x (a (b d.Ω)) := rfl
  have happ2 : (b * (x * a)) d.Ω = b (x (a d.Ω)) := rfl
  rw [← happ, hmul, happ2, hxa, map_zero]

/-- **Proposition `prop:faithful`, `main.tex:1355-1420`.**  `tau_q` is faithful on
`q M_Γ q`. -/
theorem faithful {x : H →L[ℂ] H} (hx : x ∈ d.toCornerData.corner)
    (h : d.toCornerData.tau (star x * x) = 0) : x = 0 := by
  set S : Set H := {ξ : H | ∃ a ∈ (d.A : Set (H →L[ℂ] H)), ∃ b ∈ d.B, ξ = a (b d.Ω)} with hS
  have hvanish : S ⊆ (LinearMap.ker (x : H →ₗ[ℂ] H) : Set H) := by
    rintro ξ ⟨a, ha, b, hb, rfl⟩
    exact d.apply_dense_vector hx ha hb h
  have hspan : (Submodule.span ℂ S : Set H) ⊆ (LinearMap.ker (x : H →ₗ[ℂ] H) : Set H) := by
    have := Submodule.span_le.2 hvanish
    exact this
  have hclosed : IsClosed ((LinearMap.ker (x : H →ₗ[ℂ] H) : Submodule ℂ H) : Set H) :=
    x.isClosed_ker
  have huniv : (Set.univ : Set H) ⊆ (LinearMap.ker (x : H →ₗ[ℂ] H) : Set H) := by
    have hcl := closure_minimal hspan hclosed
    rw [d.dense_span.closure_eq] at hcl
    exact hcl
  ext ξ
  have : ξ ∈ (LinearMap.ker (x : H →ₗ[ℂ] H) : Set H) := huniv (Set.mem_univ ξ)
  simpa using this

/-- Faithfulness in its usual biconditional form on the corner. -/
theorem tau_star_mul_self_eq_zero_iff {x : H →L[ℂ] H} (hx : x ∈ d.toCornerData.corner) :
    d.toCornerData.tau (star x * x) = 0 ↔ x = 0 := by
  refine ⟨d.faithful hx, ?_⟩
  rintro rfl
  simp

end FaithfulCornerData

/-! ## §6  The packaged conclusion -/

/-- **Project-local definition** of a *faithful normal finite tracial state* on the corner
`p M p` of a concrete von Neumann algebra, with the corner's own unit `p` as the
normalization point.  Normality is stated in its strongest available form: continuity along
weak-operator convergent nets (which implies σ-weak continuity). -/
structure IsFaithfulNormalTracialStateOnCorner (M : VonNeumannAlgebra H) {p : H →L[ℂ] H}
    (hp : IsSelfAdjoint p) (φ : (H →L[ℂ] H) →L[ℂ] ℂ) : Prop where
  /-- Positivity on the corner. -/
  nonneg : ∀ x ∈ M.corner hp, 0 ≤ (φ (star x * x)).re
  /-- Values on positive elements are real. -/
  isReal : ∀ x ∈ M.corner hp, (φ (star x * x)).im = 0
  /-- Normalization at the unit `p` of the corner: it is a *state*, not merely a weight. -/
  normalized : φ p = 1
  /-- Traciality. -/
  tracial : ∀ x ∈ M.corner hp, ∀ y ∈ M.corner hp, φ (x * y) = φ (y * x)
  /-- Normality: weak-operator continuity along nets. -/
  normal : ∀ {ι : Type v} {l : Filter ι} {T : ι → H →L[ℂ] H} {x : H →L[ℂ] H},
    Tendsto (fun i => ContinuousLinearMap.toWOT (RingHom.id ℂ) H H (T i)) l
      (𝓝 (ContinuousLinearMap.toWOT (RingHom.id ℂ) H H x)) →
    Tendsto (fun i => φ (T i)) l (𝓝 (φ x))
  /-- Faithfulness. -/
  faithful : ∀ x ∈ M.corner hp, φ (star x * x) = 0 → x = 0

/-- **P50, main theorem (`main.tex:1336-1455`).**

Under the explicit manuscript specialization data — a norm-closed represented quasi-local
C⋆-algebra `A`, the projection `q ∈ M_Γ = A''` fixing the unit GNS vector `Ω`, cyclicity of
`tau_q` on the compressions of `A` (the output of `P49`), a complementary algebra `B`
commuting with `A`, and density of the span of the vectors `a b Ω` — the compressed vector
functional `tau_q(x) = ⟪Ω, q x q Ω⟫` is a **faithful normal finite tracial state** on the von
Neumann corner `q M_Γ q`.

No fullness, finiteness of `q`, central-summand statement, global trace/weight, or type-III
exclusion is claimed. -/
theorem FaithfulCornerData.isFaithfulNormalTracialState (d : FaithfulCornerData H) :
    IsFaithfulNormalTracialStateOnCorner d.toCornerData.M d.isSelfAdjoint_q
      d.toCornerData.tau where
  nonneg := fun x _ => d.toCornerData.tau_nonneg x
  isReal := fun x _ => d.toCornerData.tau_isReal x
  normalized := d.toCornerData.tau_q
  tracial := fun _ hx _ hy => d.toCornerData.tau_mul_comm hx hy
  normal := fun h => d.toCornerData.tau_tendsto_of_wotTendsto h
  faithful := fun _ hx h => d.faithful hx h

/-! ## §7  Non-vacuity: the hypotheses are simultaneously satisfiable

The two structures bundle a representation, a projection, a unit vector, a C⋆-level
cyclicity statement, a commutation premise and a density premise.  The following
one-dimensional model instantiates all of them, so the packaged theorem is not vacuous.  It
carries no manuscript content. -/

section Sanity

/-- Operators on `ℂ` commute. -/
theorem clm_complex_comm (f g : ℂ →L[ℂ] ℂ) : f * g = g * f := by
  have hlin : ∀ (h : ℂ →L[ℂ] ℂ) (w : ℂ), h w = w * h 1 := by
    intro h w
    have := h.map_smul w (1 : ℂ)
    simpa [smul_eq_mul] using this
  refine ContinuousLinearMap.ext fun z => ?_
  show f (g z) = g (f z)
  rw [hlin f (g z), hlin g z, hlin g (f z), hlin f z]
  ring

/-- The one-dimensional witness for `CornerData`. -/
noncomputable def sanityCornerData : CornerData ℂ where
  A := ⊤
  isClosed_A := by
    have : ((⊤ : StarSubalgebra ℂ (ℂ →L[ℂ] ℂ)) : Set (ℂ →L[ℂ] ℂ)) = Set.univ := by
      ext x; simp
    rw [this]
    exact isClosed_univ
  q := 1
  isSelfAdjoint_q := IsSelfAdjoint.one _
  isIdempotent_q := by simp
  q_mem := one_mem (StarSubalgebra.vonNeumannGenerated (⊤ : StarSubalgebra ℂ (ℂ →L[ℂ] ℂ)))
  Ω := 1
  q_apply_Ω := rfl
  inner_Ω := by simp
  cstar_tracial := by
    intro a _ b _
    have h : (1 * a * 1) * (1 * b * 1) = (1 * b * 1) * (1 * a * 1) := by
      simp only [one_mul, mul_one]
      exact clm_complex_comm a b
    rw [h]

/-- The one-dimensional witness for `FaithfulCornerData`. -/
noncomputable def sanityFaithfulCornerData : FaithfulCornerData ℂ where
  toCornerData := sanityCornerData
  B := {1}
  B_commutes := by
    intro b hb
    rw [Set.mem_singleton_iff] at hb
    subst hb
    intro m _
    simp
  dense_span := by
    have hmem : ∀ z : ℂ, z ∈
        ((Submodule.span ℂ
          {ξ : ℂ | ∃ a ∈ (sanityCornerData.A : Set (ℂ →L[ℂ] ℂ)),
            ∃ b ∈ ({1} : Set (ℂ →L[ℂ] ℂ)), ξ = a (b sanityCornerData.Ω)} :
            Submodule ℂ ℂ) : Set ℂ) := by
      intro z
      refine Submodule.subset_span ⟨z • (1 : ℂ →L[ℂ] ℂ), ?_, 1, rfl, ?_⟩
      · show z • (1 : ℂ →L[ℂ] ℂ) ∈ ((⊤ : StarSubalgebra ℂ (ℂ →L[ℂ] ℂ)) : Set (ℂ →L[ℂ] ℂ))
        simp
      · show z = (z • (1 : ℂ →L[ℂ] ℂ)) ((1 : ℂ →L[ℂ] ℂ) (1 : ℂ))
        simp
    rw [Set.eq_univ_of_forall hmem]
    exact dense_univ

end Sanity

end NormalFaithfulCornerTrace
end AristotleCandidates

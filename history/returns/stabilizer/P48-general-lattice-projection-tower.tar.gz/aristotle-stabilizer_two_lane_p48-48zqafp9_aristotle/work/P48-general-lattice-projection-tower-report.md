# P48 report — general-lattice local-code projection tower

Module: `AristotleCandidates/GeneralLatticeProjectionTower.lean` (only file created).

- **Source basis:** `main.tex:1026-1195`.
- **Package/lane:** `P48`, lane `G`. Predecessors: none.
- **Build:** `lake build AristotleCandidates.GeneralLatticeProjectionTower` succeeds
  with no errors and no linter warnings.
- **Soundness:** no `sorry`, `admit`, `axiom`, `opaque`, `unsafe`, or
  `implemented_by`. Every checked theorem reports only
  `propext, Classical.choice, Quot.sound`.
- **Imports:** `Mathlib`, `AristotleCandidates.FiniteStabilizerProjector`,
  `AristotleCandidates.BicommutantVonNeumannCore`. No P47–P61 packet is imported.

## The declaration representing `q`

Abstract (any decreasing tower of star projections on a complex Hilbert space):

```lean
AristotleCandidates.ProjectionTower.limitProj
  {H} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]
  (p : ℕ → H →L[ℂ] H) : H →L[ℂ] H
:= (limitSpace p).starProjection
```

where `limitSpace p = ⨅ n, fixedSpace (p n)` and
`fixedSpace a = LinearMap.ker (a - 1)`.

Lattice-level (the manuscript's `q`):

```lean
AristotleCandidates.LocalCode.latticeLimitProj
  {L S} [Group S] {H} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]
  (E : LatticeExhaustion L) (ss : SupportSystem L S) (U : S →* (H →L[ℂ] H))
  [∀ n, Fintype (stageSubgroup E ss n)] : H →L[ℂ] H
:= limitCodeProj U (stageSubgroup E ss)
```

with the stage projections

```lean
AristotleCandidates.LocalCode.latticeCodeProj E ss U n
  = groupAverage (U.comp (stageSubgroup E ss n).subtype)
  = (Fintype.card (stageSubgroup E ss n) : ℂ)⁻¹ • ∑ g, U ↑g
```

## The convergence premise

**There is none.** The monotone strong limit is *proved* in the pinned library,
not assumed:

```lean
AristotleCandidates.ProjectionTower.IsDecreasingProjTower.tendsto_limitProj
  (hp : IsDecreasingProjTower p) (x : H) :
  Filter.Tendsto (fun n => p n x) Filter.atTop (nhds (limitProj p x))
```

and its lattice form `AristotleCandidates.LocalCode.tendsto_latticeLimitProj`.
Consequently no analytic step is isolated as a named structure field; the packet's
fallback clause was not needed.

The proof is elementary and self-contained: `‖pₙ x‖²` is antitone and bounded
below, `‖pₙ x − pₘ x‖² = ‖pₙ x‖² − ‖pₘ x‖²` for `n ≤ m`, hence `(pₙ x)` is Cauchy;
its limit lies in every closed fixed space and is orthogonal to `x` minus itself,
so it equals `q x`.

## Full list of hypotheses (all explicit, none hidden)

1. `LatticeExhaustion L`: `region`, `stage : ℕ → Set L`, `stage_finite`,
   `stage_mono`, `stage_subset`, `stage_exhausts`.
2. `SupportSystem L S`: `supp : S → Set L`, `supp_one`, `supp_mul`, `supp_inv`.
3. `[∀ n, Fintype (stageSubgroup E ss n)]` — **local finiteness** of the stabilizer
   constraints in a finite stage. This is the one genuinely extra assumption
   relative to the cited manuscript lines; the manuscript uses it implicitly when
   it forms the finite local code projection `P_{Γₙ}`.
4. `U : S →* (H →L[ℂ] H)` with `hU : ∀ g, star (U g) = U g⁻¹` — unitary
   representation of the stabilizer group on the (GNS) Hilbert space.
5. For `q ∈ M`: `∀ n, latticeCodeProj E ss U n ∈ M` for a concrete
   `M : VonNeumannAlgebra H`.
6. For `q Ω = Ω`: `Ω` is invariant under every stabilizer element supported in
   some stage.

All manuscript-facing conclusions are conditional on 1–6.

## Results recovered

| Manuscript item | Lean declaration |
|---|---|
| exhaustion `Γ₁ ⊆ Γ₂ ⊆ ⋯`, `Γ = ⋃ Γₙ` (1033-1036) | `LocalCode.LatticeExhaustion`, `LatticeExhaustion.iUnion_stage` |
| local projections `Pₙ`, `pₙ = π_ω(Pₙ)` (1044-1048) | `LocalCode.latticeCodeProj` |
| Lemma `lema:proj_inequality`, `pₙ ≥ pₙ₊₁` (1049-1057) | `LocalCode.latticeCodeProj_mul_of_le`, `LocalCode.latticeCodeProj_sub_isPositive` |
| Lemma `lem:q_exists`, strong limit `q` (1140-1155) | `LocalCode.latticeLimitProj`, `LocalCode.tendsto_latticeLimitProj` |
| `q ∈ M_Γ` (1156-1161) | `LocalCode.latticeLimitProj_mem_vonNeumannAlgebra` |
| `q Ω = Ω` (1161-1180) | `LocalCode.latticeLimitProj_apply_of_invariant` |

## Deviations from the displayed proof

* The manuscript proves `pₙ ≥ pₙ₊₁` from a partial-trace support-projection lemma
  for finite-dimensional tensor factors. That route presupposes tensor-factor
  coordinates, which this lane forbids. The same inequality is instead derived
  algebraically from `Gₙ ≤ Gₘ`, i.e. from the fact that a larger finite stage sees
  more stabilizer constraints, so its group average is a smaller projection.
* The manuscript places `q ∈ M_Γ` by strong closedness of `M_Γ` via the bicommutant
  theorem. The pinned Mathlib has no double commutant theorem. It is not needed:
  `q ∈ M` follows because a commutant is strongly closed and `M = (M')'` holds by
  definition for a concrete `VonNeumannAlgebra`.

## Forbidden downstream claims — not made

No trace on the corner `q M_Γ q`, no faithfulness or normality, no finiteness of
`q`, no fullness, no global weight, no factor or type-III statement appears in the
module. Nothing from Lane H (hyperbolic basis, tensor-factor coordinates) is used.

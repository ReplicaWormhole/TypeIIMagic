# Canonical manuscript context

The canonical manuscript entry point and its bibliography files are
included under `manuscript/`.
Read `manuscript/main.tex` for the canonical source text.
Read `AUTONOMY_POLICY.md`, `AGENTS.md`, `PLAN.md`, and
`work/TWO-LANE-FORMALIZATION-DECISION.md` before beginning. Verify the
packet's lane, predecessors, permitted gate, and forbidden downstream
claims against those files. The packet names a milestone,
but permits necessary local theory and a different proof route. Do not
silently strengthen claims or add unstated analytic hypotheses.

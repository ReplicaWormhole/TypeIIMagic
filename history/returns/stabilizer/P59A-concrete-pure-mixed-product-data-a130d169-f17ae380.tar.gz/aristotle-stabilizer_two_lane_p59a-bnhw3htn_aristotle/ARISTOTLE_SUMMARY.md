# Summary of changes for run f17ae380-7cbe-4e16-8ea3-94d98cb8ef47
Packet P59A is complete. `lake build AristotleCandidates.ConcretePureMixedProductData` succeeds with no `sorry`, `admit`, `axiom`, `opaque`, `unsafe`, or `implemented_by`; `#print axioms` on the exported declarations reports only `propext`, `Classical.choice`, `Quot.sound`. All work is committed and pushed. Only the single new file `AristotleCandidates/ConcretePureMixedProductData.lean` was created; P55D, P56R, P57, P58, the manuscript, and the other candidates were left untouched.

**1. Checked infrastructure developed in the packet**
- A pure/mixed *label calculus* on coordinate Pauli labels (`IsPureLabel` / `IsMixedLabel`, closed under `0` and `+`) for the selected coordinate set `A.family.selected` and its complement, with classical decidability used only locally for the partition.
- Exact vanishing lemmas for the Z/X coordinate pairing between a word supported on selected coordinates and one supported on unselected coordinates, plus additivity of the coordinate expectation (`productExpectation_add`).
- A generic coordinate C*-subalgebra API (`labelWordSet`, `labelSpanAlg`, `labelCStarAlg`, and a subset criterion for closed sets) parametrized by a label predicate, which is what both factors are instantiated from.
- A cone lemma `nonneg_of_starSq` and the conversion `positiveOfStarSq` from "nonnegative on all `star s * s`" to Mathlib's `PositiveLinearMap`, proved against the pinned concrete C*-order.

**2. The P59A gate, recovered in its intended form**
- `pureCStar` and `mixedCStar`: the two concrete coordinate quasi-local C*-algebras inside the P55D concrete source C*-algebra, with their unital star-homomorphic embeddings.
- `pureCStar_mixedCStar_commute`: the two images commute elementwise (generators → closed complex submodule → closure).
- `dense_productSpan`: the complex span of elementary products is norm dense in the source C*-algebra.
- The two marginal product functionals, with positivity, unitality and contractivity (`norm_totalStateCLM_le` and the marginal counterparts).
- `totalStateCLM_mul`: P56R's recovered source state factorizes as the product of its two marginals on every elementary product.
- `concreteProductGNSData`: the exported `ProductGNSTensor.ProductGNSData`, built entirely from the local model — every field (commutation, density, product, positivity, norm bound) is proved, and the definition takes **no** additional assumption or premise argument. A branch-uniform variant `AlphaData.concreteProductGNSData` depending only on the coordinate data is also exported.
- Identification lemmas pin the datum's total algebra to the P55D concrete source C*-algebra and its total state to P56R's `cstarProductStateRecovered` / recovered regional state transported through the P55D concrete `alpha`.

**3. Conditional theorems** — none. No result in the file carries an extra hypothesis beyond the existing P52/P53/P55D coordinate-model assumptions inherited through `AlphaData` and `SourceConcreteRep`. No tensor-product, state, density, factor, weak-closure, normality, trace, or weight premise is supplied, and no forbidden downstream claim (completed infinite tensor product, factor classification, regional factor theorem, trace/weight) is stated.

**4. Obstruction noted** — Mathlib does not register the C*-algebra order as a global instance on a `StarSubalgebra`/closed-range subtype, so the `PartialOrder` and `StarOrderedRing` structures of the three algebras are pinned explicitly to `CStarAlgebra.spectralOrder` / `spectralOrderedRing` inside the datum, and the `IsAlgebraicState`-to-`PositiveLinearMap` conversion is proved against exactly that pinned order. This is a packaging gap in the library, not a mathematical one.

The Properties table has been reconciled: the four theorems (commutation, dense product span, state factorization, total-state identification) are marked proved; the five definitions (pure factor, mixed factor, positivity conversion, and the two exported datums) remain definitions.
# Summary of changes for run 2e89017e-ccab-47c2-bd66-ca42164fd972
## P55A — finite-stage local-hyperbolic Pauli-to-dyadic bridge: complete

Created exactly one new file, `AristotleCandidates/LocalHyperbolicFiniteStageUHFBridge.lean` (≈990 lines). No predecessor module was edited (the whole branch diff touches only this file). The file header carries the "infrastructure only" context declaration and the Plan-alignment section.

### Verification command (exact)

```
lake build AristotleCandidates.LocalHyperbolicFiniteStageUHFBridge
```

Result: `Build completed successfully (8050 jobs)`, with **zero errors and zero warnings**. A grep over the file finds no `sorry`, `admit`, `axiom`, `opaque`, `unsafe`, or `implemented_by`. `#print axioms` on `sourceStageUHFEquiv`, `sourceStageUHFEquiv_zGenerator`, `sourceStageUHFEquiv_xGenerator`, `sourceStageUHFEquiv_bijective`, and `norm_sourceStageUHFEquiv` reports only `[propext, Classical.choice, Quot.sound]`.

### 1. Checked infrastructure developed in this packet

* **Register matrix model.** `Reg ι := ι → PauliBit`, `regPairing a b = ∑ i, a i * b i`, and the standard word
  `stdWord a b r c = if r = a + c then pauliSign (regPairing b c) else 0`, with proved multiplication `stdWord a b * stdWord a' b' = pauliSign (regPairing b a') • stdWord (a+a') (b+b')`, involution `star (stdWord a b) = pauliSign (regPairing a b) • stdWord a b`, character orthogonality, trace formula, linear independence, and the basis `stdWordBasis` (dimension count via `Module.finrank_matrix`).
* **Matrix star-equivalence toolkit:** `matrixMapStarEquiv`, `matrixReindexStarEquiv`, `matrixCompStarEquiv`, `scalarMatrixStarEquiv`.
* **Identification of the dyadic stage.** `qubitMatrixEquiv k : QubitTensorPower k ≃⋆ₐ[ℂ] Matrix (Reg (Fin k)) (Reg (Fin k)) ℂ`, defined by recursion on the recursive `QubitTensorPower` model (this is the "equivalent indexing of the dyadic matrix stage" the packet permits, constructed and proved here, not assumed).
* **Standard X/Z words defined recursively inside `QubitTensorPower`** (`qubitX`, `qubitZ`, `qubitWord k a b := qubitX k a * qubitZ k b`), with proved register-model images `qubitX ↦ stdWord a 0`, `qubitZ ↦ stdWord 0 b`, `qubitWord ↦ stdWord a b`, plus `qubitX_mul`, `qubitZ_mul`, commutation, and star formulas.
* **AlphaData layer:** exponent-coordinate decomposition `sourceForm_eq : (A.sourceForm n).form v w = regPairing (zPart v) (xPart w)`, the enumerated coordinate isomorphism `enumRepr`, and the basis-transport equivalence `sourceStageMatrixEquiv` built from P53's `pauliWordBasis` and `stdWordBasis`.
* **Norms:** a local finite-dimensional C⋆-structure on the coordinate Pauli algebra, `norm_starAlgEquiv` (star equivalences of C⋆-algebras are isometric), and the dyadic-stage norm `qubitOpNorm k x := ‖qubitMatrixEquiv k x‖` with proved positivity/definiteness, unit, submultiplicativity, triangle, star invariance, and the C⋆ identity.

### 2. Results in the packet's intended form

* `A.sourceStageUHFEquiv n e : pauliAlgebra (A.sourceForm n) ≃⋆ₐ[ℂ] QubitTensorPower k`, built as `(A.sourceStageMatrixEquiv n e).trans (qubitMatrixEquiv k).symm` from the explicit P53 Pauli-word basis and the explicit enumeration parameter `e : A.Coord n ≃ Fin k`. It is **not** a structure field.
* Default specialization `A.sourceStageUHFEquivDefault n` at `k = Nat.card (A.Coord n)`, using the constructed enumeration `A.coordEnumeration n := Finite.equivFin _`, with both generator corollaries.
* `sourceStageUHFEquiv_map_mul`, `sourceStageUHFEquiv_map_star`, `sourceStageUHFEquiv_bijective`.
* `norm_sourceStageUHFEquiv`, `norm_sourceStageMatrixEquiv`, `norm_sourceStageMatrixEquiv_sub`, `isometry_sourceStageMatrixEquiv`.

### Exact generator formulas and convention-dependent phases

Word formula (no extra phase):

```
A.sourceStageUHFEquiv n e (pauliWord (A.sourceForm n) v)
  = qubitWord k (A.enumRepr n e v).1 (A.enumRepr n e v).2
```

Generators:

```
A.sourceStageUHFEquiv n e (pauliWord (A.sourceForm n) ((A.stageCoordinates n).z i)) = qubitZ k (Pi.single (e i) 1)
A.sourceStageUHFEquiv n e (pauliWord (A.sourceForm n) ((A.stageCoordinates n).x i)) = qubitX k (Pi.single (e i) 1)
```

so **both convention-dependent fourth-root phases are trivial (`i^0 = 1`)**. This is not an accident but a proved consequence of matching conventions: P53's coordinate pairing `(coordPairing I).form v w = ∑ i, v (inl i) * w (inr i)` is the Z-part/X-part pairing, i.e. the **ordered `X^a Z^b` convention with X on the left**, and `qubitWord k a b` is defined with the same ordering. The phases that are non-trivial in general, and are exposed and proved rather than hidden, are:

* multiplication: `qubitX a * qubitZ b * (qubitX a' * qubitZ b') = pauliSign (regPairing b a') • qubitWord (a+a') (b+b')`, i.e. sign `(-1)^{b·a'}`;
* commutation: `qubitZ k b * qubitX k a = pauliSign (regPairing b a) • qubitWord k a b`;
* involution: `star (qubitWord k a b) = pauliSign (regPairing a b) • qubitWord k a b`, i.e. sign `(-1)^{a·b}`;
* fourth root: `star (zmodFourPhase (liftPauliBit (regPairing a b)) • qubitWord k a b) = zmodFourPhase (liftPauliBit (regPairing a b)) • qubitWord k a b`, i.e. `i^{a·b} X^a Z^b` is exactly the self-adjoint normalization;
* tensor convention: in the recursive model, qubit `0` is the **outer** matrix factor; this is fixed by `regSuccEquiv k : Fin 2 × Reg (Fin k) ≃ Reg (Fin (k+1))` (from `Fin.consEquiv`) and enters `qubitMatrixEquiv` explicitly. It introduces no permutation or phase in the generator formulas because the recursive X/Z words are defined with the same ordering.

### 3. Remaining assumptions

* P53's `AlphaData` hypotheses (its symplectic coordinate structure and finite-stage data) are inherited unchanged; nothing new was assumed about them.
* Classical choice is used only as constructed data: `Fintype`/`DecidableEq` on `A.Coord n`, and the default enumeration `Finite.equivFin`. Every use is a constructed term, never a hypothesis.
* No finite-stage star equivalence, norm equality, word basis, or matrix-unit identification was assumed; each is constructed and proved in the file.
* The dyadic-stage norm is *defined* through the constructed register matrix model, because `QubitTensorPower k` carries only `Semiring`/`StarRing`/`Algebra ℂ`/`StarModule ℂ` instances and no norm. For the same reason the distance form of the isometry is stated in the register matrix model (`norm_sourceStageMatrixEquiv_sub`): the recursive model has no subtraction.

### 4. Obstructions

None outstanding for this gate.

### Scope discipline

No direct-limit equivalence, C⋆ completion, regional alpha, state identity, GNS tensor split, factor classification, or trace/weight statement appears anywhere in the file. Lane G is untouched. All work is committed and pushed.
# Summary of changes for run 4c191796-3bda-41a9-adb7-2453624762fa
## P52 — coherent local-hyperbolic coordinates (Lane H, no predecessors)

Created exactly one new file, `AristotleCandidates/CoherentLocalHyperbolicCoordinates.lean`. `lake build AristotleCandidates.CoherentLocalHyperbolicCoordinates` succeeds; the file contains no `sorry`, `admit`, `axiom`, `opaque`, `unsafe`, or `implemented_by`, and the main results were checked to depend only on `propext`, `Classical.choice`, `Quot.sound`.

### Audit answer: does finite support alone give locally finite blocks?

**No.** Locality of each hyperbolic pair (`main.tex:1678`) is modelled by the finitely supported F₂ phase space `(L ⊕ L) →₀ F₂`, so every label is finitely supported — yet the coordinate blocks can still be infinite. This is proved, not asserted: `exists_infinite_coordinateBlock_of_no_independence` exhibits a locally supported family along an exhaustion whose every block is infinite.

What supplies local finiteness is the other half of the manuscript clause, that `{z_i, x_i}` is a symplectic *basis*. Only its linear-independence consequence is assumed, and from it local finiteness is **derived**:
- `coordinateBlock_finite` — every stage-`n` block is finite;
- `coordinateBlock_card_le` — `Nat.card (block n) ≤ |Λ n|`, matching the manuscript's `|I| = |Γ|`.

### Named extra fields (the result is conditional on exactly these)

1. `LocalHyperbolicFamily.indep` — F₂-linear independence of `Sum.elim z x`. Used for local finiteness and for injectivity of the coordinate map. The symplectic pairing values are deliberately *not* assumed, since nothing here needs them.
2. `LatticeExhaustion` (`region`, `mono`, `covers`) — the monotone finite-region exhaustion; the manuscript uses finite subregions without fixing one.
3. `LocalHyperbolicFamily.selected` — the manuscript's subset `P ⊆ I`; only its block restriction is used, with no stabilizer-state property assumed.

No local-finiteness or coherence property is assumed as a field: both are proved from (1)–(2).

### Constructed content

- Phase space, region-supported subspaces, their finite-dimensionality and rank (`finrank_supportedOn`: `2·|S|`), and absorption of finite sets by an exhaustion.
- Coordinate blocks: monotone, exhausting (`iUnion_coordinateBlock`), finite, with the cardinality bound.
- Finite **source** Pauli labels (words supported on the block) and finite **target** Pauli labels (vectors supported on the region), each monotone (inclusion coherence), exhausting (`iSup_sourceLabels`, `iSup_targetLabels`), and finite-dimensional.
- The coordinate map `Finsupp.linearCombination` of the hyperbolic pairs: injective, block-compatible (`coordinateMap_sourceLabels_le`), with block-restricted maps `blockCoordinateMap`, their injectivity, and the commuting-square coherence `blockCoordinateMap_inclusion`.
- Data for later phase calibration: `selectedBlock` (finite, monotone) and `span_selectedBlock_le_targetLabels`.
- `CoordinateBlockSystem` bundling all of it, produced by `LocalHyperbolicFamily.blockSystem`.
- Reuse bridge to checked infrastructure: `LocalHyperbolicFamily.ofAdaptedBasis` turns an `AdaptedPauliCoordinateBasis` (from `Formalization/SymplecticCoordinates.lean`) into such a family, and `coordinateMap_ofAdaptedBasis` identifies its coordinate map with that basis's coordinate-label equivalence.

### Scope discipline

Only `Formalization.SymplecticCoordinates`, `Formalization.AdaptedStabilizerSubspace`, `Formalization.CoherentBasisEquiv` and Mathlib are imported; no P53 or later module. The file makes no C⋆-algebra, global algebraic alpha, product-state, GNS, tensor-splitting, factorhood, trace or weight claim — it is finite-dimensional F₂-linear algebra over a lattice exhaustion.

Classification: items above are (1) checked infrastructure plus (3) conditional results under the three named premises; no manuscript theorem beyond the P52 gate is claimed.

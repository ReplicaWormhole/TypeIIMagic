# P50 — faithful normal tracial state on the von Neumann corner

## Context declaration

- **Source basis:** `main.tex:1336-1455`.

## Plan alignment

- **Package and lane:** `P50`; Lane `G`.
- **Predecessors:** `P49`, integrated and locally audited before submission.
- **Gate discharged:** extend `tau_q` to `q M_Gamma q` and prove it is a
  faithful normal finite tracial state under the exact required hypotheses.
- **Forbidden downstream claims:** no fullness, no statement about every central
  summand, no global trace/weight, and no final type-III exclusion.

## Mathematical target

Create only `AristotleCandidates/NormalFaithfulCornerTrace.lean`. Define the
corner functional induced by P49 in the represented von Neumann corner. Prove
unitality, positivity, cyclicity, normality, and faithfulness wherever supported.
When pinned Mathlib lacks an extension theorem, package the minimal extension
and continuity statement as a named interface and derive the strongest exact
conditional theorem. The conclusion must say **tracial state**, not merely weight.

## Auxiliary assumptions

List all extension, density, normality, support, commutation, and faithfulness
premises explicitly; do not use a global trace.

## Files and imports

Create only `AristotleCandidates/NormalFaithfulCornerTrace.lean`; import P49
and the checked C-star/GNS/bicommutant infrastructure as needed.

## Acceptance criteria

`lake build AristotleCandidates.NormalFaithfulCornerTrace` succeeds without
forbidden declarations. Report which of positivity, normality, faithfulness,
and traciality are proved and which remain named premises.

# Two-lane formalization decision

Date: 2026-08-07

The active Codex/Aristotle loop follows the two-lane plan in `PLAN.md`.

**Lane G** formalizes the manuscript's general-lattice corner argument:
the strong-limit code projection `q`, the faithful normal finite tracial state
on `q M_Gamma q`, finiteness and fullness of `q`, and the conclusion that each
nonzero central summand has a nonzero finite projection and hence is not type
III. This route does not use a direct integral and does not require a global
trace/weight on `M_Gamma`.

**Lane H** formalizes the explicit short-range/local-hyperbolic model:
coherent coordinate maps, an algebraic and C-star `alpha`, the product-state
identity, product GNS tensor factorization, and the resulting factor and
trace/weight classification.

The lanes meet only after their own gates are met. In particular, the explicit
tensor-factor result proves trivial center in the special local-hyperbolic
case, whereas the general corner result rules out type-III central summands
without asserting trivial center.

The first approved parallel Aristotle wave is P47, P48, P52, and P54. No
dependent packet should be submitted before its prerequisite results are
integrated and semantically audited.

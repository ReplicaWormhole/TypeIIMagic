import AristotleCandidates.ConcretePureMixedProductData
import AristotleCandidates.MixedUHFHyperfiniteFactor

/-!
# P59B — the mixed GNS / UHF bridge

**Context declaration.**  *Source basis:* `main.tex:1945-1967`.

## Plan alignment

* Package `P59B`, lane `H`; predecessors `P59A`
  (`AristotleCandidates.ConcretePureMixedProductData`) and `P58`
  (`AristotleCandidates.MixedUHFHyperfiniteFactor`), both integrated and
  locally audited.
* Gate discharged: identify the concrete **mixed** component of the P59A
  product datum with P58's dyadic-UHF model and transport P58's factor and
  tracial structure to it.
* Forbidden downstream claims, none of which is made here: no pure type-I
  factor, no regional product transport, no trace/weight dichotomy, and no
  fresh mixed-factor premise.
-/

set_option maxHeartbeats 1000000
set_option synthInstance.maxHeartbeats 400000

namespace StabilizerHyperfinite

open scoped InnerProductSpace ComplexOrder

namespace UHFBridge

open LocalHyperbolicAlpha

/-! ## 0. The dyadic Pauli-word basis and the word trace -/

section DyadicWords

variable {k : ℕ}

/-- The register matrix model of a dyadic stage, as a complex-linear
equivalence. -/
noncomputable def qubitMatrixLinearEquiv (k : ℕ) :
    QubitTensorPower k ≃ₗ[ℂ] Matrix (Reg (Fin k)) (Reg (Fin k)) ℂ :=
  { qubitMatrixEquiv k with map_smul' := fun c x => map_smul (qubitMatrixEquiv k) c x }

@[simp] theorem qubitMatrixLinearEquiv_apply (x : QubitTensorPower k) :
    qubitMatrixLinearEquiv k x = qubitMatrixEquiv k x := rfl

/-- The standard Pauli words form a complex basis of the dyadic stage. -/
noncomputable def qubitWordBasis (k : ℕ) :
    Module.Basis (Reg (Fin k) × Reg (Fin k)) ℂ (QubitTensorPower k) :=
  stdWordBasis.map (qubitMatrixLinearEquiv k).symm

@[simp] theorem qubitWordBasis_apply (p : Reg (Fin k) × Reg (Fin k)) :
    qubitWordBasis k p = qubitWord k p.1 p.2 := by
  refine qubitMatrixEquiv_injective k ?_
  show qubitMatrixEquiv k ((qubitMatrixLinearEquiv k).symm (stdWordBasis p)) =
      qubitMatrixEquiv k (qubitWord k p.1 p.2)
  rw [stdWordBasis_apply, qubitMatrixEquiv_qubitWord]
  exact (qubitMatrixLinearEquiv k).apply_symm_apply _

/-- The multiplication rule of the standard dyadic Pauli words. -/
theorem qubitWord_mul (k : ℕ) (a b a' b' : Reg (Fin k)) :
    qubitWord k a b * qubitWord k a' b' =
      pauliSign (regPairing b a') • qubitWord k (a + a') (b + b') := by
  refine qubitMatrixEquiv_injective k ?_
  dsimp only
  rw [map_mul, map_smul, qubitMatrixEquiv_qubitWord, qubitMatrixEquiv_qubitWord,
    qubitMatrixEquiv_qubitWord, stdWord_mul]

/-- Every element of the algebraic dyadic limit is the image of a finite
stage, phrased with the canonical stage map `qubitUHFOf`. -/
theorem exists_qubitUHFOf (z : QubitUHFAlgebra) :
    ∃ (n : ℕ) (x : QubitTensorPower n), z = qubitUHFOf n x := by
  induction z using DirectLimit.induction with
  | _ i x => exact ⟨i, x, rfl⟩

theorem card_reg (k : ℕ) : Fintype.card (Reg (Fin k)) = 2 ^ k := by
  simp [Reg, PauliBit]

theorem regSuccEquiv_apply (k : ℕ) (i : Fin 2) (t : Reg (Fin k)) :
    regSuccEquiv k (i, t) = Fin.cons (bitEquiv i) t := rfl

/-- The normalized dyadic trace is the normalized matrix trace of the register
matrix model. -/
theorem qubitTensorTrace_eq_regTrace : ∀ (k : ℕ) (x : QubitTensorPower k),
    qubitTensorTrace k x =
      ((2 ^ k : ℕ) : ℂ)⁻¹ * Matrix.trace (qubitMatrixEquiv k x)
  | 0, x => by
      show scalarTrace x = _
      have : Matrix.trace (qubitMatrixEquiv 0 x) = x := by
        rw [Matrix.trace]
        rw [Finset.sum_eq_single (0 : Reg (Fin 0))]
        · show (scalarMatrixStarEquiv (Reg (Fin 0)) x) 0 0 = x
          rw [scalarMatrixStarEquiv_apply]
        · intro c _ hc
          exact absurd (Subsingleton.elim _ _) hc
        · intro h; exact absurd (Finset.mem_univ _) h
      rw [this]
      simp [scalarTrace]
  | k + 1, x => by
      have hne : ((2 ^ k : ℕ) : ℂ) ≠ 0 := by exact_mod_cast (Nat.two_pow_pos k).ne'
      show normalizedMatrixTraceOver (Fin 2) (qubitTensorTrace k) x = _
      rw [normalizedMatrixTraceOver_apply]
      have htr : Matrix.trace (qubitMatrixEquiv (k + 1) x) =
          ∑ p : Fin 2 × Reg (Fin k), qubitMatrixEquiv k (x p.1 p.1) p.2 p.2 := by
        rw [Matrix.trace]
        rw [← Equiv.sum_comp (regSuccEquiv k)
          (fun y => Matrix.diag (qubitMatrixEquiv (k + 1) x) y)]
        refine Finset.sum_congr rfl (fun p _ => ?_)
        show qubitMatrixEquiv (k + 1) x (regSuccEquiv k p) (regSuccEquiv k p) = _
        rw [qubitMatrixEquiv_succ_apply]
        obtain ⟨i, t⟩ := p
        rw [regSuccEquiv_apply]
        simp
      rw [htr, Fintype.sum_prod_type]
      have hsum : ∀ i : Fin 2, ∑ t : Reg (Fin k), qubitMatrixEquiv k (x i i) t t
          = ((2 ^ k : ℕ) : ℂ) * qubitTensorTrace k (x i i) := by
        intro i
        rw [qubitTensorTrace_eq_regTrace k (x i i)]
        field_simp
        rfl
      simp only [hsum]
      rw [← Finset.mul_sum]
      have h2 : ((2 ^ (k + 1) : ℕ) : ℂ) = 2 * ((2 ^ k : ℕ) : ℂ) := by push_cast; ring
      rw [h2]
      simp only [Fintype.card_fin]
      field_simp
      ring

/-- **The dyadic trace of a Pauli word** is `1` on the identity word and `0` on
every other word. -/
theorem qubitTensorTrace_qubitWord (k : ℕ) (a b : Reg (Fin k)) :
    qubitTensorTrace k (qubitWord k a b) = if a = 0 ∧ b = 0 then 1 else 0 := by
  rw [qubitTensorTrace_eq_regTrace, qubitMatrixEquiv_qubitWord, trace_stdWord, card_reg]
  have hne : ((2 ^ k : ℕ) : ℂ) ≠ 0 := by exact_mod_cast (Nat.two_pow_pos k).ne'
  split_ifs with h
  · exact inv_mul_cancel₀ hne
  · rw [mul_zero]

end DyadicWords

end UHFBridge

/-! ## 1. Mixed coordinate registers

A **mixed register** is the explicit coordinate-index identification required by
the packet: an injective list of `k` *unselected* (mixed) coordinates of the
P52/P53 model, together with a stage of the coordinate exhaustion containing
all of them. -/

namespace LocalHyperbolicAlpha

namespace AlphaData

open CoherentLocalHyperbolic UHFBridge

variable {L I : Type*} [LinearOrder I] (A : AlphaData L I)

/-- **The coordinate-index identification.**  `k` distinct mixed (unselected)
coordinates of the local-hyperbolic model, all visible at one stage of the
coordinate exhaustion. -/
structure MixedRegister (k : ℕ) where
  /-- the chosen mixed coordinates -/
  coord : Fin k → I
  /-- they are distinct -/
  coord_injective : Function.Injective coord
  /-- none of them is selected: they carry the maximally mixed factor -/
  coord_not_selected : ∀ j, coord j ∉ A.family.selected
  /-- a stage of the exhaustion containing all of them -/
  stage : ℕ
  /-- all chosen coordinates are visible at that stage -/
  coord_mem_block : ∀ j, coord j ∈ A.family.coordinateBlock A.exhaustion stage

/-- Additivity of a Pauli form in the left argument over a finite sum. -/
theorem pauliForm_sum_left {V : Type*} [AddCommGroup V] (B : PauliForm V) {J : Type*}
    (s : Finset J) (f : J → V) (w : V) :
    B.form (∑ j ∈ s, f j) w = ∑ j ∈ s, B.form (f j) w := by
  classical
  induction s using Finset.induction_on with
  | empty => simp [B.zero_left]
  | insert a s ha ih =>
      rw [Finset.sum_insert ha, B.add_left, ih, Finset.sum_insert ha]

/-- The value of the coordinate pairing on a single generator. -/
theorem coordPairing_single {J : Type*} (p : J ⊕ J) (c : PauliBit)
    (w : PauliCoordinateLabels J) :
    (coordPairing J).form (Finsupp.single p c) w =
      c * Sum.elim (fun i => w (Sum.inr i)) (fun _ => (0 : PauliBit)) p := by
  show (Finsupp.single p c).sum
      (fun q d => d * Sum.elim (fun i => w (Sum.inr i)) (fun _ => (0 : PauliBit)) q) = _
  rw [Finsupp.sum_single_index]
  rw [zero_mul]

namespace MixedRegister

variable {A} {k : ℕ} (E : A.MixedRegister k)

/-- The coordinate Pauli label of the register word `X^a Z^b`. -/
noncomputable def label (a b : Reg (Fin k)) : PauliCoordinateLabels I :=
  ∑ j : Fin k,
    (Finsupp.single (Sum.inl (E.coord j)) (b j) + Finsupp.single (Sum.inr (E.coord j)) (a j))

theorem label_apply_inl (a b : Reg (Fin k)) (i : I) :
    E.label a b (Sum.inl i) = ∑ j : Fin k, if E.coord j = i then b j else 0 := by
  classical
  rw [label, Finsupp.finset_sum_apply]
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [Finsupp.add_apply, Finsupp.single_apply, Finsupp.single_apply]
  simp

theorem label_apply_inr (a b : Reg (Fin k)) (i : I) :
    E.label a b (Sum.inr i) = ∑ j : Fin k, if E.coord j = i then a j else 0 := by
  classical
  rw [label, Finsupp.finset_sum_apply]
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [Finsupp.add_apply, Finsupp.single_apply, Finsupp.single_apply]
  simp

theorem label_apply_inl_coord (a b : Reg (Fin k)) (j : Fin k) :
    E.label a b (Sum.inl (E.coord j)) = b j := by
  classical
  rw [label_apply_inl]
  rw [Finset.sum_eq_single j]
  · rw [if_pos rfl]
  · intro j' _ hj'
    rw [if_neg (fun h => hj' (E.coord_injective h))]
  · intro h
    exact absurd (Finset.mem_univ j) h

theorem label_apply_inr_coord (a b : Reg (Fin k)) (j : Fin k) :
    E.label a b (Sum.inr (E.coord j)) = a j := by
  classical
  rw [label_apply_inr]
  rw [Finset.sum_eq_single j]
  · rw [if_pos rfl]
  · intro j' _ hj'
    rw [if_neg (fun h => hj' (E.coord_injective h))]
  · intro h
    exact absurd (Finset.mem_univ j) h

theorem label_apply_inl_of_ne {i : I} (a b : Reg (Fin k)) (h : ∀ j, E.coord j ≠ i) :
    E.label a b (Sum.inl i) = 0 := by
  classical
  rw [label_apply_inl]
  exact Finset.sum_eq_zero fun j _ => if_neg (h j)

theorem label_apply_inr_of_ne {i : I} (a b : Reg (Fin k)) (h : ∀ j, E.coord j ≠ i) :
    E.label a b (Sum.inr i) = 0 := by
  classical
  rw [label_apply_inr]
  exact Finset.sum_eq_zero fun j _ => if_neg (h j)

/-- Every coordinate touched by a register word is one of the register's
coordinates. -/
theorem exists_coord_of_ne_zero {a b : Reg (Fin k)} {p : I ⊕ I} (hp : E.label a b p ≠ 0) :
    ∃ j, site p = E.coord j := by
  by_contra hcon
  push_neg at hcon
  have h : ∀ j, E.coord j ≠ site p := fun j hj => hcon j hj.symm
  cases p with
  | inl i =>
      exact hp (E.label_apply_inl_of_ne a b (i := i) h)
  | inr i =>
      exact hp (E.label_apply_inr_of_ne a b (i := i) h)

@[simp] theorem label_zero : E.label 0 0 = 0 := by
  rw [label]
  refine Finset.sum_eq_zero fun j _ => ?_
  show Finsupp.single (Sum.inl (E.coord j)) ((0 : Reg (Fin k)) j)
      + Finsupp.single (Sum.inr (E.coord j)) ((0 : Reg (Fin k)) j) = 0
  simp

theorem label_add (a b a' b' : Reg (Fin k)) :
    E.label (a + a') (b + b') = E.label a b + E.label a' b' := by
  rw [label, label, label, ← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun j _ => ?_
  show Finsupp.single (Sum.inl (E.coord j)) (b j + b' j)
      + Finsupp.single (Sum.inr (E.coord j)) (a j + a' j) = _
  rw [Finsupp.single_add, Finsupp.single_add]
  abel

/-- A register word is a mixed coordinate word in the sense of P59A. -/
theorem isMixedLabel_label (a b : Reg (Fin k)) : A.IsMixedLabel (E.label a b) := by
  intro p hp
  obtain ⟨j, hj⟩ := E.exists_coord_of_ne_zero hp
  rw [hj]
  exact E.coord_not_selected j

/-- A register word is a stage label at the register's stage. -/
theorem label_mem_sourceLabel (a b : Reg (Fin k)) : E.label a b ∈ A.SourceLabel E.stage := by
  rw [CoherentLocalHyperbolic.LocalHyperbolicFamily.mem_sourceLabels_iff]
  intro p hp
  obtain ⟨j, hj⟩ := E.exists_coord_of_ne_zero (Finsupp.mem_support_iff.mp hp)
  rw [hj]
  exact E.coord_mem_block j

/-- The register word as a stage label. -/
noncomputable def stageLabel (a b : Reg (Fin k)) : A.SourceLabel E.stage :=
  ⟨E.label a b, E.label_mem_sourceLabel a b⟩

@[simp] theorem stageLabel_coe (a b : Reg (Fin k)) :
    ((E.stageLabel a b : A.SourceLabel E.stage) : PauliCoordinateLabels I) = E.label a b := rfl

/-- **The Pauli cocycle of the register words is the standard register
cocycle.**  This is why no phase correction is needed in the mixed bridge. -/
theorem sourceForm_stageLabel (a b a' b' : Reg (Fin k)) :
    (A.sourceForm E.stage).form (E.stageLabel a b) (E.stageLabel a' b') = regPairing b a' := by
  classical
  show (coordPairing I).form (E.label a b) (E.label a' b') = regPairing b a'
  rw [label, pauliForm_sum_left]
  rw [regPairing]
  refine Finset.sum_congr rfl fun j _ => ?_
  rw [(coordPairing I).add_left, coordPairing_single, coordPairing_single]
  show b j * (E.label a' b') (Sum.inr (E.coord j)) + a j * (0 : PauliBit) = b j * a' j
  rw [E.label_apply_inr_coord, mul_zero, add_zero]

/-! ## 2. The register word operators inside the P55D concrete C⋆-algebra -/

section WordOps

variable (R : A.SourceConcreteRep)

/-- The concrete operator of a register Pauli word `X^a Z^b`. -/
noncomputable def wordOp (a b : Reg (Fin k)) : R.sourceCStar :=
  R.wordElt E.stage (E.stageLabel a b)

theorem stageLabel_add (a b a' b' : Reg (Fin k)) :
    E.stageLabel a b + E.stageLabel a' b' = E.stageLabel (a + a') (b + b') :=
  Subtype.ext (by
    show E.label a b + E.label a' b' = E.label (a + a') (b + b')
    rw [E.label_add])

@[simp] theorem wordOp_zero_zero : E.wordOp R 0 0 = 1 := by
  have h : E.stageLabel (0 : Reg (Fin k)) 0 = 0 := Subtype.ext E.label_zero
  rw [wordOp, h, R.wordElt_zero]

theorem wordOp_mul (a b a' b' : Reg (Fin k)) :
    E.wordOp R a b * E.wordOp R a' b' =
      pauliSign (regPairing b a') • E.wordOp R (a + a') (b + b') := by
  rw [wordOp, wordOp, R.wordElt_mul, E.sourceForm_stageLabel, E.stageLabel_add]
  rfl

theorem wordOp_star (a b : Reg (Fin k)) :
    star (E.wordOp R a b) = pauliSign (regPairing a b) • E.wordOp R a b := by
  rw [wordOp, R.wordElt_star, E.sourceForm_stageLabel, regPairing_comm b a]

theorem wordOp_mem_mixedCStar (a b : Reg (Fin k)) : E.wordOp R a b ∈ R.mixedCStar :=
  R.wordElt_mem_mixedCStar (E.isMixedLabel_label a b)

/-- Register words with the same coordinate label are the same operator, even
when the two registers are recorded at different stages of the exhaustion. -/
theorem wordOp_eq_of_label_eq {k' : ℕ} (E' : A.MixedRegister k') {a b : Reg (Fin k)}
    {a' b' : Reg (Fin k')} (hlab : E'.label a' b' = E.label a b) :
    E'.wordOp R a' b' = E.wordOp R a b := by
  have h1 : E.stage ≤ max E.stage E'.stage := le_max_left _ _
  have h2 : E'.stage ≤ max E.stage E'.stage := le_max_right _ _
  have h3 : A.sourceIncl h2 (E'.stageLabel a' b') = A.sourceIncl h1 (E.stageLabel a b) := by
    refine Subtype.ext ?_
    rw [A.sourceIncl_coe, A.sourceIncl_coe, stageLabel_coe, stageLabel_coe]
    exact hlab
  rw [wordOp, wordOp, ← R.wordElt_incl h2, ← R.wordElt_incl h1, h3]

theorem label_eq_zero_iff (a b : Reg (Fin k)) : E.label a b = 0 ↔ (a = 0 ∧ b = 0) := by
  constructor
  · intro h
    constructor
    · funext j
      have hj := E.label_apply_inr_coord a b j
      rw [h] at hj
      exact hj.symm
    · funext j
      have hj := E.label_apply_inl_coord a b j
      rw [h] at hj
      exact hj.symm
  · rintro ⟨rfl, rfl⟩
    exact E.label_zero

/-- A register word is an allowed word of the P56R product state exactly when
it is the identity word. -/
theorem mem_allowedLabels_label_iff (a b : Reg (Fin k)) :
    E.label a b ∈ A.allowedLabels ↔ (a = 0 ∧ b = 0) := by
  constructor
  · intro h
    obtain ⟨hx, hz⟩ := (A.mem_allowedLabels_iff _).mp h
    refine ⟨funext fun j => ?_, funext fun j => ?_⟩
    · have hj := E.label_apply_inr_coord a b j
      rw [hx (E.coord j)] at hj
      exact hj.symm
    · have hj := E.label_apply_inl_coord a b j
      by_cases hb : b j = 0
      · exact hb
      · exact absurd (hz (E.coord j) (by rw [hj]; exact hb)) (E.coord_not_selected j)
  · rintro ⟨rfl, rfl⟩
    rw [E.label_zero]
    exact Submodule.zero_mem _

/-- **The P59A product state on a register word** is the normalized dyadic
trace of that word: `1` for the identity and `0` otherwise. -/
theorem totalState_wordOp (a b : Reg (Fin k)) :
    R.totalStateCLM (E.wordOp R a b) = if a = 0 ∧ b = 0 then 1 else 0 := by
  classical
  rw [wordOp, R.totalStateCLM_wordElt, stageLabel_coe, A.productExpectation_eq_indicator]
  by_cases h : a = 0 ∧ b = 0
  · rw [if_pos ((E.mem_allowedLabels_label_iff a b).mpr h), if_pos h]
  · rw [if_neg (fun hc => h ((E.mem_allowedLabels_label_iff a b).mp hc)), if_neg h]

/-! ### The finite-stage bridge homomorphism -/

theorem one_eq_qubitWordBasis : (1 : QubitTensorPower k) = qubitWordBasis k (0, 0) := by
  rw [qubitWordBasis_apply]
  show (1 : QubitTensorPower k) = qubitWord k 0 0
  rw [qubitWord, qubitX_zero, qubitZ_zero, one_mul]

theorem wordOp_map_one :
    (qubitWordBasis k).constr ℂ (fun p => E.wordOp R p.1 p.2) 1 = 1 := by
  rw [one_eq_qubitWordBasis, Module.Basis.constr_basis]
  exact E.wordOp_zero_zero R

theorem wordOp_map_mul (p q : Reg (Fin k) × Reg (Fin k)) :
    (qubitWordBasis k).constr ℂ (fun p => E.wordOp R p.1 p.2)
        (qubitWordBasis k p * qubitWordBasis k q) =
      (qubitWordBasis k).constr ℂ (fun p => E.wordOp R p.1 p.2) (qubitWordBasis k p) *
        (qubitWordBasis k).constr ℂ (fun p => E.wordOp R p.1 p.2) (qubitWordBasis k q) := by
  have hprod : qubitWordBasis k p * qubitWordBasis k q =
      pauliSign (regPairing p.2 q.1) • qubitWordBasis k (p.1 + q.1, p.2 + q.2) := by
    rw [qubitWordBasis_apply, qubitWordBasis_apply, qubitWordBasis_apply, qubitWord_mul]
  rw [hprod, map_smul, Module.Basis.constr_basis, Module.Basis.constr_basis,
    Module.Basis.constr_basis, E.wordOp_mul]

theorem wordOp_map_star (p : Reg (Fin k) × Reg (Fin k)) :
    (qubitWordBasis k).constr ℂ (fun p => E.wordOp R p.1 p.2) (star (qubitWordBasis k p)) =
      star ((qubitWordBasis k).constr ℂ (fun p => E.wordOp R p.1 p.2) (qubitWordBasis k p)) := by
  have hstar : star (qubitWordBasis k p) =
      pauliSign (regPairing p.1 p.2) • qubitWordBasis k p := by
    rw [qubitWordBasis_apply, star_qubitWord]
  rw [hstar, map_smul, Module.Basis.constr_basis]
  exact (E.wordOp_star R p.1 p.2).symm

/-- **The finite-stage mixed bridge.**  The dyadic stage of `k` qubits maps
into the P55D concrete source C⋆-algebra by sending the standard Pauli word
`X^a Z^b` to the coordinate Pauli word of the register.  No phase correction is
needed: the two Pauli cocycles coincide. -/
noncomputable def stageHom : QubitTensorPower k →⋆ₐ[ℂ] R.sourceCStar :=
  starAlgHomOfBasis ((qubitWordBasis k).constr ℂ (fun p => E.wordOp R p.1 p.2))
    (qubitWordBasis k) (E.wordOp_map_one R) (E.wordOp_map_mul R) (E.wordOp_map_star R)

theorem stageHom_apply (x : QubitTensorPower k) :
    E.stageHom R x = (qubitWordBasis k).constr ℂ (fun p => E.wordOp R p.1 p.2) x := rfl

@[simp] theorem stageHom_qubitWord (a b : Reg (Fin k)) :
    E.stageHom R (qubitWord k a b) = E.wordOp R a b := by
  have h := Module.Basis.constr_basis (qubitWordBasis k) ℂ
    (fun p : Reg (Fin k) × Reg (Fin k) => E.wordOp R p.1 p.2) (a, b)
  rw [qubitWordBasis_apply] at h
  exact h

theorem stageHom_mem_mixedCStar (x : QubitTensorPower k) : E.stageHom R x ∈ R.mixedCStar := by
  classical
  rw [← (qubitWordBasis k).sum_repr x, map_sum]
  refine sum_mem fun p _ => ?_
  rw [map_smul, qubitWordBasis_apply, E.stageHom_qubitWord]
  exact SMulMemClass.smul_mem _ (E.wordOp_mem_mixedCStar R p.1 p.2)

/-- **The finite-stage bridge is state preserving**: it carries the normalized
dyadic trace to the P59A mixed marginal. -/
theorem totalState_stageHom (x : QubitTensorPower k) :
    R.totalStateCLM (E.stageHom R x) = qubitTensorTrace k x := by
  classical
  conv_rhs => rw [← (qubitWordBasis k).sum_repr x]
  conv_lhs => rw [← (qubitWordBasis k).sum_repr x]
  rw [map_sum, map_sum, map_sum]
  refine Finset.sum_congr rfl fun p _ => ?_
  rw [map_smul, map_smul, map_smul, qubitWordBasis_apply, E.stageHom_qubitWord,
    E.totalState_wordOp, qubitTensorTrace_qubitWord]

/-- The finite-stage bridge kills only `0`; this is the trace faithfulness of
P54 transported through the bridge. -/
theorem eq_zero_of_stageHom_eq_zero {z : QubitTensorPower k} (h : E.stageHom R z = 0) :
    z = 0 := by
  have htr : qubitTensorTrace k (star z * z) = 0 := by
    rw [← E.totalState_stageHom R, map_mul, map_star, h, star_zero, zero_mul, map_zero]
  exact qubitTensorTrace_isFaithful k z htr

theorem stageHom_injective : Function.Injective (E.stageHom R) := by
  intro x y hxy
  refine (qubitMatrixLinearEquiv k).injective ?_
  set Lm := (qubitWordBasis k).constr ℂ (fun p : Reg (Fin k) × Reg (Fin k) => E.wordOp R p.1 p.2)
    with hLm
  set M := Lm.comp ((qubitMatrixLinearEquiv k).symm.toLinearMap) with hM
  have hMval : ∀ d, M d = E.stageHom R ((qubitMatrixLinearEquiv k).symm d) := fun _ => rfl
  have hker : ∀ d, M d = 0 → d = 0 := by
    intro d hd
    have hz := E.eq_zero_of_stageHom_eq_zero R ((hMval d).symm.trans hd)
    have := congrArg (qubitMatrixLinearEquiv k) hz
    rwa [LinearEquiv.apply_symm_apply, map_zero] at this
  refine sub_eq_zero.mp (hker _ ?_)
  rw [map_sub, hMval, hMval, LinearEquiv.symm_apply_apply, LinearEquiv.symm_apply_apply, hxy,
    sub_self]

/-- If the register exhausts the mixed coordinates, every mixed coordinate word
lies in the range of the finite-stage bridge. -/
theorem wordElt_mem_range_stageHom
    {n : ℕ} {v : A.SourceLabel n}
    (hcov : ∀ p : I ⊕ I, (v : PauliCoordinateLabels I) p ≠ 0 → ∃ j, site p = E.coord j) :
    R.wordElt n v ∈ Set.range (E.stageHom R) := by
  classical
  refine ⟨qubitWord k (fun j => (v : PauliCoordinateLabels I) (Sum.inr (E.coord j)))
      (fun j => (v : PauliCoordinateLabels I) (Sum.inl (E.coord j))), ?_⟩
  rw [E.stageHom_qubitWord, wordOp]
  have hlab : E.label (fun j => (v : PauliCoordinateLabels I) (Sum.inr (E.coord j)))
      (fun j => (v : PauliCoordinateLabels I) (Sum.inl (E.coord j)))
      = (v : PauliCoordinateLabels I) := by
    refine Finsupp.ext fun p => ?_
    cases p with
    | inl i =>
        by_cases hi : ∃ j, E.coord j = i
        · obtain ⟨j, rfl⟩ := hi
          exact E.label_apply_inl_coord _ _ j
        · push_neg at hi
          rw [E.label_apply_inl_of_ne _ _ (fun j hj => hi j hj)]
          by_contra hne
          obtain ⟨j, hj⟩ := hcov (Sum.inl i) (fun h0 => hne h0.symm)
          exact hi j hj.symm
    | inr i =>
        by_cases hi : ∃ j, E.coord j = i
        · obtain ⟨j, rfl⟩ := hi
          exact E.label_apply_inr_coord _ _ j
        · push_neg at hi
          rw [E.label_apply_inr_of_ne _ _ (fun j hj => hi j hj)]
          by_contra hne
          obtain ⟨j, hj⟩ := hcov (Sum.inr i) (fun h0 => hne h0.symm)
          exact hi j hj.symm
  have hn : n ≤ max n E.stage := le_max_left _ _
  have hs : E.stage ≤ max n E.stage := le_max_right _ _
  have h3 : A.sourceIncl hs (E.stageLabel
      (fun j => (v : PauliCoordinateLabels I) (Sum.inr (E.coord j)))
      (fun j => (v : PauliCoordinateLabels I) (Sum.inl (E.coord j)))) = A.sourceIncl hn v := by
    refine Subtype.ext ?_
    rw [A.sourceIncl_coe, A.sourceIncl_coe, stageLabel_coe]
    exact hlab
  rw [← R.wordElt_incl hs, h3, R.wordElt_incl hn]

end WordOps

end MixedRegister

/-! ## 3. Coherent enumerations of the mixed coordinates -/

/-- **The coordinate-index identification in the infinite mixed branch**: an
injective enumeration of mixed (unselected) coordinates by the natural
numbers. -/
structure MixedEnumeration where
  /-- the enumerated mixed coordinates -/
  coord : ℕ → I
  /-- the enumeration is injective -/
  coord_injective : Function.Injective coord
  /-- every enumerated coordinate is unselected -/
  coord_not_selected : ∀ j, coord j ∉ A.family.selected

namespace MixedEnumeration

variable {A} (N : A.MixedEnumeration)

/-- A stage of the coordinate exhaustion containing the first `k` enumerated
coordinates. -/
noncomputable def stage (k : ℕ) : ℕ := (Finset.range k).sup (fun j => A.birth (N.coord j))

theorem stage_mono : Monotone N.stage := by
  intro k k' h
  exact Finset.sup_mono
    (fun x hx => Finset.mem_range.mpr (lt_of_lt_of_le (Finset.mem_range.mp hx) h))

/-- The register of the first `k` enumerated coordinates.  The dyadic
connecting map adjoins qubits on the left, so position `j` of a `k`-qubit
register carries the coordinate number `k - (j+1)`. -/
noncomputable def register (k : ℕ) : A.MixedRegister k where
  coord j := N.coord (k - ((j : ℕ) + 1))
  coord_injective := by
    intro j1 j2 hj
    have h := N.coord_injective hj
    have h1 := j1.isLt
    have h2 := j2.isLt
    exact Fin.ext (by omega)
  coord_not_selected j := N.coord_not_selected _
  stage := N.stage k
  coord_mem_block := by
    intro j
    refine A.mem_coordinateBlock_of_birth_le ?_
    have hj := j.isLt
    have hmem : k - ((j : ℕ) + 1) ∈ Finset.range k := Finset.mem_range.mpr (by omega)
    exact Finset.le_sup (f := fun j => A.birth (N.coord j)) hmem

@[simp] theorem register_coord (k : ℕ) (j : Fin k) :
    (N.register k).coord j = N.coord (k - ((j : ℕ) + 1)) := rfl

@[simp] theorem register_stage (k : ℕ) : (N.register k).stage = N.stage k := rfl

/-- **Coherence of the registers along the dyadic tower.** -/
theorem register_label_pad {k k' : ℕ} (h : k ≤ k') (a b : Reg (Fin k)) :
    (N.register k').label (padReg k k' a) (padReg k k' b) = (N.register k).label a b := by
  classical
  have hemb : ∀ i : Fin k, (i : ℕ) + (k' - k) < k' := fun i => by have := i.isLt; omega
  set e : Fin k → Fin k' := fun i => ⟨(i : ℕ) + (k' - k), hemb i⟩ with he
  have hinj : ∀ i1 ∈ (Finset.univ : Finset (Fin k)), ∀ i2 ∈ (Finset.univ : Finset (Fin k)),
      e i1 = e i2 → i1 = i2 := by
    intro i1 _ i2 _ hi
    have := congrArg Fin.val hi
    simp only [he] at this
    exact Fin.ext (by omega)
  set F : Fin k' → PauliCoordinateLabels I := fun j' =>
    Finsupp.single (Sum.inl ((N.register k').coord j')) (padReg k k' b j')
      + Finsupp.single (Sum.inr ((N.register k').coord j')) (padReg k k' a j') with hF
  have hzero : ∀ j' ∈ (Finset.univ : Finset (Fin k')),
      j' ∉ Finset.image e Finset.univ → F j' = 0 := by
    intro j' _ hj'
    have hlt : (j' : ℕ) + k < k' := by
      by_contra hge
      push_neg at hge
      have hlt' : (j' : ℕ) + k - k' < k := by have := j'.isLt; omega
      refine hj' (Finset.mem_image.mpr ⟨⟨(j' : ℕ) + k - k', hlt'⟩, Finset.mem_univ _, ?_⟩)
      refine Fin.ext ?_
      simp only [he]
      have := j'.isLt
      omega
    rw [hF]
    simp only
    rw [padReg_apply_of_lt _ _ hlt, padReg_apply_of_lt _ _ hlt]
    simp
  have hsum : ∑ j' ∈ Finset.image e Finset.univ, F j' = ∑ j' : Fin k', F j' :=
    (Finset.sum_subset (Finset.subset_univ _) hzero)
  have himg : ∑ j' ∈ Finset.image e Finset.univ, F j' = ∑ i : Fin k, F (e i) :=
    Finset.sum_image hinj
  have hterm : ∀ i : Fin k, F (e i) =
      Finsupp.single (Sum.inl ((N.register k).coord i)) (b i)
        + Finsupp.single (Sum.inr ((N.register k).coord i)) (a i) := by
    intro i
    have hi := i.isLt
    have hcoord : (N.register k').coord (e i) = (N.register k).coord i := by
      show N.coord (k' - ((e i : ℕ) + 1)) = N.coord (k - ((i : ℕ) + 1))
      congr 1
      simp only [he]
      omega
    have hval : ((e i : ℕ) + k) = k' + (i : ℕ) := by simp only [he]; omega
    rw [hF]
    simp only
    rw [hcoord, padReg_apply_of_le _ _ i hval, padReg_apply_of_le _ _ i hval]
  rw [MixedRegister.label, MixedRegister.label, ← hsum, himg]
  exact Finset.sum_congr rfl fun i _ => hterm i

section Limit

variable (R : A.SourceConcreteRep)

theorem stageHom_compat {k k' : ℕ} (h : k ≤ k') (x : QubitTensorPower k) :
    (N.register k').stageHom R (qubitTensorPowerMap k k' h x) = (N.register k).stageHom R x := by
  classical
  conv_lhs => rw [← (qubitWordBasis k).sum_repr x]
  conv_rhs => rw [← (qubitWordBasis k).sum_repr x]
  rw [map_sum, map_sum, map_sum]
  refine Finset.sum_congr rfl fun p _ => ?_
  rw [map_smul, map_smul, map_smul, qubitWordBasis_apply, qubitTensorPowerMap_qubitWord,
    MixedRegister.stageHom_qubitWord, MixedRegister.stageHom_qubitWord]
  congr 1
  exact MixedRegister.wordOp_eq_of_label_eq (N.register k) R (N.register k')
    (N.register_label_pad h p.1 p.2)

/-- **The mixed UHF bridge (algebraic form).**  The algebraic dyadic (UHF)
limit maps into the P55D concrete source C⋆-algebra. -/
noncomputable def uhfHom : QubitUHFAlgebra →⋆ₐ[ℂ] R.sourceCStar :=
  algebraicLimitStarAlgHom (fun k => (N.register k).stageHom R)
    (fun k k' h x => N.stageHom_compat R h x)

@[simp] theorem uhfHom_of (k : ℕ) (x : QubitTensorPower k) :
    N.uhfHom R (qubitUHFOf k x) = (N.register k).stageHom R x :=
  algebraicLimitStarAlgHom_of _ _ k x

theorem uhfHom_mem_mixedCStar (z : QubitUHFAlgebra) : N.uhfHom R z ∈ R.mixedCStar := by
  obtain ⟨n, x, rfl⟩ := exists_qubitUHFOf z
  rw [N.uhfHom_of R]
  exact (N.register n).stageHom_mem_mixedCStar R x

/-- **The mixed UHF bridge.**  The algebraic dyadic (UHF) limit maps into the
P59A mixed coordinate C⋆-algebra. -/
noncomputable def mixedHom : QubitUHFAlgebra →⋆ₐ[ℂ] R.mixedCStar :=
  StarAlgHom.codRestrict (N.uhfHom R) R.mixedCStar (N.uhfHom_mem_mixedCStar R)

@[simp] theorem mixedHom_coe (z : QubitUHFAlgebra) :
    ((N.mixedHom R z : R.mixedCStar) : R.sourceCStar) = N.uhfHom R z := rfl

/-- **The mixed bridge is state preserving**: it carries the canonical
normalized UHF trace to the P59A mixed marginal state. -/
theorem mixedMarginal_mixedHom (z : QubitUHFAlgebra) :
    R.mixedMarginal (N.mixedHom R z) = qubitUHFTrace z := by
  obtain ⟨n, x, rfl⟩ := exists_qubitUHFOf z
  rw [R.mixedMarginal_apply, N.mixedHom_coe R, N.uhfHom_of R, qubitUHFTrace_of]
  exact (N.register n).totalState_stageHom R x

theorem uhfHom_injective : Function.Injective (N.uhfHom R) := by
  intro z w hzw
  obtain ⟨n, x, rfl⟩ := exists_qubitUHFOf z
  obtain ⟨m, y, rfl⟩ := exists_qubitUHFOf w
  rw [← qubitUHFOf_map (le_max_left n m) x, ← qubitUHFOf_map (le_max_right n m) y]
  rw [← qubitUHFOf_map (le_max_left n m) x, ← qubitUHFOf_map (le_max_right n m) y,
    N.uhfHom_of R, N.uhfHom_of R] at hzw
  rw [(N.register (max n m)).stageHom_injective R hzw]

theorem mixedHom_injective : Function.Injective (N.mixedHom R) := by
  intro z w hzw
  exact N.uhfHom_injective R (congrArg Subtype.val hzw)

/-- Every mixed stage word is covered by a large enough initial register of an
exhaustive enumeration. -/
theorem exists_register_cover (hsurj : ∀ i : I, i ∉ A.family.selected → ∃ j, N.coord j = i)
    {n : ℕ} (v : A.SourceLabel n) (hv : A.IsMixedLabel (v : PauliCoordinateLabels I)) :
    ∃ k : ℕ, ∀ p : I ⊕ I, (v : PauliCoordinateLabels I) p ≠ 0 →
      ∃ j : Fin k, site p = (N.register k).coord j := by
  classical
  have hex : ∀ p ∈ (v : PauliCoordinateLabels I).support, ∃ mp : ℕ, N.coord mp = site p := by
    intro p hp
    exact hsurj (site p) (hv p (Finsupp.mem_support_iff.mp hp))
  choose! m hm using hex
  refine ⟨(v : PauliCoordinateLabels I).support.sup m + 1, ?_⟩
  intro p hp
  have hps : p ∈ (v : PauliCoordinateLabels I).support := Finsupp.mem_support_iff.mpr hp
  have hle : m p ≤ (v : PauliCoordinateLabels I).support.sup m := Finset.le_sup hps
  refine ⟨⟨(v : PauliCoordinateLabels I).support.sup m - m p, by omega⟩, ?_⟩
  rw [N.register_coord]
  have hidx : (v : PauliCoordinateLabels I).support.sup m + 1 -
      (((v : PauliCoordinateLabels I).support.sup m - m p) + 1) = m p := by omega
  rw [hidx, hm p hps]

/-- **Norm approximation.**  If the enumeration exhausts the mixed coordinates,
every element of the P59A mixed coordinate C⋆-algebra is a norm limit of images
of the dyadic UHF algebra. -/
theorem exists_uhfHom_approx (hsurj : ∀ i : I, i ∉ A.family.selected → ∃ j, N.coord j = i)
    (b : R.mixedCStar) {eps : ℝ} (heps : 0 < eps) :
    ∃ z : QubitUHFAlgebra, ‖(b : R.sourceCStar) - N.uhfHom R z‖ < eps := by
  classical
  set Rng : Submodule ℂ R.sourceCStar :=
    ((N.uhfHom R).range : StarSubalgebra ℂ R.sourceCStar).toSubalgebra.toSubmodule with hRng
  have hgen : R.labelWordSet A.IsMixedLabel ⊆ (Rng.topologicalClosure : Set R.sourceCStar) := by
    rintro T ⟨n, v, hv, rfl⟩
    obtain ⟨k, hk⟩ := N.exists_register_cover hsurj v hv
    obtain ⟨x, hx⟩ := (N.register k).wordElt_mem_range_stageHom R hk (v := v)
    refine Submodule.le_topologicalClosure _ ?_
    refine ⟨qubitUHFOf k x, ?_⟩
    show N.uhfHom R (qubitUHFOf k x) = R.wordElt n v
    rw [N.uhfHom_of R]
    exact hx
  have hsub := R.labelCStarAlg_subset_of_closed (Q := A.IsMixedLabel) A.isMixedLabel_zero
    (fun _ _ hc hd => A.isMixedLabel_add hc hd)
    (Submodule.isClosed_topologicalClosure Rng) hgen
  have hb0 : (b : R.sourceCStar) ∈ (Rng.topologicalClosure : Set R.sourceCStar) := hsub b.2
  rw [Submodule.topologicalClosure_coe, Metric.mem_closure_iff] at hb0
  obtain ⟨T, hT, hdist⟩ := hb0 eps heps
  have hT' : T ∈ (N.uhfHom R).range := hT
  obtain ⟨z, hz⟩ := hT'
  refine ⟨z, ?_⟩
  rw [show N.uhfHom R z = T from hz]
  rwa [dist_eq_norm] at hdist

/-- **The mixed bridge has dense range** as soon as the enumeration exhausts
the mixed coordinates. -/
theorem denseRange_mixedHom
    (hsurj : ∀ i : I, i ∉ A.family.selected → ∃ j, N.coord j = i) :
    DenseRange (N.mixedHom R) := by
  intro b
  rw [Metric.mem_closure_iff]
  intro eps heps
  obtain ⟨z, hz⟩ := N.exists_uhfHom_approx R hsurj b heps
  refine ⟨N.mixedHom R z, ⟨z, rfl⟩, ?_⟩
  rw [Subtype.dist_eq, dist_eq_norm]
  exact hz

end Limit

end MixedEnumeration

end AlphaData

end LocalHyperbolicAlpha

/-! ## 4. Spatial transport of the P58 structures

A unitary between two Hilbert spaces carries the P58 notions -- trivial centre,
matricial chain, vector-normal functionals, and the whole hyperfinite
finite-factor model -- from one side to the other.  This is checked
infrastructure: it makes no manuscript claim. -/

namespace SpatialTransport

variable {H : Type*} [NormedAddCommGroup H] [InnerProductSpace ℂ H] [CompleteSpace H]
variable {H' : Type*} [NormedAddCommGroup H'] [InnerProductSpace ℂ H'] [CompleteSpace H']

theorem conj_apply (U : H ≃ₗᵢ[ℂ] H') (T : H →L[ℂ] H) (y : H') :
    U.conjStarAlgEquiv T y = U (T (U.symm y)) := rfl

theorem conj_symm_conj (U : H ≃ₗᵢ[ℂ] H') (T : H →L[ℂ] H) :
    U.symm.conjStarAlgEquiv (U.conjStarAlgEquiv T) = T :=
  U.conjStarAlgEquiv.symm_apply_apply T

theorem norm_conjStarAlgEquiv (U : H ≃ₗᵢ[ℂ] H') (T : H →L[ℂ] H) :
    ‖U.conjStarAlgEquiv T‖ = ‖T‖ := by
  refine le_antisymm ?_ ?_
  · refine ContinuousLinearMap.opNorm_le_bound _ (norm_nonneg T) fun y => ?_
    rw [conj_apply, U.norm_map]
    calc ‖T (U.symm y)‖ ≤ ‖T‖ * ‖U.symm y‖ := T.le_opNorm _
      _ = ‖T‖ * ‖y‖ := by rw [U.symm.norm_map]
  · refine ContinuousLinearMap.opNorm_le_bound _ (norm_nonneg _) fun x => ?_
    have hx : ‖T x‖ = ‖U.conjStarAlgEquiv T (U x)‖ := by
      rw [conj_apply, U.norm_map, U.symm_apply_apply]
    rw [hx]
    calc ‖U.conjStarAlgEquiv T (U x)‖ ≤ ‖U.conjStarAlgEquiv T‖ * ‖U x‖ :=
          ContinuousLinearMap.le_opNorm _ _
      _ = ‖U.conjStarAlgEquiv T‖ * ‖x‖ := by rw [U.norm_map]

/-- Conjugation by a unitary, as a linear isometry equivalence of the two
operator algebras. -/
noncomputable def conjIsom (U : H ≃ₗᵢ[ℂ] H') : (H →L[ℂ] H) ≃ₗᵢ[ℂ] (H' →L[ℂ] H') where
  toLinearEquiv := U.conjStarAlgEquiv.toAlgEquiv.toLinearEquiv
  norm_map' := norm_conjStarAlgEquiv U

@[simp] theorem conjIsom_apply (U : H ≃ₗᵢ[ℂ] H') (T : H →L[ℂ] H) :
    conjIsom U T = U.conjStarAlgEquiv T := rfl

/-- Conjugation by a unitary, as a `*`-homomorphism of the operator algebras. -/
noncomputable def conjHom (U : H ≃ₗᵢ[ℂ] H') : (H →L[ℂ] H) →⋆ₐ[ℂ] (H' →L[ℂ] H') :=
  starAlgHomOfStarAlgEquiv U.conjStarAlgEquiv

@[simp] theorem conjHom_apply (U : H ≃ₗᵢ[ℂ] H') (T : H →L[ℂ] H) :
    conjHom U T = U.conjStarAlgEquiv T := rfl

/-- The image of a `*`-subalgebra of operators under conjugation by a
unitary. -/
noncomputable def mapAlg (U : H ≃ₗᵢ[ℂ] H') (S : StarSubalgebra ℂ (H →L[ℂ] H)) :
    StarSubalgebra ℂ (H' →L[ℂ] H') :=
  S.map (conjHom U)

theorem coe_mapAlg (U : H ≃ₗᵢ[ℂ] H') (S : StarSubalgebra ℂ (H →L[ℂ] H)) :
    (mapAlg U S : Set (H' →L[ℂ] H')) =
      (fun T => U.conjStarAlgEquiv T) '' (S : Set (H →L[ℂ] H)) :=
  StarSubalgebra.coe_map S (conjHom U)

theorem mem_mapAlg (U : H ≃ₗᵢ[ℂ] H') {S : StarSubalgebra ℂ (H →L[ℂ] H)}
    {T : H →L[ℂ] H} (hT : T ∈ S) : U.conjStarAlgEquiv T ∈ mapAlg U S := by
  rw [← SetLike.mem_coe, coe_mapAlg]
  exact ⟨T, hT, rfl⟩

theorem image_centralizer (U : H ≃ₗᵢ[ℂ] H') (S : Set (H →L[ℂ] H)) :
    (fun T => U.conjStarAlgEquiv T) '' S.centralizer =
      ((fun T => U.conjStarAlgEquiv T) '' S).centralizer :=
  StabilizerHyperfinite.BoundedStateGNS.image_centralizer_of_mulEquiv
    (U.conjStarAlgEquiv.toRingEquiv.toMulEquiv) S

/-- The image of a concrete von Neumann algebra under conjugation by a
unitary. -/
noncomputable def mapVN (U : H ≃ₗᵢ[ℂ] H') (M : VonNeumannAlgebra H) : VonNeumannAlgebra H' where
  toStarSubalgebra := mapAlg U M.toStarSubalgebra
  centralizer_centralizer' := by
    have hcoe : (mapAlg U M.toStarSubalgebra).carrier =
        (fun T => U.conjStarAlgEquiv T) '' (M : Set (H →L[ℂ] H)) :=
      coe_mapAlg U M.toStarSubalgebra
    have hcc : Set.centralizer (Set.centralizer ((M : Set (H →L[ℂ] H)))) =
        (M : Set (H →L[ℂ] H)) := M.centralizer_centralizer'
    rw [hcoe, ← image_centralizer, ← image_centralizer, hcc]

theorem coe_mapVN (U : H ≃ₗᵢ[ℂ] H') (M : VonNeumannAlgebra H) :
    (mapVN U M : Set (H' →L[ℂ] H')) =
      (fun T => U.conjStarAlgEquiv T) '' (M : Set (H →L[ℂ] H)) :=
  coe_mapAlg U M.toStarSubalgebra

theorem mapVN_vonNeumannGenerated (U : H ≃ₗᵢ[ℂ] H') (S : StarSubalgebra ℂ (H →L[ℂ] H)) :
    mapVN U (StarSubalgebra.vonNeumannGenerated S) =
      StarSubalgebra.vonNeumannGenerated (mapAlg U S) := by
  refine SetLike.coe_injective ?_
  rw [coe_mapVN, StarSubalgebra.coe_vonNeumannGenerated, StarSubalgebra.coe_vonNeumannGenerated,
    coe_mapAlg, ← image_centralizer, ← image_centralizer]

theorem hasTrivialOperatorCenter_mapVN (U : H ≃ₗᵢ[ℂ] H') {M : VonNeumannAlgebra H}
    (h : HasTrivialOperatorCenter M) : HasTrivialOperatorCenter (mapVN U M) := by
  intro x hx hcomm
  rw [coe_mapVN] at hx
  obtain ⟨y, hy, rfl⟩ := hx
  have hcomm' : ∀ z ∈ (M : Set (H →L[ℂ] H)), z * y = y * z := by
    intro z hz
    have hz' : U.conjStarAlgEquiv z ∈ (mapVN U M : Set (H' →L[ℂ] H')) := by
      rw [coe_mapVN]; exact ⟨z, hz, rfl⟩
    have hcz := hcomm _ hz'
    have h2 : U.conjStarAlgEquiv (z * y) = U.conjStarAlgEquiv (y * z) := by
      rw [map_mul U.conjStarAlgEquiv, map_mul U.conjStarAlgEquiv]; exact hcz
    exact U.conjStarAlgEquiv.injective h2
  obtain ⟨c, hc⟩ := h y hy hcomm'
  refine ⟨c, ?_⟩
  show U.conjStarAlgEquiv y = c • 1
  rw [hc, map_smul, map_one]

/-- A `*`-subalgebra is `*`-isomorphic to its image under conjugation. -/
noncomputable def mapAlgEquiv (U : H ≃ₗᵢ[ℂ] H') (S : StarSubalgebra ℂ (H →L[ℂ] H)) :
    S ≃⋆ₐ[ℂ] mapAlg U S :=
  StarAlgEquiv.ofBijective
    (StarAlgHom.codRestrict ((conjHom U).comp S.subtype) (mapAlg U S)
      (fun a => mem_mapAlg U a.2))
    ⟨by
      intro a b hab
      have hval : U.conjStarAlgEquiv (a : H →L[ℂ] H) = U.conjStarAlgEquiv (b : H →L[ℂ] H) :=
        congrArg Subtype.val hab
      exact Subtype.ext (U.conjStarAlgEquiv.injective hval), by
      rintro ⟨y, hy⟩
      rw [← SetLike.mem_coe, coe_mapAlg] at hy
      obtain ⟨T, hT, hTy⟩ := hy
      exact ⟨⟨T, hT⟩, Subtype.ext hTy⟩⟩

theorem coe_iUnion_mapAlg (U : H ≃ₗᵢ[ℂ] H') (C : ℕ → StarSubalgebra ℂ (H →L[ℂ] H)) :
    (⋃ n, (mapAlg U (C n) : Set (H' →L[ℂ] H'))) =
      (fun T => U.conjStarAlgEquiv T) '' (⋃ n, (C n : Set (H →L[ℂ] H))) := by
  rw [Set.image_iUnion]
  exact Set.iUnion_congr fun n => coe_mapAlg U (C n)

/-- Transport of a matricial chain along a unitary. -/
noncomputable def isMatricialChain_mapAlg (U : H ≃ₗᵢ[ℂ] H')
    {S : StarSubalgebra ℂ (H →L[ℂ] H)} (h : IsMatricialChain S) :
    IsMatricialChain (mapAlg U S) where
  chain n := mapAlg U (h.chain n)
  dim := h.dim
  dim_tendsto := h.dim_tendsto
  mono := by
    intro n m hnm y hy
    rw [← SetLike.mem_coe, coe_mapAlg] at hy ⊢
    obtain ⟨T, hT, rfl⟩ := hy
    exact ⟨T, h.mono hnm hT, rfl⟩
  matrix n := ⟨(mapAlgEquiv U (h.chain n)).symm.trans (h.matrix n).some⟩
  dense := by
    rw [coe_iUnion_mapAlg, coe_mapAlg, ← h.dense]
    exact ((conjIsom U).toHomeomorph.image_closure _).symm

/-- **Spatial invariance of the P58 hyperfinite finite-factor model.** -/
theorem isHyperfiniteFiniteFactorModel_mapVN (U : H ≃ₗᵢ[ℂ] H') {M : VonNeumannAlgebra H}
    (h : IsHyperfiniteFiniteFactorModel M) :
    IsHyperfiniteFiniteFactorModel (mapVN U M) where
  factor := hasTrivialOperatorCenter_mapVN U h.factor
  finite_trace := by
    obtain ⟨phi, ⟨v, hv⟩, hone, hpos, htr, hfaith⟩ := h.finite_trace
    refine ⟨phi.comp (conjIsom U.symm).toLinearEquiv.toLinearMap, ⟨U v, ?_⟩, ?_, ?_, ?_, ?_⟩
    · intro x
      show phi (U.symm.conjStarAlgEquiv x) = ⟪U v, x (U v)⟫_ℂ
      rw [hv]
      have h1 : U.symm.conjStarAlgEquiv x v = U.symm (x (U v)) := by
        show U.symm (x (U.symm.symm v)) = U.symm (x (U v))
        rw [LinearIsometryEquiv.symm_symm]
      rw [h1, ← U.inner_map_map v (U.symm (x (U v))), LinearIsometryEquiv.apply_symm_apply]
    · show phi (U.symm.conjStarAlgEquiv 1) = 1
      rw [map_one, hone]
    · intro x
      obtain ⟨r, hr, hx⟩ := hpos (U.symm.conjStarAlgEquiv x)
      refine ⟨r, hr, ?_⟩
      show phi (U.symm.conjStarAlgEquiv (star x * x)) = (r : ℂ)
      rw [map_mul U.symm.conjStarAlgEquiv, map_star U.symm.conjStarAlgEquiv, hx]
    · intro x hx y hy
      rw [coe_mapVN] at hx hy
      obtain ⟨x', hx', rfl⟩ := hx
      obtain ⟨y', hy', rfl⟩ := hy
      show phi (U.symm.conjStarAlgEquiv (U.conjStarAlgEquiv x' * U.conjStarAlgEquiv y')) =
        phi (U.symm.conjStarAlgEquiv (U.conjStarAlgEquiv y' * U.conjStarAlgEquiv x'))
      rw [map_mul U.symm.conjStarAlgEquiv, map_mul U.symm.conjStarAlgEquiv,
        conj_symm_conj, conj_symm_conj]
      exact htr x' hx' y' hy'
    · intro x hx hzero
      rw [coe_mapVN] at hx
      obtain ⟨x', hx', rfl⟩ := hx
      have hz : phi (star x' * x') = 0 := by
        have hz' : phi (U.symm.conjStarAlgEquiv
            (star (U.conjStarAlgEquiv x') * U.conjStarAlgEquiv x')) = 0 := hzero
        rwa [map_mul U.symm.conjStarAlgEquiv, map_star U.symm.conjStarAlgEquiv,
          conj_symm_conj] at hz'
      show U.conjStarAlgEquiv x' = 0
      rw [hfaith x' hx' hz, map_zero]
  hyperfinite := by
    obtain ⟨S, ⟨hchain⟩, hgen⟩ := h.hyperfinite
    refine ⟨mapAlg U S, ⟨isMatricialChain_mapAlg U hchain⟩, ?_⟩
    rw [← mapVN_vonNeumannGenerated, hgen]
  infinite N := by
    obtain ⟨k, S, hNk, hSM, ⟨e⟩⟩ := h.infinite N
    refine ⟨k, mapAlg U S, hNk, ?_, ⟨(mapAlgEquiv U S).symm.trans e⟩⟩
    rw [coe_mapAlg, coe_mapVN]
    exact Set.image_mono hSM

/-- Transport of the P58 finite mixed matrix-factor data along a
`*`-isomorphism. -/
noncomputable def isMixedMatrixFactor_of_starAlgEquiv {B C : Type*}
    [Semiring B] [StarRing B] [Algebra ℂ B] [Semiring C] [StarRing C] [Algebra ℂ C]
    {k : ℕ} {tau : B →ₗ[ℂ] ℂ} {sigma : C →ₗ[ℂ] ℂ} (e : C ≃⋆ₐ[ℂ] B)
    (hstate : ∀ x : C, sigma x = tau (e x)) (hB : IsMixedMatrixFactor B k tau) :
    IsMixedMatrixFactor C k sigma where
  equiv := e.trans hB.equiv
  pos := hB.pos
  trace_eq x := by rw [hstate x]; exact hB.trace_eq (e x)
  tracial := by
    have hs : sigma = StabilizerHyperfinite.pullback e tau := LinearMap.ext hstate
    rw [hs]
    exact StabilizerHyperfinite.isAlgebraicTracialState_pullback e tau hB.tracial
  faithful := by
    intro x hx
    rw [hstate (star x * x), map_mul e, map_star e] at hx
    have hex := hB.faithful (e x) hx
    have hx0 : e x = e 0 := by rw [hex, map_zero]
    exact e.injective hx0
  center := by
    intro x hx
    obtain ⟨c, hc⟩ := hB.center (e x) (fun y => by
      have hxy := hx (e.symm y)
      have h2 : e (x * e.symm y) = e (e.symm y * x) := by rw [hxy]
      rw [map_mul, map_mul, e.apply_symm_apply] at h2
      exact h2)
    refine ⟨c, ?_⟩
    have hex : e x = e (algebraMap ℂ C c) := by rw [hc, AlgHomClass.commutes]
    exact e.injective hex

end SpatialTransport

/-! ## 5. The mixed GNS bridge -/

namespace LocalHyperbolicAlpha

namespace AlphaData

open CoherentLocalHyperbolic UHFBridge AristotleCandidates.ProductGNSTensor

variable {L I : Type*} [LinearOrder I] {A : AlphaData L I}

/-- The P59A product datum of the concrete source representation `R`. -/
noncomputable abbrev SourceConcreteRep.data (R : A.SourceConcreteRep) : ProductGNSData.{0} :=
  R.concreteProductGNSData

/-- The mixed GNS space of the P59A product datum. -/
noncomputable abbrev SourceConcreteRep.mixedGNS (R : A.SourceConcreteRep) : Type :=
  (R.data).MixedGNS

/-- The represented mixed coordinate algebra on the mixed GNS space. -/
noncomputable def SourceConcreteRep.mixedRepAlg (R : A.SourceConcreteRep) :
    StarSubalgebra ℂ (R.mixedGNS →L[ℂ] R.mixedGNS) :=
  ((R.data).mixedRep).range

/-- The von Neumann algebra generated by the represented mixed coordinate
algebra: the mixed factor of the P59A datum. -/
noncomputable def SourceConcreteRep.mixedRepVonNeumann (R : A.SourceConcreteRep) :
    VonNeumannAlgebra R.mixedGNS :=
  StarSubalgebra.vonNeumannGenerated R.mixedRepAlg

namespace MixedEnumeration

variable (N : A.MixedEnumeration) (R : A.SourceConcreteRep)

/-- The enumeration exhausts the mixed (unselected) coordinates. -/
def Exhaustive : Prop := ∀ i : I, i ∉ A.family.selected → ∃ j, N.coord j = i

theorem mixedState_apply (b : R.mixedCStar) : (R.data).mixedState b = R.mixedMarginal b := rfl

/-- The linear map of the UHF trace pre-Hilbert space into the mixed pre-GNS
space. -/
noncomputable def preMap : UHFL2 →ₗ[ℂ] (R.data).mixedState.PreGNS :=
  (((R.data).mixedState.toPreGNS.comp (N.mixedHom R).toLinearMap)).comp
    (ofL2 : UHFL2 ≃ₗ[ℂ] QubitUHFAlgebra).toLinearMap

@[simp] theorem preMap_apply (w : UHFL2) :
    N.preMap R w = (R.data).mixedState.toPreGNS (N.mixedHom R (ofL2 w)) := rfl

/-- **The bridge is isometric for the two GNS inner products.** -/
theorem inner_preMap (w w' : UHFL2) :
    ⟪N.preMap R w, N.preMap R w'⟫_ℂ = ⟪w, w'⟫_ℂ := by
  sorry

theorem norm_preMap (w : UHFL2) : ‖N.preMap R w‖ = ‖w‖ := by
  sorry

/-- The bridge as a bounded map into the completed mixed GNS space. -/
noncomputable def preCLM : UHFL2 →L[ℂ] R.mixedGNS :=
  (coeCLM ((R.data).mixedState.PreGNS)).comp
    (LinearMap.mkContinuous (N.preMap R) 1 (fun w => by rw [N.norm_preMap R w, one_mul]))

@[simp] theorem preCLM_apply (w : UHFL2) :
    N.preCLM R w = ((N.preMap R w : (R.data).mixedState.PreGNS) : R.mixedGNS) := rfl

/-- The bridge extended to the UHF GNS Hilbert space. -/
noncomputable def gnsCLM : UHFGNS →L[ℂ] R.mixedGNS := clmExtend (N.preCLM R)

@[simp] theorem gnsCLM_coe (w : UHFL2) :
    N.gnsCLM R (w : UHFGNS) = ((N.preMap R w : (R.data).mixedState.PreGNS) : R.mixedGNS) :=
  clmExtend_coe _ _

theorem norm_gnsCLM (x : UHFGNS) : ‖N.gnsCLM R x‖ = ‖x‖ := by
  sorry

theorem denseRange_gnsCLM (hsurj : N.Exhaustive) : DenseRange (N.gnsCLM R) := by
  sorry

theorem surjective_gnsCLM (hsurj : N.Exhaustive) :
    Function.Surjective (N.gnsCLM R) := by
  sorry

/-- **The mixed GNS unitary.**  The trace GNS space of P58's dyadic UHF algebra
is unitarily isomorphic to the mixed GNS space of the P59A product datum. -/
noncomputable def gnsUnitary (hsurj : N.Exhaustive) : UHFGNS ≃ₗᵢ[ℂ] R.mixedGNS :=
  LinearIsometryEquiv.ofSurjective
    ⟨(N.gnsCLM R : UHFGNS →ₗ[ℂ] R.mixedGNS), N.norm_gnsCLM R⟩ (N.surjective_gnsCLM R hsurj)

@[simp] theorem gnsUnitary_apply (hsurj : N.Exhaustive) (x : UHFGNS) :
    N.gnsUnitary R hsurj x = N.gnsCLM R x := rfl

/-- **The intertwining identity.**  The mixed GNS unitary carries P58's UHF
reference representation to the P59A mixed GNS representation composed with the
algebra bridge. -/
theorem gnsUnitary_intertwine (hsurj : N.Exhaustive) (z : QubitUHFAlgebra) (x : UHFGNS) :
    N.gnsUnitary R hsurj (uhfRep z x) =
      (R.data).mixedRep (N.mixedHom R z) (N.gnsUnitary R hsurj x) := by
  sorry

/-- **The spatial identification of the two representations.** -/
theorem conj_uhfRep (hsurj : N.Exhaustive) (z : QubitUHFAlgebra) :
    (N.gnsUnitary R hsurj).conjStarAlgEquiv (uhfRep z) = (R.data).mixedRep (N.mixedHom R z) := by
  sorry

/-! ### Transport of the P58 weak-closure conclusions -/

/-- **The weak closures agree.**  Conjugation by the mixed GNS unitary carries
P58's `mixedVonNeumann` exactly onto the von Neumann algebra generated by the
P59A mixed GNS representation. -/
theorem mapVN_mixedVonNeumann (hsurj : N.Exhaustive) :
    SpatialTransport.mapVN (N.gnsUnitary R hsurj) mixedVonNeumann = R.mixedRepVonNeumann := by
  sorry

/-- **P59B, main transport.**  Under P58's own explicitly named weak-closure
premises, the von Neumann algebra generated by the mixed GNS representation of
the P59A product datum is a hyperfinite finite-factor model in the sense of
P58. -/
theorem mixedRepVonNeumann_isHyperfiniteFiniteFactor (hsurj : N.Exhaustive)
    (h : MixedWeakClosurePremises) :
    IsHyperfiniteFiniteFactorModel R.mixedRepVonNeumann := by
  rw [← N.mapVN_mixedVonNeumann R hsurj]
  exact SpatialTransport.isHyperfiniteFiniteFactorModel_mapVN _
    (mixedVonNeumann_isHyperfiniteFiniteFactor h)

end MixedEnumeration

/-! ## 6. The finite mixed branch -/

namespace MixedRegister

variable {k : ℕ} (E : A.MixedRegister k) (R : A.SourceConcreteRep)

/-- The register exhausts the mixed (unselected) coordinates. -/
def Exhaustive : Prop := ∀ i : I, i ∉ A.family.selected → ∃ j, E.coord j = i

theorem range_stageHom_eq (hsurj : E.Exhaustive) {b : R.sourceCStar} (hb : b ∈ R.mixedCStar) :
    b ∈ Set.range (E.stageHom R) := by
  classical
  set Lm := (qubitWordBasis k).constr ℂ (fun p : Reg (Fin k) × Reg (Fin k) => E.wordOp R p.1 p.2)
    with hLm
  have hrange : LinearMap.range Lm =
      Submodule.span ℂ (Set.range fun p : Reg (Fin k) × Reg (Fin k) => E.wordOp R p.1 p.2) :=
    Module.Basis.constr_range (qubitWordBasis k) ℂ
  have hclosed : IsClosed ((LinearMap.range Lm : Submodule ℂ R.sourceCStar) :
      Set R.sourceCStar) := by
    rw [hrange]
    haveI := FiniteDimensional.span_of_finite ℂ
      (Set.finite_range fun p : Reg (Fin k) × Reg (Fin k) => E.wordOp R p.1 p.2)
    exact Submodule.closed_of_finiteDimensional _
  have hgen : R.labelWordSet A.IsMixedLabel ⊆
      ((LinearMap.range Lm : Submodule ℂ R.sourceCStar) : Set R.sourceCStar) := by
    rintro T ⟨n, v, hv, rfl⟩
    have hcov : ∀ p : I ⊕ I, (v : PauliCoordinateLabels I) p ≠ 0 → ∃ j, site p = E.coord j := by
      intro p hp
      obtain ⟨j, hj⟩ := hsurj (site p) (hv p hp)
      exact ⟨j, hj.symm⟩
    obtain ⟨z, hz⟩ := E.wordElt_mem_range_stageHom R hcov
    exact ⟨z, hz⟩
  have hsub := R.labelCStarAlg_subset_of_closed (Q := A.IsMixedLabel) A.isMixedLabel_zero
    (fun _ _ hc hd => A.isMixedLabel_add hc hd) hclosed hgen
  exact hsub hb

/-- **The finite mixed branch.**  If the register exhausts the mixed
coordinates, the P59A mixed coordinate C⋆-algebra *is* the dyadic stage of `k`
qubits. -/
noncomputable def mixedCStarEquiv (hsurj : E.Exhaustive) :
    QubitTensorPower k ≃⋆ₐ[ℂ] R.mixedCStar :=
  StarAlgEquiv.ofBijective
    ((E.stageHom R).codRestrict R.mixedCStar (E.stageHom_mem_mixedCStar R))
    ⟨(StarAlgHom.injective_codRestrict _ _ _).mpr (E.stageHom_injective R),
      by
        rintro ⟨b, hb⟩
        obtain ⟨z, hz⟩ := E.range_stageHom_eq R hsurj hb
        exact ⟨z, Subtype.ext hz⟩⟩

@[simp] theorem coe_mixedCStarEquiv (hsurj : E.Exhaustive) (x : QubitTensorPower k) :
    ((E.mixedCStarEquiv R hsurj x : R.mixedCStar) : R.sourceCStar) = E.stageHom R x := rfl

theorem mixedMarginal_mixedCStarEquiv (hsurj : E.Exhaustive) (x : QubitTensorPower k) :
    R.mixedMarginal (E.mixedCStarEquiv R hsurj x) = qubitTensorTrace k x := by
  rw [R.mixedMarginal_apply, coe_mixedCStarEquiv, E.totalState_stageHom]

/-- **P59B, finite branch.**  With finitely many mixed coordinates the P59A
mixed component is the matrix factor `M_{2^k}(ℂ)` with its normalized trace, in
the exact sense of P58's `IsMixedMatrixFactor`. -/
noncomputable def mixedCStar_isMixedMatrixFactor (hsurj : E.Exhaustive) :
    IsMixedMatrixFactor R.mixedCStar (2 ^ k) R.mixedMarginal :=
  SpatialTransport.isMixedMatrixFactor_of_starAlgEquiv
    (B := QubitTensorPower k) (tau := qubitTensorTrace k)
    (C := R.mixedCStar) (sigma := R.mixedMarginal)
    (E.mixedCStarEquiv R hsurj).symm
    (fun x => by
      conv_lhs => rw [← StarAlgEquiv.apply_symm_apply (E.mixedCStarEquiv R hsurj) x]
      exact E.mixedMarginal_mixedCStarEquiv R hsurj _)
    (qubitTensorPower_isMixedMatrixFactor k)

end MixedRegister

/-! ## 7. Existence of the coordinate-index identification -/

section Existence

variable (A)

/-- The coordinate index type of the local-hyperbolic model is countable: it is
exhausted by the finite coordinate blocks. -/
theorem countable_coordinates (A : AlphaData L I) : Countable I := by
  have h : (Set.univ : Set I) = ⋃ n : ℕ, ((A.blockFinset n : Finset I) : Set I) := by
    ext i
    simp only [Set.mem_univ, Set.mem_iUnion, Finset.mem_coe, true_iff]
    exact ⟨A.birth i, (A.mem_blockFinset _ i).2 (A.mem_coordinateBlock_birth i)⟩
  rw [← Set.countable_univ_iff, h]
  exact Set.countable_iUnion (fun n => (A.blockFinset n).countable_toSet)

/-- In the infinite mixed branch the mixed coordinates admit an exhaustive
enumeration. -/
theorem exists_mixedEnumeration [Infinite {i : I // i ∉ A.family.selected}] :
    ∃ N : A.MixedEnumeration, N.Exhaustive := by
  haveI : Countable I := countable_coordinates A
  haveI : Countable {i : I // i ∉ A.family.selected} := inferInstance
  obtain ⟨d⟩ := (nonempty_denumerable_iff (α := {i : I // i ∉ A.family.selected})).mpr
    ⟨inferInstance, inferInstance⟩
  letI := d
  set e : ℕ ≃ {i : I // i ∉ A.family.selected} :=
    (Denumerable.eqv {i : I // i ∉ A.family.selected}).symm with he
  refine ⟨{ coord := fun j => (e j : I)
            coord_injective := ?_
            coord_not_selected := fun j => (e j).2 }, ?_⟩
  · intro j1 j2 hj
    exact e.injective (Subtype.ext hj)
  · intro i hi
    exact ⟨e.symm ⟨i, hi⟩, by simp⟩

/-- In the finite mixed branch the mixed coordinates admit an exhaustive finite
register. -/
theorem exists_mixedRegister [Finite {i : I // i ∉ A.family.selected}] :
    ∃ (k : ℕ) (E : A.MixedRegister k), E.Exhaustive := by
  classical
  set k := Nat.card {i : I // i ∉ A.family.selected} with hk
  set e : Fin k ≃ {i : I // i ∉ A.family.selected} :=
    (Finite.equivFin {i : I // i ∉ A.family.selected}).symm with he
  refine ⟨k, { coord := fun j => (e j : I)
               coord_injective := fun j1 j2 hj => e.injective (Subtype.ext hj)
               coord_not_selected := fun j => (e j).2
               stage := Finset.univ.sup (fun j : Fin k => A.birth (e j : I))
               coord_mem_block := ?_ }, ?_⟩
  · intro j
    exact A.mem_coordinateBlock_of_birth_le
      (Finset.le_sup (f := fun j : Fin k => A.birth (e j : I)) (Finset.mem_univ j))
  · intro i hi
    exact ⟨e.symm ⟨i, hi⟩, by simp⟩


end Existence

end AlphaData

end LocalHyperbolicAlpha

end StabilizerHyperfinite

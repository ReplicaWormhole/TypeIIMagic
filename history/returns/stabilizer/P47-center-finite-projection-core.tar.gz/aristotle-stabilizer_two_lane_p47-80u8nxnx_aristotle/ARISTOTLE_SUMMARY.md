# Summary of changes for run 51855055-543c-447d-84aa-1fabba7f918b
## P47 — center and finite-projection core (Lane G foundation, infrastructure only)

Created exactly one new file, `AristotleCandidates/CenterFiniteProjectionCore.lean` (≈680 lines), starting from `Mathlib.Analysis.VonNeumannAlgebra.Basic` and `AristotleCandidates.BicommutantVonNeumannCore`. No other file was added or modified.

**Verification.** `lake build AristotleCandidates.CenterFiniteProjectionCore` succeeds with no errors and no warnings. The file contains no `sorry`, `admit`, `axiom`, `opaque`, `unsafe`, or `implemented_by`. Axiom checks on the main results (`IsFull.mul_ne_zero`, `IsFiniteProjection.mul_central`, `MvNLe.trans`, `MvNEquiv.add`, `IsCentralSupport.unique`, `center`, `corner`) report only `propext`, `Classical.choice`, `Quot.sound`.

### 1. Definitions introduced (all for Mathlib's concrete `M : VonNeumannAlgebra H`)
- `VonNeumannAlgebra.center` — the center `M ∩ M'`, itself a concrete von Neumann algebra (built as the commutant of `M ∪ M'`, so the double-commutant condition is automatic).
- `IsProjection`, `IsCentralProjection` — projections of `M` and central projections; Mathlib's `IsStarProjection` (self-adjoint idempotent) is reused rather than redefined.
- `ProjLe p q := p * q = p ∧ q * p = p` — the projection order, purely algebraic.
- `MvNEquiv`, `MvNLe` — Murray–von Neumann equivalence and subequivalence via a partial isometry in `M`.
- `IsFiniteProjection` — a projection not equivalent to a proper subprojection of itself.
- `corner M hp` — the compression `p M p` for self-adjoint `p`, as a `NonUnitalStarSubalgebra ℂ (H →L[ℂ] H)`.
- `IsCentralSupport M p z` — central support as a *predicate* (smallest central projection acting as identity on `p`), deliberately avoiding any completeness of the projection lattice; `IsFull M p := IsCentralSupport M p 1`.

### 2. Proved algebraic lemmas (no analytic input beyond the C*-norm identity noted in 3)
- Center: `coe_center` (`center = M ∩ M'`), `mem_center_iff`, `mem_of_mem_center`, `center_commute`, `center_le`, `center_le_commutant`, `center_commutant`.
- Projections: `isProjection_zero/one`, `IsProjection.one_sub`, `IsProjection.sub` (`q − p` for `p ≤ q`), `IsCentralProjection.{isProjection, commute, one_sub, mul}`, `isCentralProjection_zero/one`.
- Order: `ProjLe.{refl, trans, antisymm, mul_left, mul_right, eq_zero_of_le_zero}`, `zero_projLe`, `projLe_one`, `projLe_of_mul_eq_left/right` (one equation suffices for star projections).
- Compression: `IsCentralProjection.mul_isProjection`, `mul_projLe_left`, `mul_projLe_right`, `central_mul_mul_central` (multiplicativity of `x ↦ z·x`), `central_corner_eq_image` (`zMz = z·M`).
- Comparison: `MvNEquiv.{refl, symm, trans, isProjection_left, isProjection_right, left_eq_zero, right_eq_zero, add}` (orthogonal additivity), `conj_isProjection_of_projLe` (transport of a subprojection by a partial isometry), `MvNLe.{refl, of_projLe, of_mvNEquiv, trans}`.
- Finiteness: `isFiniteProjection_zero`, `IsFiniteProjection.isProjection`, and the compression lemma `IsFiniteProjection.mul_central` (a central compression of a finite projection is finite).
- Corners: `mem_corner_iff`, `corner_subset`, `mul_mul_mem_corner`, `corner_eq_image` (`corner = { p x p : x ∈ M }`), `corner_mul_left/right` (`p` is a unit for its corner), `corner_mono`, `corner_zero`, `mem_corner_one`.
- Central support and fullness: `IsCentralSupport.{isCentralProjection, mul_eq, projLe, unique}`; **`IsFull.mul_ne_zero`** — the required central-intersection implication: a full projection meets every nonzero central projection nontrivially (`z ≠ 0 → z·p ≠ 0`); its converse `isFull_of_forall_central` and the equivalence `isFull_iff_forall_central`; `IsFull.exists_nonzero_projection` (`z·p` is a nonzero projection dominated by `z` and by `p`); sanity checks `isFull_one`, `isCentralSupport_zero`.

### 3. Algebraic vs. analytic status
Everything above is algebraic. The single non-algebraic input is the C*-norm identity used once, in `mul_star_mul_self_eq_self` (`star v * v` idempotent ⇒ `v * (star v * v) = v`) via `CStarRing.star_mul_self_eq_zero_iff`, together with its mirror `star_mul_self_mul_eq_self`; the results depending on it are `MvNEquiv.isProjection_right`, `MvNEquiv.add`, `MvNLe.trans`, and `IsFiniteProjection.mul_central`. This is a norm identity, not an operator-topology, normality, or density statement. Nothing about strong/weak closures, normal states or weights, semifiniteness, direct integrals, or factor type is used or asserted; the double commutant theorem remains unavailable at the pinned Mathlib commit and is not assumed.

### 4. Plan alignment
Lane G foundation packet with no predecessors; it uses only Mathlib and the already-integrated `BicommutantVonNeumannCore`, and imports nothing from P48–P61. No forbidden downstream claim appears: there is no projection tower, no corner trace or state, no global weight, no fullness assertion about the manuscript projection, and no type-III exclusion — neither as a theorem nor as a structure field. The generic algebraic ingredients (`IsFiniteProjection.mul_central`, `IsFull.mul_ne_zero`) are stated separately and are *not* combined into the Lane-G/P51 conclusion.

### 5. Remaining obstructions (not addressed here, by design)
Existence of central supports as a construction (needs completeness of the projection lattice), comparison theory proper (the comparison theorem / polar decomposition of projections), and every normality/topology fact remain open in the pinned Mathlib and are left to later packets.

All work is committed and pushed.
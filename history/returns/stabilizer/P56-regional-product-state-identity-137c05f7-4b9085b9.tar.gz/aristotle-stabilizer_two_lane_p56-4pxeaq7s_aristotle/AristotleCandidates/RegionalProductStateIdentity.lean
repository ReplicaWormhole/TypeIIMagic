import AristotleCandidates.RegionalConcreteCStarAlpha
import Formalization.FinitePureMixedQubitState

/-!
# P56 — the regional/product-state identity

**Context declaration.**  Source basis: `main.tex:1915-1969` (the state
`\tilde\omega = \omega_S \circ \alpha` and its identification with the
pure/mixed product state `\bigotimes_{i\in F\cap P}|0\rangle\langle 0|\otimes
\bigotimes_{j\in F\setminus P}\mathbb 1_j/2`, "checked on Pauli words, which
form a basis of the operators").

## Plan alignment

* Package `P56`, lane `H`; predecessor `P55D`
  (`AristotleCandidates.RegionalConcreteCStarAlpha`), integrated and audited,
  together with the checked pure/mixed one-qubit expectations of
  `Formalization.FinitePureMixedQubitState`.
* Gate discharged: the equality of the regional stabilizer state pulled back by
  the exact P55D `alpha` with the pure/mixed product state — first on finite
  Pauli words, then on the concrete C⋆-algebra by density and continuity.
* Forbidden downstream claims, none of which is made here: no GNS tensor
  splitting, no von Neumann spatial tensor product, no factorhood, no trivial
  centre, and no trace or weight classification.

## What is constructed and proved

For every `A : AlphaData L I` of P53:

1. `allowedLabels`, the manuscript's selection rule on coordinate Pauli words
   (no `X` exponent, every `Z` exponent on a selected coordinate `i ∈ P`), and
   `stabilizerLabels`, the local stabilizer group `W_Γ`, proved equal to
   `span_{F₂} {z i : i ∈ P}`, together with the **stabilizer membership
   criterion** `coordinateMap_mem_stabilizerLabels_iff`.
2. `productExpectation`, the pure/mixed product-state expectation of a
   coordinate Pauli word, defined as the finite product of the *checked*
   one-qubit expectations `singleQubitPureExpectation` (on `i ∈ P`) and
   `singleQubitMixedExpectation` (on `i ∉ P`) of
   `Formalization.FinitePureMixedQubitState`, and proved equal to the indicator
   of `allowedLabels`.
3. `sourceProductState`, the pure/mixed product state on the algebraic
   quasi-local Pauli algebra, and `regionalStabilizerState`, the regional
   stabilizer state on the algebraic regional algebra, both built from
   compatible finite-stage functionals; both are unital.
4. **The finite-word identity** `regionalStabilizerState_alpha_word` and its
   consequence on the whole algebraic limit `regionalStabilizerState_alpha`:
   `ω_S ∘ α = ω_prod`.
5. The stabilizer-character package `stabilizerElement`, `..._mul`,
   `..._star`, `regionalStabilizerState_stabilizerElement`: the images `α(O)` of
   allowed words form a group of self-adjoint elements with expectation `1`,
   and every regional Pauli word outside `W_Γ` is annihilated.
6. **The continuous state identity** `SourceConcreteRep.cstarState_identity`
   (and its branch form `regionalCStarAlpha_state_identity`): *any* two
   continuous functionals on the P55C concrete C⋆-algebras restricting to the
   two algebraic states on the dense algebraic images satisfy `g ∘ alpha = f`
   for the exact P55D C⋆ `alpha`.  Each is unique
   (`cstarSourceState_unique`, `cstarRegionalState_unique`).
7. Under the single auxiliary assumption below, the two continuous functionals
   are *constructed* (`cstarProductState`, `cstarRegionalState`) by a proved
   dense-extension theorem for bounded linear functionals, and the final
   equality is `cstarRegionalState_cstarAlpha`.

## Auxiliary assumptions

Exactly one, exposed as the explicit structure
`AlphaData.SourceConcreteRep.ProductStateBound`: a norm bound
`‖ω_prod z‖ ≤ C ‖R.sourceEmbedding z‖` for the algebraic product state with
respect to the concrete C⋆-norm of P55C.  It is used *only* for the existence
of the continuous extensions in §8; the continuous state identity itself
(`cstarState_identity`) assumes nothing beyond continuity of the two given
functionals.  Mathematically this bound holds with `C = 1`, because the
finite-stage functionals are pure/mixed density-matrix expectations and a state
on a C⋆-algebra is norm-decreasing; that standard C⋆-fact is *not* formalized
here (it needs finite-dimensional positive square roots and the isometry of
injective star homomorphisms), so it is carried as a named premise rather than
claimed.  No positivity claim is made for either functional in this module: the
results above concern unitality and the word values only.
-/

namespace StabilizerHyperfinite

namespace LocalHyperbolicAlpha

open CoherentLocalHyperbolic

/-! ## 0. Extension of a bounded linear functional along a dense isometric image

This is the analytic tool used in §9: a linear functional on a dense subspace
which is bounded for the ambient norm has a unique continuous extension.  It is
the functional analogue of `Formalization.ConcreteCStarCompletion`'s extension
of star-algebra homomorphisms, and it is proved, not assumed. -/

section DenseFunctional

variable {E X : Type*} [NormedAddCommGroup E] [NormedSpace ℂ E]
  [NormedAddCommGroup X] [NormedSpace ℂ X]
  {i : E →ₗ[ℂ] X} {f : E →ₗ[ℂ] ℂ}

/-- The extension of a linear functional along an isometric linear map with
dense range. -/
noncomputable def extendFunctional (hi : Isometry i) (hd : DenseRange i) (f : E →ₗ[ℂ] ℂ) :
    X → ℂ :=
  IsDenseInducing.extend (hi.isUniformInducing.isDenseInducing hd) f

/-- Two continuous functionals which agree on a dense isometric image agree. -/
theorem eq_of_denseRange (hd : DenseRange i) (g h : X →L[ℂ] ℂ)
    (hgh : ∀ a, g (i a) = h (i a)) : g = h := by
  refine ContinuousLinearMap.ext (fun x => ?_)
  have hfun : (g : X → ℂ) = h :=
    Continuous.ext_on hd g.continuous h.continuous (by rintro _ ⟨a, rfl⟩; exact hgh a)
  exact congrFun hfun x

variable (hi : Isometry i) (hd : DenseRange i) (hf : UniformContinuous f)

include hf in
theorem extendFunctional_apply (a : E) : extendFunctional hi hd f (i a) = f a :=
  uniformly_extend_of_ind hi.isUniformInducing hd hf a

include hf in
theorem continuous_extendFunctional : Continuous (extendFunctional hi hd f) :=
  (uniformContinuous_uniformly_extend hi.isUniformInducing hd hf).continuous

include hf in
theorem extendFunctional_add (x y : X) :
    extendFunctional hi hd f (x + y) =
      extendFunctional hi hd f x + extendFunctional hi hd f y := by
  have hc := continuous_extendFunctional hi hd hf
  have hfun : (fun p : X × X => extendFunctional hi hd f (p.1 + p.2)) =
      fun p : X × X => extendFunctional hi hd f p.1 + extendFunctional hi hd f p.2 := by
    refine Continuous.ext_on (hd.prodMap hd) (hc.comp (continuous_fst.add continuous_snd))
      ((hc.comp continuous_fst).add (hc.comp continuous_snd)) ?_
    rintro _ ⟨⟨a, b⟩, rfl⟩
    show extendFunctional hi hd f (i a + i b) =
      extendFunctional hi hd f (i a) + extendFunctional hi hd f (i b)
    rw [← map_add i, extendFunctional_apply hi hd hf, extendFunctional_apply hi hd hf,
      extendFunctional_apply hi hd hf, map_add f]
  exact congrFun hfun (x, y)

include hf in
theorem extendFunctional_smul (c : ℂ) (x : X) :
    extendFunctional hi hd f (c • x) = c • extendFunctional hi hd f x := by
  have hc := continuous_extendFunctional hi hd hf
  have hfun : (fun x : X => extendFunctional hi hd f (c • x)) =
      fun x : X => c • extendFunctional hi hd f x := by
    refine Continuous.ext_on hd (hc.comp (continuous_const_smul c)) (hc.const_smul c) ?_
    rintro _ ⟨a, rfl⟩
    show extendFunctional hi hd f (c • i a) = c • extendFunctional hi hd f (i a)
    rw [← map_smul i, extendFunctional_apply hi hd hf, extendFunctional_apply hi hd hf,
      map_smul f]
  exact congrFun hfun x

/-- **The continuous extension**, as a continuous linear functional. -/
noncomputable def extendCLM (hi : Isometry i) (hd : DenseRange i) {f : E →ₗ[ℂ] ℂ}
    (hf : UniformContinuous f) : X →L[ℂ] ℂ where
  toFun := extendFunctional hi hd f
  map_add' := extendFunctional_add hi hd hf
  map_smul' c x := extendFunctional_smul hi hd hf c x
  cont := continuous_extendFunctional hi hd hf

@[simp] theorem extendCLM_apply (a : E) : extendCLM hi hd hf (i a) = f a :=
  extendFunctional_apply hi hd hf a

/-- **Uniqueness of the continuous extension.** -/
theorem eq_extendCLM (g : X →L[ℂ] ℂ) (hg : ∀ a, g (i a) = f a) : g = extendCLM hi hd hf := by
  refine ContinuousLinearMap.ext (fun x => ?_)
  have hfun : (g : X → ℂ) = extendCLM hi hd hf := by
    refine Continuous.ext_on hd g.continuous (extendCLM hi hd hf).continuous ?_
    rintro _ ⟨a, rfl⟩
    rw [hg a, extendCLM_apply hi hd hf a]
  exact congrFun hfun x

end DenseFunctional

namespace AlphaData

variable {L I : Type*} [LinearOrder I] (A : AlphaData L I)

/-! ## 1. The allowed source labels and the regional stabilizer labels -/

/-- **The allowed source Pauli labels.**  The manuscript's condition on a
coordinate Pauli word `O = \prod_i X_i^{a_i} Z_i^{b_i}`: no `X` exponent at all,
and every `Z` exponent carried by a selected (`P`) coordinate.  In the
coordinate label group `(I ⊕ I) →₀ F₂` the `Z` exponents sit on `Sum.inl` and
the `X` exponents on `Sum.inr`. -/
def allowedLabels : Submodule PauliBit (PauliCoordinateLabels I) :=
  Finsupp.supported PauliBit PauliBit (Sum.inl '' A.family.selected)

theorem mem_allowedLabels_iff (c : PauliCoordinateLabels I) :
    c ∈ A.allowedLabels ↔
      (∀ i : I, c (Sum.inr i) = 0) ∧ ∀ i : I, c (Sum.inl i) ≠ 0 → i ∈ A.family.selected := by
  classical
  rw [allowedLabels, Finsupp.mem_supported]
  constructor
  · intro h
    refine ⟨fun i => ?_, fun i hi => ?_⟩
    · by_contra hne
      obtain ⟨j, hj, hji⟩ := h (Finsupp.mem_support_iff.mpr hne)
      exact Sum.inl_ne_inr hji
    · obtain ⟨j, hj, hji⟩ := h (Finsupp.mem_support_iff.mpr hi)
      rw [← Sum.inl.injEq j i |>.mp hji]
      exact hj
  · rintro ⟨hx, hz⟩ p hp
    rw [Finset.mem_coe, Finsupp.mem_support_iff] at hp
    rcases p with i | i
    · exact ⟨i, hz i hp, rfl⟩
    · exact absurd (hx i) hp

/-- **The regional stabilizer labels** `W_Γ`: the image of the allowed source
labels under the coordinate map, i.e. the `F₂`-span of `{z i : i ∈ P}`. -/
noncomputable def stabilizerLabels : Submodule PauliBit (PhaseSpace L) :=
  A.allowedLabels.map A.family.coordinateMap

/-- `W_Γ = span_{F₂} {z i : i ∈ P}`, the manuscript's description of the local
stabilizer group. -/
theorem stabilizerLabels_eq_span :
    A.stabilizerLabels = Submodule.span PauliBit (A.family.z '' A.family.selected) := by
  rw [stabilizerLabels, allowedLabels, Finsupp.supported_eq_span_single, Submodule.map_span]
  congr 1
  simp only [Set.image_image]
  exact Set.image_congr (fun i _ => A.family.coordinateMap_single_z i)

/-- **The stabilizer membership criterion.**  A coordinate word lands in the
regional stabilizer group exactly when it is an allowed word.  This is the
injectivity of the adapted coordinate map in the form used by the manuscript's
"the resulting operator will have a string that is [outside] `W_Γ`". -/
theorem coordinateMap_mem_stabilizerLabels_iff (c : PauliCoordinateLabels I) :
    A.family.coordinateMap c ∈ A.stabilizerLabels ↔ c ∈ A.allowedLabels := by
  constructor
  · rintro ⟨d, hd, hdc⟩
    rwa [A.family.coordinateMap_injective hdc] at hd
  · intro hc
    exact ⟨c, hc, rfl⟩

/-! ## 2. The pure/mixed product expectation of a coordinate Pauli word -/

/-- The one-qubit Pauli label carried by the coordinate `i` of a coordinate
Pauli word: the `X` exponent is the `Sum.inr` entry, the `Z` exponent the
`Sum.inl` entry. -/
def coordLabel (c : PauliCoordinateLabels I) (i : I) : SingleQubitLabel :=
  (c (Sum.inr i), c (Sum.inl i))

/-- **The one-qubit factor of the pure/mixed product state** at the coordinate
`i`: the checked zero-vector expectation `singleQubitPureExpectation` on a
selected (`i ∈ P`) coordinate, and the checked normalized-trace expectation
`singleQubitMixedExpectation` on an unselected one. -/
noncomputable def coordFactor (c : PauliCoordinateLabels I) (i : I) : ℂ := by
  classical
  exact if i ∈ A.family.selected then singleQubitPureExpectation (coordLabel c i)
    else singleQubitMixedExpectation (coordLabel c i)

theorem coordFactor_selected {c : PauliCoordinateLabels I} {i : I}
    (hi : i ∈ A.family.selected) :
    A.coordFactor c i = singleQubitPureExpectation (coordLabel c i) := by
  classical
  rw [coordFactor, if_pos hi]

theorem coordFactor_not_selected {c : PauliCoordinateLabels I} {i : I}
    (hi : i ∉ A.family.selected) :
    A.coordFactor c i = singleQubitMixedExpectation (coordLabel c i) := by
  classical
  rw [coordFactor, if_neg hi]

open scoped Classical in
/-- The finite set of coordinates touched by a coordinate Pauli word. -/
noncomputable def coordSupport' (c : PauliCoordinateLabels I) : Finset I :=
  c.support.image site

open scoped Classical in
theorem mem_coordSupport'_iff (c : PauliCoordinateLabels I) (i : I) :
    i ∈ coordSupport' (I := I) c ↔ c (Sum.inl i) ≠ 0 ∨ c (Sum.inr i) ≠ 0 := by
  classical
  rw [coordSupport', Finset.mem_image]
  constructor
  · rintro ⟨p, hp, rfl⟩
    rw [Finsupp.mem_support_iff] at hp
    rcases p with j | j
    · exact Or.inl hp
    · exact Or.inr hp
  · rintro (h | h)
    · exact ⟨Sum.inl i, Finsupp.mem_support_iff.mpr h, rfl⟩
    · exact ⟨Sum.inr i, Finsupp.mem_support_iff.mpr h, rfl⟩

open scoped Classical in
/-- **The pure/mixed product-state expectation of a coordinate Pauli word**
(`main.tex:1927-1931`): the finite product of the one-qubit expectations over
the coordinates touched by the word.  All other coordinates contribute the
factor `1`. -/
noncomputable def productExpectation (c : PauliCoordinateLabels I) : ℂ :=
  ∏ i ∈ coordSupport' (I := I) c, A.coordFactor c i

/-- **The manuscript's selection rule, positive half.**  The product-state
expectation of an allowed coordinate Pauli word — no `X` exponent, all `Z`
exponents on selected coordinates — is `1`. -/
theorem productExpectation_of_mem {c : PauliCoordinateLabels I} (hc : c ∈ A.allowedLabels) :
    A.productExpectation c = 1 := by
  classical
  · rw [productExpectation]
    obtain ⟨hx, hz⟩ := (A.mem_allowedLabels_iff c).mp hc
    refine Finset.prod_eq_one (fun i hi => ?_)
    have hisel : i ∈ A.family.selected := by
      rcases (mem_coordSupport'_iff c i).mp hi with h | h
      · exact hz i h
      · exact absurd (hx i) h
    rw [A.coordFactor_selected hisel, coordLabel, hx i]
    simp [singleQubitPureExpectation]

/-- **The manuscript's selection rule, vanishing half.**  Every coordinate
Pauli word which is not allowed has product-state expectation `0`. -/
theorem productExpectation_of_not_mem {c : PauliCoordinateLabels I}
    (hc : c ∉ A.allowedLabels) : A.productExpectation c = 0 := by
  classical
  · rw [productExpectation]
    have hex : ∃ i : I, A.coordFactor c i = 0 ∧ i ∈ coordSupport' (I := I) c := by
      by_contra hno
      push_neg at hno
      refine hc ((A.mem_allowedLabels_iff c).mpr ⟨fun i => ?_, fun i hi => ?_⟩)
      · by_contra hne
        have hmem : i ∈ coordSupport' (I := I) c :=
          (mem_coordSupport'_iff c i).mpr (Or.inr hne)
        have hzero : A.coordFactor c i = 0 := by
          by_cases hisel : i ∈ A.family.selected
          · rw [A.coordFactor_selected hisel, coordLabel]
            simp [singleQubitPureExpectation, hne]
          · rw [A.coordFactor_not_selected hisel, coordLabel]
            simp [singleQubitMixedExpectation, Prod.ext_iff, hne]
        exact (hno i hzero) hmem
      · by_contra hisel
        have hmem : i ∈ coordSupport' (I := I) c :=
          (mem_coordSupport'_iff c i).mpr (Or.inl hi)
        have hzero : A.coordFactor c i = 0 := by
          rw [A.coordFactor_not_selected hisel, coordLabel]
          simp [singleQubitMixedExpectation, Prod.ext_iff, hi]
        exact (hno i hzero) hmem
    obtain ⟨i, hzero, hmem⟩ := hex
    exact Finset.prod_eq_zero hmem hzero

open scoped Classical in
/-- **The manuscript's selection rule.**  The product-state expectation of a
coordinate Pauli word is the indicator of the allowed words. -/
theorem productExpectation_eq_indicator (c : PauliCoordinateLabels I) :
    A.productExpectation c = if c ∈ A.allowedLabels then 1 else 0 := by
  by_cases hc : c ∈ A.allowedLabels
  · rw [if_pos hc, A.productExpectation_of_mem hc]
  · rw [if_neg hc, A.productExpectation_of_not_mem hc]

@[simp] theorem productExpectation_zero : A.productExpectation 0 = 1 :=
  A.productExpectation_of_mem (Submodule.zero_mem _)

/-! ## 3. The product state on the algebraic source limit -/

/-- The stage-`n` product-state functional: the linear functional whose value on
each Pauli word is the pure/mixed product expectation of its label. -/
noncomputable def stageProductState (n : ℕ) : pauliAlgebra (A.sourceForm n) →ₗ[ℂ] ℂ :=
  (pauliWordBasis (A.sourceForm n)).constr ℂ
    (fun v => A.productExpectation (v : PauliCoordinateLabels I))

@[simp] theorem stageProductState_word (n : ℕ) (v : A.SourceLabel n) :
    A.stageProductState n (pauliWord (A.sourceForm n) v) =
      A.productExpectation (v : PauliCoordinateLabels I) := by
  rw [stageProductState, ← pauliWordBasis_apply, Module.Basis.constr_basis]

/-- The stage product states are compatible with the stage inclusions: the
manuscript's "for every local product `F ⋐ I`" coherence. -/
theorem stageProductState_connecting (n m : ℕ) (h : n ≤ m) (x : pauliAlgebra (A.sourceForm n)) :
    A.stageProductState m (A.sourceConnecting n m h x) = A.stageProductState n x := by
  refine pauliAlgebra_linear_ext (A.sourceForm n)
    ((A.stageProductState m).comp (A.sourceConnecting n m h).toAlgHom.toLinearMap)
    (A.stageProductState n) (fun v => ?_) x
  show A.stageProductState m (A.sourceConnecting n m h (pauliWord (A.sourceForm n) v)) = _
  rw [A.sourceConnecting_word, A.stageProductState_word, A.stageProductState_word,
    A.sourceIncl_coe]

/-- **The pure/mixed product state on the algebraic quasi-local Pauli algebra**
`𝒫I`: the coherent limit of the finite product states. -/
noncomputable def sourceProductState : A.SourceLimit →ₗ[ℂ] ℂ :=
  algebraicLimitTrace A.stageProductState A.stageProductState_connecting

@[simp] theorem sourceProductState_of (n : ℕ) (x : pauliAlgebra (A.sourceForm n)) :
    A.sourceProductState (A.sourceOf n x) = A.stageProductState n x :=
  algebraicLimitTrace_of (f := fun i j le => A.directedFamily.sourceConnecting i j le)
    A.stageProductState A.stageProductState_connecting n x

theorem sourceProductState_word (n : ℕ) (v : A.SourceLabel n) :
    A.sourceProductState (A.sourceOf n (pauliWord (A.sourceForm n) v)) =
      A.productExpectation (v : PauliCoordinateLabels I) := by
  rw [A.sourceProductState_of, A.stageProductState_word]

/-! ## 4. The regional stabilizer state on the algebraic regional limit -/

open scoped Classical in
/-- The allowed coordinate word labelling a regional stabilizer vector.  It is
unique when it exists, by injectivity of the adapted coordinate map. -/
noncomputable def stabPreimage (u : PhaseSpace L) : PauliCoordinateLabels I :=
  if h : ∃ c : PauliCoordinateLabels I, c ∈ A.allowedLabels ∧ A.family.coordinateMap c = u
    then h.choose else 0

theorem stabPreimage_coordinateMap {c : PauliCoordinateLabels I} (hc : c ∈ A.allowedLabels) :
    A.stabPreimage (A.family.coordinateMap c) = c := by
  classical
  have hex : ∃ d : PauliCoordinateLabels I,
      d ∈ A.allowedLabels ∧ A.family.coordinateMap d = A.family.coordinateMap c := ⟨c, hc, rfl⟩
  rw [stabPreimage, dif_pos hex]
  exact A.family.coordinateMap_injective hex.choose_spec.2

/-- **The stabilizer sign character.**  On a regional stabilizer vector
`u = \sum_{i} z_i` it is the inverse of the P53 calibration phase of the
coordinate word labelling `u`; this is exactly the sign convention that makes
the calibrated regional Pauli words `α(O)` the `+1`-eigenvalue stabilizer
elements. -/
noncomputable def stabSign (u : PhaseSpace L) : ℂ :=
  (zmodFourPhase (A.qGlobal (A.stabPreimage u)))⁻¹

theorem stabSign_coordinateMap {c : PauliCoordinateLabels I} (hc : c ∈ A.allowedLabels) :
    A.stabSign (A.family.coordinateMap c) = (zmodFourPhase (A.qGlobal c))⁻¹ := by
  rw [stabSign, A.stabPreimage_coordinateMap hc]

open scoped Classical in
/-- **The value of the regional stabilizer state on a regional Pauli word**: the
stabilizer sign on the stabilizer group `W_Γ`, and `0` on every Pauli string
outside it (`main.tex:1936-1943`). -/
noncomputable def regionalWordValue (u : PhaseSpace L) : ℂ :=
  if u ∈ A.stabilizerLabels then A.stabSign u else 0

theorem regionalWordValue_of_not_mem {u : PhaseSpace L} (hu : u ∉ A.stabilizerLabels) :
    A.regionalWordValue u = 0 := by
  classical
  rw [regionalWordValue, if_neg hu]

theorem regionalWordValue_coordinateMap {c : PauliCoordinateLabels I}
    (hc : c ∈ A.allowedLabels) :
    A.regionalWordValue (A.family.coordinateMap c) = (zmodFourPhase (A.qGlobal c))⁻¹ := by
  classical
  rw [regionalWordValue, if_pos ((A.coordinateMap_mem_stabilizerLabels_iff c).mpr hc),
    A.stabSign_coordinateMap hc]

/-- The stage-`n` regional stabilizer functional. -/
noncomputable def stageRegionalState (n : ℕ) : pauliAlgebra (A.targetForm n) →ₗ[ℂ] ℂ :=
  (pauliWordBasis (A.targetForm n)).constr ℂ (fun u => A.regionalWordValue (u : PhaseSpace L))

@[simp] theorem stageRegionalState_word (n : ℕ) (u : A.TargetLabel n) :
    A.stageRegionalState n (pauliWord (A.targetForm n) u) =
      A.regionalWordValue (u : PhaseSpace L) := by
  rw [stageRegionalState, ← pauliWordBasis_apply, Module.Basis.constr_basis]

theorem stageRegionalState_connecting (n m : ℕ) (h : n ≤ m) (y : pauliAlgebra (A.targetForm n)) :
    A.stageRegionalState m (A.targetConnecting n m h y) = A.stageRegionalState n y := by
  refine pauliAlgebra_linear_ext (A.targetForm n)
    ((A.stageRegionalState m).comp (A.targetConnecting n m h).toAlgHom.toLinearMap)
    (A.stageRegionalState n) (fun u => ?_) y
  show A.stageRegionalState m (A.targetConnecting n m h (pauliWord (A.targetForm n) u)) = _
  rw [A.targetConnecting_word, A.stageRegionalState_word, A.stageRegionalState_word,
    A.targetIncl_coe]

/-- **The regional stabilizer state on the algebraic regional algebra** `𝒜Γ`. -/
noncomputable def regionalStabilizerState : A.TargetLimit →ₗ[ℂ] ℂ :=
  algebraicLimitTrace A.stageRegionalState A.stageRegionalState_connecting

@[simp] theorem regionalStabilizerState_of (n : ℕ) (y : pauliAlgebra (A.targetForm n)) :
    A.regionalStabilizerState (A.targetOf n y) = A.stageRegionalState n y :=
  algebraicLimitTrace_of (f := fun i j le => A.directedFamily.targetConnecting i j le)
    A.stageRegionalState A.stageRegionalState_connecting n y

theorem regionalStabilizerState_word (n : ℕ) (u : A.TargetLabel n) :
    A.regionalStabilizerState (A.targetOf n (pauliWord (A.targetForm n) u)) =
      A.regionalWordValue (u : PhaseSpace L) := by
  rw [A.regionalStabilizerState_of, A.stageRegionalState_word]

/-- The regional stabilizer state annihilates every regional Pauli word whose
string lies outside the local stabilizer group `W_Γ`. -/
theorem regionalStabilizerState_word_of_not_mem (n : ℕ) {u : A.TargetLabel n}
    (hu : (u : PhaseSpace L) ∉ A.stabilizerLabels) :
    A.regionalStabilizerState (A.targetOf n (pauliWord (A.targetForm n) u)) = 0 := by
  rw [A.regionalStabilizerState_word, A.regionalWordValue_of_not_mem hu]

/-! ## 5. Unitality of the two algebraic functionals -/

theorem sourceOf_one (n : ℕ) : A.sourceOf n (1 : pauliAlgebra (A.sourceForm n)) = 1 :=
  (DirectLimit.one_def (G := A.directedFamily.limitData.Source)
    (f := fun i j h => A.directedFamily.limitData.sourceConnecting i j h) n).symm

theorem targetOf_one (n : ℕ) : A.targetOf n (1 : pauliAlgebra (A.targetForm n)) = 1 :=
  (DirectLimit.one_def (G := A.directedFamily.limitData.Target)
    (f := fun i j h => A.directedFamily.limitData.targetConnecting i j h) n).symm

theorem sourceOf_mul (n : ℕ) (x y : pauliAlgebra (A.sourceForm n)) :
    A.sourceOf n (x * y) = A.sourceOf n x * A.sourceOf n y :=
  (DirectLimit.mul_def (G := A.directedFamily.limitData.Source)
    (f := fun i j h => A.directedFamily.limitData.sourceConnecting i j h) n x y).symm

theorem sourceOf_star (n : ℕ) (x : pauliAlgebra (A.sourceForm n)) :
    A.sourceOf n (star x) = star (A.sourceOf n x) :=
  (star_of (f := fun i j h => A.directedFamily.limitData.sourceConnecting i j h) n x).symm

@[simp] theorem sourceProductState_one : A.sourceProductState 1 = 1 := by
  rw [← A.sourceOf_one 0, A.sourceProductState_of,
    show (1 : pauliAlgebra (A.sourceForm 0)) = pauliWord (A.sourceForm 0) 0 from
      (pauliWord_zero _).symm, A.stageProductState_word]
  simp

@[simp] theorem regionalStabilizerState_one : A.regionalStabilizerState 1 = 1 := by
  rw [← A.targetOf_one 0, A.regionalStabilizerState_of,
    show (1 : pauliAlgebra (A.targetForm 0)) = pauliWord (A.targetForm 0) 0 from
      (pauliWord_zero _).symm, A.stageRegionalState_word]
  have h0 : ((0 : A.TargetLabel 0) : PhaseSpace L) = A.family.coordinateMap 0 := by simp
  rw [h0, A.regionalWordValue_coordinateMap (Submodule.zero_mem _)]
  simp [A.qGlobal_zero]

/-! ## 6. The finite Pauli-word identity -/

/-- **The finite-word state identity** (`main.tex:1927-1943`).  On every finite
coordinate Pauli word, the regional stabilizer state pulled back by the exact
P53/P55D `alpha` is the pure/mixed product expectation of the word: it is `1`
when the word has no `X` exponent and all its `Z` exponents on selected
coordinates — equivalently, when the regional string lies in `W_Γ` — and `0`
otherwise. -/
theorem regionalStabilizerState_alpha_word (n : ℕ) (v : A.SourceLabel n) :
    A.regionalStabilizerState (A.alpha (A.sourceOf n (pauliWord (A.sourceForm n) v))) =
      A.productExpectation (v : PauliCoordinateLabels I) := by
  classical
  rw [A.alpha_word n v, A.regionalStabilizerState_of, map_smul, A.stageRegionalState_word,
    smul_eq_mul, A.stageLabelMap_coe]
  by_cases hv : (v : PauliCoordinateLabels I) ∈ A.allowedLabels
  · rw [A.regionalWordValue_coordinateMap hv, A.productExpectation_of_mem hv]
    exact mul_inv_cancel₀ (A.phase_ne_zero n v)
  · rw [A.regionalWordValue_of_not_mem
      (fun h => hv ((A.coordinateMap_mem_stabilizerLabels_iff _).mp h)),
      A.productExpectation_of_not_mem hv, mul_zero]

/-- **The algebraic state identity.**  On the whole algebraic quasi-local Pauli
algebra, `\tilde\omega = \omega_S \circ \alpha` is the pure/mixed product state.
This is the manuscript's "since the states agree on a basis of operators, they
are the same states", at the algebraic level. -/
theorem regionalStabilizerState_alpha (z : A.SourceLimit) :
    A.regionalStabilizerState (A.alpha z) = A.sourceProductState z := by
  refine sourceLimit_linear_ext A
    (A.regionalStabilizerState.comp A.alpha.toAlgEquiv.toLinearMap) A.sourceProductState
    (fun n v => ?_) z
  show A.regionalStabilizerState (A.alpha (A.sourceOf n (pauliWord (A.sourceForm n) v))) = _
  rw [A.regionalStabilizerState_alpha_word, A.sourceProductState_word]

/-- Composition form of the algebraic state identity. -/
theorem regionalStabilizerState_comp_alpha :
    A.regionalStabilizerState.comp A.alpha.toAlgEquiv.toLinearMap = A.sourceProductState :=
  LinearMap.ext A.regionalStabilizerState_alpha

/-- Inverse form of the algebraic state identity. -/
theorem sourceProductState_alpha_symm (y : A.TargetLimit) :
    A.sourceProductState (A.alpha.symm y) = A.regionalStabilizerState y := by
  rw [← A.regionalStabilizerState_alpha (A.alpha.symm y), StarAlgEquiv.apply_symm_apply]

/-! ## 7. The regional stabilizer elements -/

section Stabilizer

variable {A}

/-- On allowed labels the source Pauli pairing vanishes: allowed words carry no
`X` exponent, so they commute and are self-adjoint. -/
theorem sourceForm_eq_zero_of_allowed_right {n : ℕ} (v w : A.SourceLabel n)
    (hw : (w : PauliCoordinateLabels I) ∈ A.allowedLabels) :
    (A.sourceForm n).form v w = 0 := by
  obtain ⟨hx, -⟩ := (A.mem_allowedLabels_iff _).mp hw
  show (coordPairing I).form (v : PauliCoordinateLabels I) (w : PauliCoordinateLabels I) = 0
  refine Finset.sum_eq_zero (fun p _ => ?_)
  rcases p with i | i
  · simp [hx i]
  · simp

/-- Allowed source Pauli words multiply without a sign. -/
theorem pauliWord_mul_of_allowed {n : ℕ} (v w : A.SourceLabel n)
    (hw : (w : PauliCoordinateLabels I) ∈ A.allowedLabels) :
    pauliWord (A.sourceForm n) v * pauliWord (A.sourceForm n) w =
      pauliWord (A.sourceForm n) (v + w) := by
  rw [pauliWord_mul, sourceForm_eq_zero_of_allowed_right v w hw, pauliSign_zero, one_smul]

/-- Allowed source Pauli words are self-adjoint. -/
theorem pauliWord_star_of_allowed {n : ℕ} (v : A.SourceLabel n)
    (hv : (v : PauliCoordinateLabels I) ∈ A.allowedLabels) :
    star (pauliWord (A.sourceForm n) v) = pauliWord (A.sourceForm n) v := by
  rw [pauliWord_star, sourceForm_eq_zero_of_allowed_right v v hv, pauliSign_zero, one_smul,
    pauli_neg_eq_self]

variable (A)

/-- **The regional stabilizer elements.**  The image under the P53/P55D `alpha`
of an allowed coordinate Pauli word: a phase-calibrated regional Pauli word
whose string is the stabilizer vector `\sum_i z_i`. -/
noncomputable def stabilizerElement (n : ℕ) (v : A.SourceLabel n) : A.TargetLimit :=
  A.alpha (A.sourceOf n (pauliWord (A.sourceForm n) v))

/-- The regional stabilizer element is the calibrated regional Pauli word of the
image string. -/
theorem stabilizerElement_eq (n : ℕ) (v : A.SourceLabel n) :
    A.stabilizerElement n v =
      A.targetOf n (A.phase n v • pauliWord (A.targetForm n) (A.stageLabelMap n v)) :=
  A.alpha_word n v

/-- The string of a regional stabilizer element lies in `W_Γ`. -/
theorem stageLabelMap_mem_stabilizerLabels {n : ℕ} (v : A.SourceLabel n)
    (hv : (v : PauliCoordinateLabels I) ∈ A.allowedLabels) :
    ((A.stageLabelMap n v : A.TargetLabel n) : PhaseSpace L) ∈ A.stabilizerLabels := by
  rw [A.stageLabelMap_coe]
  exact (A.coordinateMap_mem_stabilizerLabels_iff _).mpr hv

@[simp] theorem stabilizerElement_zero (n : ℕ) : A.stabilizerElement n 0 = 1 := by
  rw [stabilizerElement, pauliWord_zero, A.sourceOf_one, map_one]

/-- The regional stabilizer elements form a group under multiplication. -/
theorem stabilizerElement_mul {n : ℕ} (v w : A.SourceLabel n)
    (hw : (w : PauliCoordinateLabels I) ∈ A.allowedLabels) :
    A.stabilizerElement n v * A.stabilizerElement n w = A.stabilizerElement n (v + w) := by
  rw [stabilizerElement, stabilizerElement, stabilizerElement, ← map_mul, ← A.sourceOf_mul,
    pauliWord_mul_of_allowed v w hw]

/-- The regional stabilizer elements are self-adjoint. -/
theorem stabilizerElement_star {n : ℕ} (v : A.SourceLabel n)
    (hv : (v : PauliCoordinateLabels I) ∈ A.allowedLabels) :
    star (A.stabilizerElement n v) = A.stabilizerElement n v := by
  rw [stabilizerElement, ← map_star, ← A.sourceOf_star, pauliWord_star_of_allowed v hv]

/-- **The stabilizer-state property.**  The regional state has expectation `1`
on every regional stabilizer element, i.e. the elements `α(O)` of allowed words
are exactly the `+1`-eigenvalue stabilizer operators of the state. -/
theorem regionalStabilizerState_stabilizerElement {n : ℕ} (v : A.SourceLabel n)
    (hv : (v : PauliCoordinateLabels I) ∈ A.allowedLabels) :
    A.regionalStabilizerState (A.stabilizerElement n v) = 1 := by
  rw [stabilizerElement, A.regionalStabilizerState_alpha_word, A.productExpectation_of_mem hv]

end Stabilizer

/-! ## 8. The identity on the concrete C⋆-algebras -/

namespace SourceConcreteRep

variable {A} (R : A.SourceConcreteRep)

/-- **The continuous state identity** (`main.tex:1944-1946`, "since the states
agree on a basis of operators, they are the same states").

If `f` is *any* continuous linear functional on the P55C concrete source
C⋆-algebra restricting to the pure/mixed product state on the dense algebraic
image, and `g` is *any* continuous linear functional on the P55C concrete
regional C⋆-algebra restricting to the regional stabilizer state on the dense
algebraic image, then `g ∘ alpha = f` for the exact P55D C⋆ `alpha`.  No
boundedness or continuity premise beyond the continuity of `f` and `g`
themselves is used. -/
theorem cstarState_identity (f : R.sourceCStar →L[ℂ] ℂ) (g : R.targetCStar →L[ℂ] ℂ)
    (hf : ∀ z : A.SourceLimit, f (R.sourceEmbedding z) = A.sourceProductState z)
    (hg : ∀ y : A.TargetLimit, g (R.targetEmbedding y) = A.regionalStabilizerState y)
    (T : R.sourceCStar) : g (R.cstarAlpha T) = f T := by
  have hfun : (fun T : R.sourceCStar => g (R.cstarAlpha T)) = fun T => f T := by
    refine Continuous.ext_on R.sourceEmbedding_denseRange
      (g.continuous.comp R.continuous_cstarAlpha) f.continuous ?_
    rintro _ ⟨z, rfl⟩
    show g (R.cstarAlpha (R.sourceEmbedding z)) = f (R.sourceEmbedding z)
    rw [R.cstarAlpha_sourceEmbedding, hg, hf, A.regionalStabilizerState_alpha]
  exact congrFun hfun T

/-- A continuous functional on the concrete source C⋆-algebra is determined by
its restriction to the dense algebraic image. -/
theorem cstarSourceState_unique (f f' : R.sourceCStar →L[ℂ] ℂ)
    (hf : ∀ z : A.SourceLimit, f (R.sourceEmbedding z) = A.sourceProductState z)
    (hf' : ∀ z : A.SourceLimit, f' (R.sourceEmbedding z) = A.sourceProductState z) : f = f' := by
  refine ContinuousLinearMap.ext (fun T => ?_)
  have hfun : (f : R.sourceCStar → ℂ) = f' :=
    Continuous.ext_on R.sourceEmbedding_denseRange f.continuous f'.continuous
      (by rintro _ ⟨z, rfl⟩; rw [hf z, hf' z])
  exact congrFun hfun T

/-- A continuous functional on the concrete regional C⋆-algebra is determined by
its restriction to the dense algebraic image. -/
theorem cstarRegionalState_unique (g g' : R.targetCStar →L[ℂ] ℂ)
    (hg : ∀ y : A.TargetLimit, g (R.targetEmbedding y) = A.regionalStabilizerState y)
    (hg' : ∀ y : A.TargetLimit, g' (R.targetEmbedding y) = A.regionalStabilizerState y) :
    g = g' := by
  refine ContinuousLinearMap.ext (fun T => ?_)
  have hfun : (g : R.targetCStar → ℂ) = g' :=
    Continuous.ext_on R.targetEmbedding_denseRange g.continuous g'.continuous
      (by rintro _ ⟨y, rfl⟩; rw [hg y, hg' y])
  exact congrFun hfun T

/-! ### Existence of the two continuous states

The only auxiliary assumption of this module: the algebraic product state is
bounded for the concrete C⋆-norm of P55C.  It is the analytic input that the
manuscript leaves implicit when it passes from Pauli words to the quasi-local
C⋆-algebra.  Nothing else — no supplied state, no supplied extension, no
supplied density interface — is assumed: the extension itself is constructed
and proved unique. -/

/-- **Auxiliary assumption (product-state boundedness).**  A norm bound for the
algebraic pure/mixed product state with respect to the concrete C⋆-norm of the
P55C representation. -/
structure ProductStateBound where
  /-- The bound constant. -/
  const : ℝ
  /-- The bound itself. -/
  norm_le : ∀ z : A.SourceLimit,
    ‖A.sourceProductState z‖ ≤ const * ‖R.sourceEmbedding z‖

variable {R}

theorem uniformContinuous_sourceProductState (hb : R.ProductStateBound) :
    letI := R.sourceNormedRing
    letI := R.sourceNormedAlgebra
    UniformContinuous A.sourceProductState := by
  letI := R.sourceNormedRing
  letI := R.sourceNormedAlgebra
  exact (AddMonoidHomClass.lipschitz_of_bound A.sourceProductState hb.const
    (fun z => hb.norm_le z)).uniformContinuous

/-- **The continuous pure/mixed product state** on the concrete source
C⋆-algebra, constructed by density from the algebraic product state. -/
noncomputable def cstarProductState (hb : R.ProductStateBound) : R.sourceCStar →L[ℂ] ℂ :=
  letI := R.sourceNormedRing
  letI := R.sourceNormedAlgebra
  extendCLM (i := (R.sourceEmbedding : A.SourceLimit →⋆ₐ[ℂ] R.sourceCStar).toAlgHom.toLinearMap)
    R.isometry_sourceEmbedding R.sourceEmbedding_denseRange
    (uniformContinuous_sourceProductState hb)

@[simp] theorem cstarProductState_sourceEmbedding (hb : R.ProductStateBound)
    (z : A.SourceLimit) :
    cstarProductState hb (R.sourceEmbedding z) = A.sourceProductState z := by
  letI := R.sourceNormedRing
  letI := R.sourceNormedAlgebra
  exact extendCLM_apply (i := (R.sourceEmbedding :
      A.SourceLimit →⋆ₐ[ℂ] R.sourceCStar).toAlgHom.toLinearMap)
    R.isometry_sourceEmbedding R.sourceEmbedding_denseRange
    (uniformContinuous_sourceProductState hb) z

variable (R)

/-- The inverse of the P55D C⋆ `alpha`, as a continuous linear map. -/
noncomputable def cstarAlphaSymmCLM : R.targetCStar →L[ℂ] R.sourceCStar where
  toFun := R.cstarAlpha.symm
  map_add' := map_add _
  map_smul' c x := map_smul R.cstarAlpha.symm c x
  cont := R.continuous_cstarAlpha_symm

@[simp] theorem cstarAlphaSymmCLM_apply (T : R.targetCStar) :
    R.cstarAlphaSymmCLM T = R.cstarAlpha.symm T := rfl

variable {R}

/-- **The continuous regional stabilizer state** on the concrete regional
C⋆-algebra.  It exists as soon as the product state is bounded, and it is the
unique continuous functional restricting to the algebraic regional stabilizer
state. -/
noncomputable def cstarRegionalState (hb : R.ProductStateBound) : R.targetCStar →L[ℂ] ℂ :=
  (cstarProductState hb).comp R.cstarAlphaSymmCLM

@[simp] theorem cstarRegionalState_targetEmbedding (hb : R.ProductStateBound)
    (y : A.TargetLimit) :
    cstarRegionalState hb (R.targetEmbedding y) = A.regionalStabilizerState y := by
  show cstarProductState hb (R.cstarAlpha.symm (R.targetEmbedding y)) = _
  rw [R.cstarAlpha_symm_targetEmbedding, cstarProductState_sourceEmbedding,
    A.sourceProductState_alpha_symm]

/-- **The final continuous state equality.**  The continuous regional stabilizer
state, pulled back by the exact P55D C⋆ `alpha`, is the continuous pure/mixed
product state on the whole concrete quasi-local C⋆-algebra. -/
theorem cstarRegionalState_cstarAlpha (hb : R.ProductStateBound) (T : R.sourceCStar) :
    cstarRegionalState hb (R.cstarAlpha T) = cstarProductState hb T :=
  cstarState_identity R _ _ (cstarProductState_sourceEmbedding hb)
    (cstarRegionalState_targetEmbedding hb) T

/-- Function form of the final continuous state equality. -/
theorem cstarRegionalState_comp_cstarAlpha (hb : R.ProductStateBound) :
    (fun T : R.sourceCStar => cstarRegionalState hb (R.cstarAlpha T)) =
      fun T => cstarProductState hb T :=
  funext (cstarRegionalState_cstarAlpha hb)

end SourceConcreteRep

/-! ## 9. The branch-uniform regional state identity -/

/-- The branch-uniform continuous state identity for the P55C/P55D branch
representation datum and the exact P55D `A.regionalCStarAlpha`. -/
theorem regionalCStarAlpha_state_identity
    (f : A.SourceConcreteCStar →L[ℂ] ℂ) (g : A.TargetConcreteCStar →L[ℂ] ℂ)
    (hf : ∀ z : A.SourceLimit, f (A.sourceCStarEmbedding z) = A.sourceProductState z)
    (hg : ∀ y : A.TargetLimit, g (A.targetCStarEmbedding y) = A.regionalStabilizerState y)
    (T : A.SourceConcreteCStar) : g (A.regionalCStarAlpha T) = f T :=
  SourceConcreteRep.cstarState_identity (A.branchSourceRep) f g hf hg T

end AlphaData

/-! ## 10. Non-vacuity -/

/-- For the tautological P53 data every coordinate is selected, so the allowed
words are exactly the `X`-free coordinate words. -/
theorem standardAlphaData_mem_allowedLabels_iff (c : PauliCoordinateLabels ℕ) :
    c ∈ standardAlphaData.allowedLabels ↔ ∀ i : ℕ, c (Sum.inr i) = 0 := by
  rw [AlphaData.mem_allowedLabels_iff]
  exact ⟨fun h => h.1, fun h => ⟨h, fun i _ => Set.mem_univ i⟩⟩

/-- **Non-vacuity.**  For the tautological P53 data the algebraic state identity
holds and the two states are unital, so neither is the zero functional. -/
theorem standardAlphaData_state_identity :
    (∀ z, standardAlphaData.regionalStabilizerState (standardAlphaData.alpha z) =
      standardAlphaData.sourceProductState z) ∧
    standardAlphaData.sourceProductState 1 = 1 ∧
    standardAlphaData.regionalStabilizerState 1 = 1 :=
  ⟨AlphaData.regionalStabilizerState_alpha _, AlphaData.sourceProductState_one _,
    AlphaData.regionalStabilizerState_one _⟩

end LocalHyperbolicAlpha

end StabilizerHyperfinite

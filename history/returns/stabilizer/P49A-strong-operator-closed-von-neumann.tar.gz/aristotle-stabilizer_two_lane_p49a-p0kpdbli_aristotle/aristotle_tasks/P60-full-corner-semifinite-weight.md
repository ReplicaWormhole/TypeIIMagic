# P60 — optional global semifinite weight from a full finite corner

## Context declaration

- **Infrastructure only:** optional strengthening beyond the Lane-G manuscript
  conclusion; this packet makes no claim that the manuscript requires it.

## Plan alignment

- **Package and lane:** `P60`; Lane `G` optional strengthening.
- **Predecessors:** `P51`, integrated and locally audited before submission.
- **Gate discharged:** globalize a full finite corner to a faithful normal
  semifinite weight under exact comparison/countability hypotheses.
- **Forbidden downstream claims:** no claim that P51 already supplied a global
  weight, no direct-integral theorem, and no Lane-H factorization.

## Mathematical target

Create only `AristotleCandidates/FullCornerSemifiniteWeight.lean`. Under explicit
sigma-finiteness/comparison hypotheses, construct a faithful normal semifinite
weight on the ambient algebra from the P51 full finite corner and its tracial
state. If the construction cannot be expressed in pinned Mathlib, formalize the
minimal conditional interface and prove its consequences without upgrading it
to an unconditional theorem.

## Auxiliary assumptions

List every family-of-partial-isometries, convergence, normality, faithfulness,
and semifiniteness premise explicitly.

## Files and imports

Create only `AristotleCandidates/FullCornerSemifiniteWeight.lean`; import P51.

## Acceptance criteria

`lake build AristotleCandidates.FullCornerSemifiniteWeight` succeeds without
forbidden declarations and reports the exact optional assumptions. This packet
is disabled in the automatic queue until separately approved.

# Summary of changes for run f17e2043-2bd3-431a-a76d-8967c9802ef8
## FF15 — finite-region full-Pauli matrix multiplication: complete

New file `FiniteFiber/FiniteRegionFullPauliMultiplication.lean` (no existing file was modified; the only other addition is the new audit script `tests/FullPauliMultiplicationAxiomAudit.lean`). It builds with no `sorry`/`admit`, no new axioms, and no `unsafe`/`opaque`/`native_decide`.

### Exact build result
- `lake build FiniteFiber.FiniteRegionFullPauliMultiplication` → `Build completed successfully (3184 jobs).` (no errors, no warnings)
- `lake build` (default target) → `Build completed successfully (3203 jobs).`
- `lake env lean tests/FullPauliMultiplicationAxiomAudit.lean` → every public theorem of the new file depends only on `[propext, Classical.choice, Quot.sound]`.
- A `lake` note "manifest out of date: source kind of dependency 'mathlib' changed" is printed by the pre-existing environment setup; it is a warning only and does not affect the build.

Note: the new module is not imported by the root aggregator `FiniteFiber.lean`, since the packet forbids modifying existing files; it is verified by the explicit module build above and can be integrated later with one import line.

### 1. Checked infrastructure developed in the packet
- `finiteRegionTensorMatrix` and `finiteRegionTensorMatrix_mul`: the finite tensor/product factorization, i.e. a product of entrywise tensor matrices over a region is the tensor matrix of the sitewise products (proved from `Finset.prod_univ_sum`).
- `zmod4PhaseFactor_two`, `zmod4PhaseFactor_phaseEmbed`, `phaseEmbed_apply`: the `±1` scalar attached to a binary sign exponent via the existing `FullPauliWord.phaseEmbed`.
- `binaryDot_eq_sum_of_support_subset`: for a left argument supported in `F`, the existing `binaryDot` is the plain sum over `F`; plus `xCoordinate_apply`, `zCoordinate_apply`, `restrictLabel`, `restrictLabel_add`.

### 2. Theorems recovered in the intended form
- `normalFormOneSiteMatrix_mul` — the one-site relation `X^{x₁}Z^{z₁} · X^{x₂}Z^{z₂} = (-1)^{z₁x₂} X^{x₁+x₂}Z^{z₁+z₂}`, in the established `X`-then-`Z` convention (so the `(1,1)` raw matrix is `-i·Y`, correction `3 : ZMod 4`), with the sign expressed through the existing `phaseEmbed`.
- `finiteRegionNormalFormMatrix_mul` — finite-region projective multiplication for the already integrated `finiteRegionNormalFormMatrix`, with summed exponent `finiteRegionNormalFormCocycle`.
- `cocycle_eq_finiteRegionNormalFormCocycle` — the region exponent *is* the existing `FullPauliWord.cocycle` (the cocycle is not redefined; no unexplained sign is introduced).
- `fullPauliRegionMatrix` / `fullPauliRegionMatrix_mul` — the target identity `matrix (a * b) = matrix a * matrix b`, the phase correction being exactly `FullPauliWord.cocycle a.label b.label`.
- `fullPauliRegionMatrix_one` — the identity word maps to `1`.
- `fullPauliRegionMatrix_negativeIdentity` — the central word `FullPauliWord.negativeIdentity` maps to `(-1) • 1`.

### 3. Conditional content / exact extra assumptions
`fullPauliRegionMatrix_mul` carries the single premise `a.label.support ⊆ F` on the left factor. This is the finite-region locality hypothesis requested by the packet, and only the left factor needs it because the cocycle pairs the `Z` coordinate of `a` against the `X` coordinate of `b`; the statement therefore covers in particular any two words supported in `F` and is strictly stronger than the two-sided form. No other hypothesis was added and nothing was weakened.

### 4. Open obstructions
None for this packet: the full `FullPauliWord` lift was not blocked, so the strongest form (full-word multiplicativity, not merely the projective core) is delivered. Out-of-scope items — quasilocal completion, states, GNS, and the infinite finite-projection theorem — were deliberately not attempted.

All work is committed and pushed.
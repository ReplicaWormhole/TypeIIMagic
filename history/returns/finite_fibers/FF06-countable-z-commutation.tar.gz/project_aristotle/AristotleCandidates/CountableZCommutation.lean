import FiniteFiber.CountablePauliRepresentation

/-!
# Commutation of the countable one-site phase generators

The one-site phase generators `countablePauliZ i` act on the countable binary
configuration `L²` space as multiplication by the bounded pointwise characters
`phaseCharacter i`.  Since these are complex scalar multipliers, any two of
them commute, with no distinctness hypothesis on the sites.

The proof compares the two composites through their almost-everywhere action
formula `configurationPhase_apply_ae`; equality of `Lp` elements is obtained
from an almost-everywhere identity, not from pointwise extensionality.
-/

open MeasureTheory

namespace FiniteFiber

/-- The almost-everywhere action of a composite of two phase multipliers. -/
private theorem configurationPhase_comp_apply_ae (i j : ℕ)
    (f : CountablePauliHilbert) :
    (configurationPhase i).comp (configurationPhase j) f =ᵐ[Measure.count]
      fun x => phaseCharacter i x * (phaseCharacter j x * f x) := by
  simp only [ContinuousLinearMap.comp_apply]
  refine (configurationPhase_apply_ae i (configurationPhase j f)).trans ?_
  filter_upwards [configurationPhase_apply_ae j f] with x hx
  rw [hx]

/-- The countable one-site phase generators commute. -/
theorem countablePauliZ_comm (i j : ℕ) :
    (countablePauliZ i).comp (countablePauliZ j) =
      (countablePauliZ j).comp (countablePauliZ i) := by
  ext f
  refine (configurationPhase_comp_apply_ae i j f).trans
    (Filter.EventuallyEq.symm ?_)
  refine (configurationPhase_comp_apply_ae j i f).trans ?_
  filter_upwards with x
  ring

end FiniteFiber

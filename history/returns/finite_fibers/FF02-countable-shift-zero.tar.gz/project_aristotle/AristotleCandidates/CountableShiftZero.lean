import FiniteFiber.CountablePauliRepresentation

/-!
# Translation by the neutral configuration is the identity

This file proves the single fact that the count-measure translation operator
`configurationShift` on the countable configuration Hilbert space is the
identity bounded operator at the neutral configuration `0`.
-/

open MeasureTheory

namespace FiniteFiber

/-- Translation by the neutral configuration acts as the identity on `L²`. -/
theorem configurationShift_zero :
    configurationShift 0 =
      ContinuousLinearMap.id ℂ CountablePauliHilbert := by
  ext f
  refine (configurationShift_apply_ae 0 f).trans ?_
  simp

end FiniteFiber

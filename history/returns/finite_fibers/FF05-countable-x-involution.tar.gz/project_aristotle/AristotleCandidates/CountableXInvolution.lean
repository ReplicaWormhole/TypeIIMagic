import FiniteFiber.CountablePauliRepresentation

/-!
# The same-site countable Pauli `X` involution

This candidate file proves the exact bounded-operator involution law for the
one-site bit flip `countablePauliX i` on the countable configuration Hilbert
space.  Composing the translation by `configurationBit i` with itself is
translation by `configurationBit i + configurationBit i = 0`, which is the
identity operator.
-/

namespace FiniteFiber

/-- Composing the one-site bit flip with itself is the identity operator. -/
theorem countablePauliX_comp_self (i : ℕ) :
    (countablePauliX i).comp (countablePauliX i) =
      ContinuousLinearMap.id ℂ CountablePauliHilbert := by
  have hadd := configurationShift_add (configurationBit i) (configurationBit i)
  rw [configurationBit_add_self, configurationShift_zero] at hadd
  simpa [countablePauliX] using hadd.symm

end FiniteFiber

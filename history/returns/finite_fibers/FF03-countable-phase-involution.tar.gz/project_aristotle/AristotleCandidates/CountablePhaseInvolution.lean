import FiniteFiber.CountablePauliRepresentation

/-!
# The one-site phase generator is an involution

The single result of this file states that the bounded multiplication operator
`configurationPhase i` on the countable configuration Hilbert space squares to
the identity.  It is exactly the operator form of the pointwise identity
`phaseCharacter i x * phaseCharacter i x = 1`, transported to `L²`
representatives almost everywhere.
-/

open MeasureTheory

namespace FiniteFiber

/-- The one-site phase generator squares to the identity operator. -/
theorem configurationPhase_comp_self (i : ℕ) :
    (configurationPhase i).comp (configurationPhase i) =
      ContinuousLinearMap.id ℂ CountablePauliHilbert := by
  ext f
  simp only [ContinuousLinearMap.comp_apply, ContinuousLinearMap.id_apply]
  refine (configurationPhase_apply_ae i (configurationPhase i f)).trans ?_
  filter_upwards [configurationPhase_apply_ae i f] with x hx
  rw [hx, ← mul_assoc, phaseCharacter_mul_self, one_mul]

end FiniteFiber

# Summary of changes for run 44158f6b-4673-4e26-9871-9fc7717c0353
## FF17 — actual finite stabilizer densities from full Pauli words

I added exactly one new file, `FiniteFiber/FullPauliStabilizerDensity.lean` (≈690 lines), building on FF15 (`FiniteRegionFullPauliMultiplication.lean`) and FF16 (`FullPauliSupportLocality.lean`). No other file was modified. `lake build FiniteFiber.FullPauliStabilizerDensity` succeeds, `lake build` still succeeds, there is no `sorry`/`admit`/`axiom`/`opaque`/`unsafe`/`implemented_by`, and `#print axioms` on every public result reports only `propext`, `Classical.choice`, `Quot.sound`. The pre-existing audits `tests/AxiomAudit.lean` and `tests/FullPauliMultiplicationAxiomAudit.lean` still report only those axioms.

### 1. Checked infrastructure developed in the packet
- `regionBasisEquiv` / `regionToQubitMatrix`: the canonical identification `QubitIndex |F| ≃ (↥F → Fin 2)` from a chosen enumeration of the region, promoted to a star-algebra reindexing that preserves products, adjoints, traces and positivity, and carries `finiteRegionPauliMatrix` to `pauliStringMatrix`.
- `regionHermitianPhase` / `regionSign`: the total `ZMod 4` phase of a full Pauli word in a region — its central phase plus the summed `X`-then-`Z` normal-form correction of `OneSitePauliNormalForm` — and the Boolean sign read off from it.
- Traces of finite-region Pauli strings, and the region-basis dimension `2^{|F|}`.

### 2. Theorem recovered in the manuscript's intended form (finite volume)
For an **explicitly finite consistent** subgroup `D : FullPauliRegionStabilizer Site` — all hypotheses are explicit structure fields: a subgroup of `FullPauliWord Site`, a finite region `F`, an explicit `Fintype` datum, `g.label.support ⊆ F` for every member, `g * g = 1` for every member, and `negativeIdentity ∉ group`:
- `fullPauliRegionMatrix_eq_pauliSign_smul`: each member's finite-region matrix is *exactly* `±1` times the phase-free Hermitian Pauli matrix of its canonical labels — the exact sign/central-phase convention of the abstract signed-Pauli layer (regression theorems pin `1 ↦ +`, `-1 ↦ −`, `Z ↦ +Z`).
- `stabilizerData`: this assembles into a genuine `FinitePauliStabilizerData ↥D.group |F|`; faithfulness of the realization and the exclusion of the matrix `-1` are **proved** (from tracelessness of nonidentity Pauli strings plus consistency), not assumed.
- `regionToQubitMatrix_regionDensity`: the group average `ρ_F = 2^{-|F|} ∑_{g∈G} g` of the finite-region matrix image *is* the stabilizer density already constructed abstractly in the finite-density layer.
- Consequences: `ρ_F` is positive semidefinite (`regionDensity_posSemidef`) with trace one (`regionDensity_trace`), equals `P_F / Tr P_F`, `Tr P_F = 2^{|F|}/|G|`, `P_F` is a nonzero self-adjoint idempotent and every stabilizer fixes it — the manuscript's Eq. for `ρ_F` in finite volume.
- `localStabilizerSubgroup S F = S ⊓ localGroup F` is the syntactic form of the manuscript's `G_{S,F} = G_S ∩ A_F`; its finiteness is **proved** from finite support alone, so `ofGlobalStabilizer` and `ofGenerators` produce the above data from a (possibly infinite) global consistent involutive stabilizer group, or directly from pairwise-commuting order-two generators excluding `-1`. `regionDensity_ofGenerators` states the positive trace-one density for that manuscript-level input.
- Non-vacuity is checked: a single `Z` stabilizer at one site gives such a subgroup with a nonidentity element, and its region matrix is the Hermitian `Z`.

### 3. Conditional content / extra assumptions
Involutivity (`g * g = 1`) of the group members is an explicit premise; it is exactly what forces the total region phase into `{0, 2}` and hence the real `±` sign, and it is discharged automatically in the generator-level constructor. No analytic or normality hypothesis is used anywhere.

### 4. Obstructions still open (explicitly *not* claimed)
Nothing global is asserted: no countable stabilizer system is inferred from short-range order, and there is no exhaustion, quasilocal algebra, global state, GNS representation, normality, or von Neumann/finite-fiber conclusion here. All algebras in this file are finite complex matrix algebras over one fixed finite region.

Following the FF16 precedent, the new module is not added to the root `FiniteFiber.lean` import list; it is verified through its own Lake target.

# Summary of changes for run 9c0ded12-3eeb-4e12-bb2a-dadf11b64b13
Added the new file `FiniteFiber/FiniteRegionEmbeddingCoherence.lean` (importing `FiniteFiber.FiniteRegionQubitAlgebra`). No existing files were modified; no `sorry`, `admit`, axioms, `unsafe`, or `opaque` are used.

**What is proved**

- `FiniteFiber.finiteRegionRestrict` — restriction of a bit configuration on `F'` to a subregion `F ⊆ F'`, plus `finiteRegionRestrict_trans` (two-step restriction = one-step) and `finiteRegionSplitEquiv_fst` (the first component of the existing coordinate split *is* this restriction); both hold by `rfl`, so subset-proof irrelevance is absorbed definitionally.
- `FiniteFiber.finiteRegionEmbed_apply_entry` — the explicit entrywise formula for the existing embedding: the `(f, g)` entry of `finiteRegionEmbed F F' hFF' A` equals `A` at the restrictions of `f, g` to `F` when `f` and `g` agree at every site of `F'` outside `F`, and `0` otherwise. This is the explicit coordinate lemma that makes the three different coordinate splits comparable; it is proved from the actual `finiteRegionSplitEquiv` and Kronecker/reindex definitions, not assumed.
- `FiniteFiber.finiteRegionEmbed_trans` — the requested coherence identity, for every matrix `A` and all `F ⊆ F' ⊆ F''`:
  `finiteRegionEmbed F' F'' hF'F'' (finiteRegionEmbed F F' hFF' A) = finiteRegionEmbed F F'' (hFF'.trans hF'F'') A`.
- `FiniteFiber.finiteRegionEmbed_comp` — the same statement as an equality of star-algebra maps: `(finiteRegionEmbed F' F'' hF'F'').comp (finiteRegionEmbed F F' hFF') = finiteRegionEmbed F F'' (hFF'.trans hF'F'')`.

**Note on the statement as given.** The composite inclusion must be written `hFF'.trans hF'F''` (`HasSubset.Subset.trans` consumes `F ⊆ F'` then `F' ⊆ F''`); the order `hF'F''.trans hFF'` in the request does not typecheck. Apart from this argument order the theorem is exactly the requested identity — nothing was weakened, and no additional hypotheses were added. No obstruction beyond the entrywise comparison lemma arose.

**Build command and result**

`lake build FiniteFiber.FiniteRegionEmbeddingCoherence`
→ `✔ [3175/3175] Built FiniteFiber.FiniteRegionEmbeddingCoherence` / `Build completed successfully (3175 jobs).` (the only output notice is a pre-existing manifest-freshness warning about the mathlib dependency source kind).

Axiom audit: `finiteRegionEmbed_trans`, `finiteRegionEmbed_comp`, and `finiteRegionEmbed_apply_entry` each depend only on `[propext, Classical.choice, Quot.sound]`; `finiteRegionRestrict_trans` on `[propext, Quot.sound]`.

All work is committed and pushed.
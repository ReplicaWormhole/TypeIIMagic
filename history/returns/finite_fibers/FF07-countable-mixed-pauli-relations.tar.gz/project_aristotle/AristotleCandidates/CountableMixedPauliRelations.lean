import FiniteFiber.CountablePauliRepresentation

/-!
# Mixed shift/phase relations for the countable Pauli generators

This candidate module proves the two mixed operator relations for the bounded
countable generators `countablePauliX` and `countablePauliZ`:

* same-site anticommutation, and
* distinct-site commutation.

All identities between `Lp` representatives are established almost everywhere
with respect to counting measure.
-/

open scoped ENNReal NNReal
open MeasureTheory

namespace FiniteFiber

/-- Almost-everywhere identities may be pulled back along a translation. -/
private theorem ae_comp_add_left_candidate
    (h : CountablePauliConfiguration) {u v : CountablePauliConfiguration → ℂ}
    (huv : u =ᵐ[Measure.count] v) :
    (fun x => u (h + x)) =ᵐ[Measure.count] fun x => v (h + x) :=
  (MeasureTheory.measurePreserving_add_left
      (Measure.count : Measure CountablePauliConfiguration)
      h).quasiMeasurePreserving.ae_eq_comp huv

/-- The phase generator applied after a bit flip acts by the unshifted phase. -/
private theorem countablePauliZ_comp_countablePauliX_apply_ae
    (i j : ℕ) (f : CountablePauliHilbert) :
    ((countablePauliZ i).comp (countablePauliX j)) f =ᵐ[Measure.count]
      fun x => phaseCharacter i x * (f : CountablePauliConfiguration → ℂ)
        (configurationBit j + x) := by
  simp only [ContinuousLinearMap.comp_apply, countablePauliZ, countablePauliX]
  filter_upwards [configurationPhase_apply_ae i (configurationShift (configurationBit j) f),
    configurationShift_apply_ae (configurationBit j) f] with x h1 h2
  rw [h1, h2]

/-- The bit flip applied after the phase generator acts by the shifted phase. -/
private theorem countablePauliX_comp_countablePauliZ_apply_ae
    (i j : ℕ) (f : CountablePauliHilbert) :
    ((countablePauliX j).comp (countablePauliZ i)) f =ᵐ[Measure.count]
      fun x => phaseCharacter i (configurationBit j + x) *
        (f : CountablePauliConfiguration → ℂ) (configurationBit j + x) := by
  simp only [ContinuousLinearMap.comp_apply, countablePauliZ, countablePauliX]
  filter_upwards [configurationShift_apply_ae (configurationBit j)
      (configurationPhase i f),
    ae_comp_add_left_candidate (configurationBit j) (configurationPhase_apply_ae i f)]
    with x h1 h2
  rw [h1, h2]

/-- Same-site mixed generators anticommute. -/
theorem countablePauliZ_comp_countablePauliX_same (i : ℕ) :
    (countablePauliZ i).comp (countablePauliX i) =
      -((countablePauliX i).comp (countablePauliZ i)) := by
  ext f
  simp only [ContinuousLinearMap.neg_apply]
  refine (countablePauliZ_comp_countablePauliX_apply_ae i i f).trans ?_
  filter_upwards [Lp.coeFn_neg (((countablePauliX i).comp (countablePauliZ i)) f),
    countablePauliX_comp_countablePauliZ_apply_ae i i f] with x hneg hx
  rw [hneg, Pi.neg_apply, hx, phaseCharacter_bit_add]
  ring

/-- Mixed generators at distinct sites commute. -/
theorem countablePauliZ_comp_countablePauliX_other
    (i j : ℕ) (hij : i ≠ j) :
    (countablePauliZ i).comp (countablePauliX j) =
      (countablePauliX j).comp (countablePauliZ i) := by
  ext f
  refine (countablePauliZ_comp_countablePauliX_apply_ae i j f).trans ?_
  filter_upwards [countablePauliX_comp_countablePauliZ_apply_ae i j f] with x hx
  rw [hx, phaseCharacter_other_bit_add i j hij]

end FiniteFiber

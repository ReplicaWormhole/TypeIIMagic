# Summary of changes for run 5b3348cb-4bec-468f-b382-a5383848de2a
## FF22 — trace and fullness of the finite-range stabilizer corner: complete

**New module (the only new source file):** `FiniteFiber/FiniteRangeTracialCorner.lean` (1278 lines), plus its `import` line in `FiniteFiber.lean` and new `#print axioms` lines in `tests/AxiomAudit.lean`.

**Exact build result**
```
lake build FiniteFiber.FiniteRangeTracialCorner   → ✔ Built FiniteFiber.FiniteRangeTracialCorner
lake build                                        → Build completed successfully (3211 jobs).
lake env lean tests/AxiomAudit.lean               → propext, Classical.choice, Quot.sound only
```
(The only diagnostic is the pre-existing `manifest out of date` warning about the mathlib dependency source kind.) No `sorry`, `admit`, `axiom`, `opaque`, `unsafe` or `implemented_by` occurs in the module.

### Derived vs still conditional

| FF20 premise / claim | Status | Lean name | Extra hypotheses |
|---|---|---|---|
| 2. `q ≠ 0` | derived | `FiniteRangeStabilizerSystem.cornerProjection_ne_zero'` | FF21 data `R, Q, W, M, hM` only |
| 3. fullness (central support `1`) | derived | `FiniteRangeStabilizerSystem.cornerProjection_isFullProjection` | FF21 data only |
| dense product orbit (local cyclicity of `Ω`) | derived | `QuasilocalStabilizerState.dense_localOperatorAlgebra_orbit` | `Q, W` only |
| normality of `τ_q`, stated as exact strong-limit continuity | derived | `vectorFunctional_tendsto_of_strong`, `tendsto_vectorFunctional_sandwich` | none |
| positivity `τ_q(a*a)=‖aΩ‖²`, normalization `τ_q(q)=1` | derived | `vectorFunctional_star_mul_self`, `vectorFunctional_eq_one_of_fixes` | none |
| finite-volume trace cyclicity (Lemma `lem:finite-trace`) | derived | `FullPauliStabilizerSystem.localState_regionCodeProjector_comm` | none |
| `p_n = π_ω(P_{Γ_n})` (identifies FF21 supports with code projectors) | derived | `FiniteRangeStabilizerSystem.supportProjection_eq_representation` | none |
| local (finite-stage) corner traciality | derived | `FiniteRangeStabilizerSystem.cornerPairing_comm_of_mem_localOperatorAlgebra` | FF21 data |
| 1. traciality on `q M q`, **general `M`** | conditional | `FiniteRangeStabilizerSystem.tracial_cornerProjection` | `hgen : W.GeneratedByLocalAlgebra M` (`M ⊆ π_ω(𝒜_loc)''`) |
| 1. faithfulness on `q M q`, **general `M`** | conditional | `FiniteRangeStabilizerSystem.faithful_cornerProjection` | same `hgen` |
| 1. traciality + faithfulness for `M = M_Γ = π_ω(𝒜_loc)''` | **derived** | `tracial_/faithful_cornerProjection_localVonNeumannAlgebra` | none beyond `R, Q, W` |
| full `SupportCornerConclusion` for `M_Γ` | **derived** | `FiniteRangeStabilizerSystem.supportCornerConclusion_localVonNeumannAlgebra` | none beyond `R, Q, W` |
| no-type-III conclusion | not asserted | — | deferred to FF23, as instructed |

`GeneratedByLocalAlgebra M` is the packet's only extra premise, stated as an explicit Lean definition and passed as an explicit argument. It is the definitional identification `M = M_Γ` (with FF21's `hM` it reads `π_ω(𝒜_loc) ⊆ M ⊆ π_ω(𝒜_loc)''`), and it is counterexample-sensitive: for `M = B(H)`, which still satisfies `hM`, the approximation argument only yields symmetry of the corner pairing inside the strong closure of the local algebra, so the corner vector state need not be tracial. Crucially it is **discharged** for the canonical algebra, so the headline theorem carries no extra hypothesis at all.

### Infrastructure built here (absent from Mathlib)
* `exists_mem_norm_sub_apply_lt` — the von Neumann density theorem in finite-tuple strong-approximation form, proved from scratch by the amplification argument; this replaces the manuscript's appeal to Kaplansky density.
* `bicommutant` — the bicommutant `𝒜''` of an arbitrary star subalgebra of `B(H)` packaged as a Mathlib `VonNeumannAlgebra`, and `QuasilocalStabilizerState.localVonNeumannAlgebra = π_ω(𝒜_loc)''` realizing the manuscript's `M_Γ`.
* `cornerPairing` with `cornerPairing_comm_of_local` / `cornerPairing_comm_of_localAlgebra` — the two-vector approximation step carrying local symmetry of `Φ(x,y)=τ_q(qxqyq)` to the whole bicommutant.
* the exact strong-limit lemmas `tendsto_apply_of_stronglyTendsTo`, `tendsto_sandwich_apply`, `cornerPairing_comm_of_eventually`, and faithfulness for arbitrary corner elements.

All work is committed and pushed; the full derived-vs-conditional table and the verification commands are also recorded in `HANDOFF.md`.

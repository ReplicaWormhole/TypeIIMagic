import FiniteFiber.FiniteStabilizerStateChain
import Mathlib.Analysis.CStarAlgebra.ContinuousLinearMap
import Mathlib.Data.Finsupp.Encodable
import Mathlib.Data.ZMod.Basic
import Mathlib.MeasureTheory.Function.Holder
import Mathlib.MeasureTheory.Function.L2Space
import Mathlib.MeasureTheory.Function.LpSpace.Complete
import Mathlib.MeasureTheory.Group.Measure

/-!
# A concrete countable Pauli configuration representation

This module begins the countable-lattice realization missing from the finite
ordered-qubit chain.  The configuration space is the additive group of
finitely supported binary configurations on `ℕ`, equipped with counting
measure.  Its `L²` space carries:

* translations by finite configurations; and
* multiplication by the one-site binary phase character.

The declarations here construct genuine bounded operators and record their
almost-everywhere action.  They do not yet prove the finite/tail factorization
which identifies the finite-site Pauli image with a finite matrix algebra, nor
do they construct a quasilocal closure or a global stabilizer state.
-/

open scoped ENNReal NNReal
open MeasureTheory

namespace FiniteFiber

/-- Finitely supported binary configurations on the countable ordered lattice. -/
abbrev CountablePauliConfiguration := ℕ →₀ ZMod 2

/-- The canonical discrete sigma algebra on the countable configuration space. -/
noncomputable instance : MeasurableSpace CountablePauliConfiguration := ⊤

/-- The concrete countable configuration Hilbert space with counting measure. -/
noncomputable abbrev CountablePauliHilbert :=
  MeasureTheory.Lp ℂ 2 (Measure.count : Measure CountablePauliConfiguration)

/-- The binary configuration supported at a single lattice site. -/
noncomputable def configurationBit (i : ℕ) : CountablePauliConfiguration :=
  Finsupp.single i 1

/-- A one-site binary configuration is nonzero. -/
theorem configurationBit_ne_zero (i : ℕ) : configurationBit i ≠ 0 := by
  intro hzero
  have hvalue := congrArg (fun x : CountablePauliConfiguration => x i) hzero
  simp [configurationBit] at hvalue

/-- A one-site binary configuration has additive order two. -/
theorem configurationBit_add_self (i : ℕ) :
    configurationBit i + configurationBit i = 0 := by
  ext j
  by_cases h : j = i
  · subst h
    simp only [configurationBit, Finsupp.add_apply, Finsupp.single_eq_same]
    exact ZMod.natCast_self 2
  · simp [configurationBit, h]

/-- Every binary residue is either zero or one. -/
theorem zmod2_eq_zero_or_eq_one (a : ZMod 2) : a = 0 ∨ a = 1 := by
  fin_cases a <;> simp

/-- Translation by a finite configuration as a bounded operator on `L²`. -/
noncomputable def configurationShift
    (g : CountablePauliConfiguration) :
    CountablePauliHilbert →L[ℂ] CountablePauliHilbert :=
  (MeasureTheory.Lp.compMeasurePreservingₗᵢ ℂ (fun x => g + x)
    (MeasureTheory.measurePreserving_add_left
      (Measure.count : Measure CountablePauliConfiguration) g)).toContinuousLinearMap

/-- The local bit-flip generator in the concrete countable representation. -/
noncomputable def countablePauliX (i : ℕ) :
    CountablePauliHilbert →L[ℂ] CountablePauliHilbert :=
  configurationShift (configurationBit i)

/-- Translation preserves the `L²` norm exactly. -/
theorem configurationShift_norm
    (g : CountablePauliConfiguration) (f : CountablePauliHilbert) :
    ‖configurationShift g f‖ = ‖f‖ := by
  change ‖(MeasureTheory.Lp.compMeasurePreservingₗᵢ ℂ (fun x => g + x)
    (MeasureTheory.measurePreserving_add_left
      (Measure.count : Measure CountablePauliConfiguration) g)) f‖ = ‖f‖
  exact (MeasureTheory.Lp.compMeasurePreservingₗᵢ ℂ (fun x => g + x)
    (MeasureTheory.measurePreserving_add_left
      (Measure.count : Measure CountablePauliConfiguration) g)).norm_map f

/-- The concrete translation formula for `configurationShift`. -/
theorem configurationShift_apply_ae
    (g : CountablePauliConfiguration) (f : CountablePauliHilbert) :
    configurationShift g f =ᵐ[Measure.count] fun x => f (g + x) := by
  exact MeasureTheory.Lp.coeFn_compMeasurePreserving f
    (MeasureTheory.measurePreserving_add_left
      (Measure.count : Measure CountablePauliConfiguration) g)

/-- The pointwise binary phase character at one lattice site. -/
def phaseCharacter (i : ℕ) (x : CountablePauliConfiguration) : ℂ :=
  if x i = 0 then 1 else -1

/-- Every one-site phase has square one. -/
theorem phaseCharacter_mul_self
    (i : ℕ) (x : CountablePauliConfiguration) :
    phaseCharacter i x * phaseCharacter i x = 1 := by
  simp only [phaseCharacter]
  split_ifs <;> norm_num

/-- Flipping the same binary site reverses its phase character. -/
theorem phaseCharacter_bit_add
    (i : ℕ) (x : CountablePauliConfiguration) :
    phaseCharacter i (configurationBit i + x) = - phaseCharacter i x := by
  rcases zmod2_eq_zero_or_eq_one (x i) with hx | hx
  · simp [phaseCharacter, Finsupp.add_apply, configurationBit, hx]
  · have htwo : (1 : ZMod 2) + 1 = 0 := by
      change (2 : ZMod 2) = 0
      exact ZMod.natCast_self 2
    simp [phaseCharacter, Finsupp.add_apply, configurationBit, hx, htwo]

/-- Flipping a distinct site leaves a one-site phase character unchanged. -/
theorem phaseCharacter_other_bit_add
    (i j : ℕ) (hij : i ≠ j) (x : CountablePauliConfiguration) :
    phaseCharacter i (configurationBit j + x) = phaseCharacter i x := by
  simp [phaseCharacter, Finsupp.add_apply, configurationBit,
    Finsupp.single_eq_of_ne hij]

/-- The phase character is a bounded `L∞` function for counting measure. -/
lemma phaseCharacter_memLp_top (i : ℕ) :
    MemLp (phaseCharacter i) ∞
      (Measure.count : Measure CountablePauliConfiguration) := by
  refine memLp_top_of_bound StronglyMeasurable.of_discrete.aestronglyMeasurable 1 ?_
  filter_upwards [] with x
  simp only [phaseCharacter]
  split_ifs <;> norm_num

/-- The local phase generator as multiplication on the countable `L²` space. -/
noncomputable def configurationPhase
    (i : ℕ) : CountablePauliHilbert →L[ℂ] CountablePauliHilbert :=
  (ContinuousLinearMap.mul ℂ ℂ).holderL
    (Measure.count : Measure CountablePauliConfiguration) ∞ 2 2
    ((phaseCharacter_memLp_top i).toLp (phaseCharacter i))

/-- The local phase generator in the concrete countable representation. -/
noncomputable def countablePauliZ (i : ℕ) :
    CountablePauliHilbert →L[ℂ] CountablePauliHilbert :=
  configurationPhase i

/-- The concrete multiplication formula for the phase generator. -/
theorem configurationPhase_apply_ae
    (i : ℕ) (f : CountablePauliHilbert) :
    configurationPhase i f =ᵐ[Measure.count]
      fun x => phaseCharacter i x * f x := by
  change (ContinuousLinearMap.mul ℂ ℂ).holder 2
    ((phaseCharacter_memLp_top i).toLp (phaseCharacter i)) f =ᵐ[Measure.count]
      fun x => phaseCharacter i x * f x
  filter_upwards [
    ContinuousLinearMap.coeFn_holder (r := 2) (ContinuousLinearMap.mul ℂ ℂ)
      ((phaseCharacter_memLp_top i).toLp (phaseCharacter i)) f,
    (phaseCharacter_memLp_top i).coeFn_toLp
  ] with x hmul hphase
  simpa [ContinuousLinearMap.mul_apply', hphase] using hmul

end FiniteFiber

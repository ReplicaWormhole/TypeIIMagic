import FiniteFiber.CountablePauliRepresentation

/-!
# Composition law for configuration shifts

This module records the composition law for the translation operators
`FiniteFiber.configurationShift` acting on the countable configuration `L²`
space.  Because `configurationShift g` sends `f` to the class of
`fun x => f (g + x)`, composing the shift by `g` with the shift by `h`
produces the shift by `g + h`, with the order recorded below.
-/

open MeasureTheory

namespace FiniteFiber

/-- Almost-everywhere identities may be pulled back along a translation, since
translations preserve the counting measure. -/
private theorem ae_comp_add_left
    (h : CountablePauliConfiguration) {u v : CountablePauliConfiguration → ℂ}
    (huv : u =ᵐ[Measure.count] v) :
    (fun x => u (h + x)) =ᵐ[Measure.count] fun x => v (h + x) :=
  (MeasureTheory.measurePreserving_add_left
      (Measure.count : Measure CountablePauliConfiguration)
      h).quasiMeasurePreserving.ae_eq_comp huv

/-- Translations compose: the shift by `g + h` equals the shift by `g`
followed by the shift by `h`. -/
theorem configurationShift_add (g h : CountablePauliConfiguration) :
    configurationShift (g + h) = (configurationShift h).comp (configurationShift g) := by
  ext f
  have hleft : configurationShift (g + h) f
      =ᵐ[Measure.count] fun x => (f : CountablePauliConfiguration → ℂ) (g + h + x) :=
    configurationShift_apply_ae (g + h) f
  have hright : (configurationShift h) (configurationShift g f)
      =ᵐ[Measure.count] fun x =>
        ((configurationShift g f : CountablePauliConfiguration → ℂ)) (h + x) :=
    configurationShift_apply_ae h (configurationShift g f)
  have hpull := ae_comp_add_left
    (u := (configurationShift g f : CountablePauliConfiguration → ℂ)) h
    (configurationShift_apply_ae g f)
  simp only [ContinuousLinearMap.comp_apply]
  refine hleft.trans (Filter.EventuallyEq.trans ?_ (hright.trans hpull).symm)
  filter_upwards with x
  rw [add_assoc]

end FiniteFiber

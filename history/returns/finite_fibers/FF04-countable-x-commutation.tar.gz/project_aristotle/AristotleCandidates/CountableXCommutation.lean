import FiniteFiber.CountablePauliRepresentation

/-!
# Commutation of the countable bit-flip translation generators

The countable bit-flip generators `countablePauliX` are translations by the
one-site binary configurations `configurationBit`.  Since translations compose
according to `configurationShift_add` and the configuration group is additive
abelian, any two such generators commute; no distinctness hypothesis is needed.
-/

namespace FiniteFiber

/-- The composition of two bit-flip translations is the translation by the sum
of the corresponding one-site configurations, in the pullback order. -/
private theorem countablePauliX_comp_eq_shift (i j : ℕ) :
    (countablePauliX i).comp (countablePauliX j) =
      configurationShift (configurationBit j + configurationBit i) := by
  simpa [countablePauliX] using
    (configurationShift_add (configurationBit j) (configurationBit i)).symm

/-- The countable bit-flip translation generators commute. -/
theorem countablePauliX_comm (i j : ℕ) :
    (countablePauliX i).comp (countablePauliX j) =
      (countablePauliX j).comp (countablePauliX i) := by
  rw [countablePauliX_comp_eq_shift, countablePauliX_comp_eq_shift,
    add_comm]

end FiniteFiber

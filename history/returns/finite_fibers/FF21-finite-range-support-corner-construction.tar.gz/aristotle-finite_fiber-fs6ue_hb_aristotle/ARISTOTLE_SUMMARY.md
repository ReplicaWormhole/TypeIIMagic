# Summary of changes for run e3674c81-d1cb-4fcb-b8fb-a16053e05d76
## FF21 — finite-range stabilizer support-corner construction

New file (the only file created): `FiniteFiber/FiniteRangeSupportCornerConstruction.lean` (~590 lines). `FiniteFiber.lean` (the library root import list) was updated so the new module — and the previously unimported FF20 module `FiniteFiber/ActualStabilizerSupportCorner.lean` — are part of the default build target. No other file was changed.

**Build command and result**
- `lake build FiniteFiber.FiniteRangeSupportCornerConstruction` → `Build completed successfully (3197 jobs)`
- `lake build` (full default target) → `Build completed successfully (3210 jobs)`
- No `sorry`, `admit`, `axiom`, `opaque`, `unsafe`, `native_decide` or `implemented_by` occurs in the file; `#print axioms` for the public results reports only `propext, Classical.choice, Quot.sound`.

**The data.** `FiniteRangeStabilizerSystem Site` bundles a surjective site enumeration (countable lattice), finite neighbourhood balls containing their centres (local finiteness), the manuscript's consistent commuting involutive full-Pauli generator system, and the finite-range condition that each generator is supported inside one ball.

**Facts proved from the finite-range definition alone (checked infrastructure, no analytic input):**
- `region`/`exhaustion`: a monotone exhaustion by finite regions covering the lattice, each region a finite union of range balls; every finite site set sits in a stage.
- `generator_supportedIn_region`: finite range puts each generator in the single stage `k+1` fixed by the index of its ball centre (the one-ball statement, no induction over supports).
- `localStabilizer n` (the stabilizers supported in region `n`, as a subgroup of the global stabilizer group): finiteness (`localStabilizerFintype`), monotonicity (`localStabilizer_mono`), exhaustion (`exists_mem_localStabilizer`, `iSup_localStabilizer = ⊤`), and membership of generators.
- `closure_localGenerators_le_regionStabilizer`: the inclusion of local-code consistency that finite range does give.
- `natAllZFiniteRangeSystem`: an explicit non-vacuity witness (the all-`Z` code on `ℕ`, range zero) with nontrivial finite local stabilizer groups.

**Facts proved given only the model-membership hypothesis `hM`:** in the supplied GNS model of a `QuasilocalStabilizerState`, the local code-space supports `supportProjection W n = π_ω(P_{Γ_n})` form a decreasing sequence of projections of `M`, each fixes `Ω` and is nonzero; their strong limit is *constructed* (the project's canonical `decreasingProjectionStrongLimit`, so no strong-limit premise is needed), is a projection of `M`, fixes `Ω`, and is therefore a **nonzero** candidate corner projection `q`. All bundled by `FiniteRangeSupportCornerData` / `FiniteRangeStabilizerSystem.supportCornerData`, and fed to FF20 in `finiteRange_supportCornerConclusion_of_gnsOrbit` and `finiteRange_central_witness_of_gnsOrbit`.

**Supplied premises (not derived here):** the quasilocal C*-completion `Q`; the global stabilizer state `W` extending the compatible finite local states; the von Neumann algebra `M` with `hM`; and `GNSOrbitConditions M q Ω` (regional/complementary commutation, dense product orbit, corner traciality of the compressed vector functional).

**Isolated additional condition.** `FiniteRangeStabilizerSystem.LocallyGenerated` states that the stabilizers supported in `region n` are exactly the products of generators supported in `region n`. It does not follow from finite range — a product of generators reaching outside a region can land back inside it, making the true local code space smaller than the one cut out by local generators — and no theorem here assumes it; it is required only if one wants to compute a local code space, its dimension or its density from the generator set. Nonzeroness of each stage is obtained instead from the fixed unit GNS vector.

No trace, fullness, type classification or no-type-III statement is claimed in this packet.

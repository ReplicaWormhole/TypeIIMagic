import FiniteFiber.CountablePauliRepresentation

/-!
# Initial/tail split of finitely supported binary configurations

For the configuration group `CountablePauliConfiguration = ℕ →₀ ZMod 2` this
file defines, for each cut `n : ℕ`, the additive restriction maps

* `configurationInitial n`, keeping the coordinates `i < n`, and
* `configurationTail n`, keeping the coordinates `n ≤ i`,

and proves that they decompose a configuration additively, vanish outside their
respective coordinate ranges, and fix the one-site generators `configurationBit`
on their range.

This is purely the additive decomposition of finitely supported binary
configurations: no tensor-product factorization, matrix realization, local
algebra, quasi-local closure, or state construction is claimed here.
-/

namespace FiniteFiber

/-- The initial restriction of a configuration to the coordinates `i < n`. -/
def configurationInitial (n : ℕ) :
    CountablePauliConfiguration →+ CountablePauliConfiguration :=
  Finsupp.filterAddHom fun i => i < n

/-- The tail restriction of a configuration to the coordinates `n ≤ i`. -/
def configurationTail (n : ℕ) :
    CountablePauliConfiguration →+ CountablePauliConfiguration :=
  Finsupp.filterAddHom fun i => n ≤ i

/-- The initial and tail restrictions recompose the original configuration. -/
theorem configurationInitial_add_configurationTail
    (n : ℕ) (x : CountablePauliConfiguration) :
    configurationInitial n x + configurationTail n x = x := by
  simpa only [configurationInitial, configurationTail, Finsupp.filterAddHom,
    AddMonoidHom.coe_mk, ZeroHom.coe_mk, Nat.not_lt] using
    Finsupp.filter_pos_add_filter_neg x (fun i => i < n)

/-- The initial restriction vanishes at coordinates beyond the cut. -/
theorem configurationInitial_apply_of_le
    (n : ℕ) (x : CountablePauliConfiguration) (i : ℕ) (h : n ≤ i) :
    configurationInitial n x i = 0 := by
  show (x.filter fun i => i < n) i = 0
  exact Finsupp.filter_apply_neg _ _ (Nat.not_lt.mpr h)

/-- The tail restriction vanishes at coordinates before the cut. -/
theorem configurationTail_apply_of_lt
    (n : ℕ) (x : CountablePauliConfiguration) (i : ℕ) (h : i < n) :
    configurationTail n x i = 0 := by
  show (x.filter fun i => n ≤ i) i = 0
  exact Finsupp.filter_apply_neg _ _ (Nat.not_le.mpr h)

/-- The initial restriction fixes a one-site generator before the cut. -/
theorem configurationInitial_bit_of_lt (n i : ℕ) (h : i < n) :
    configurationInitial n (configurationBit i) = configurationBit i := by
  show ((configurationBit i).filter fun j => j < n) = configurationBit i
  exact Finsupp.filter_single_of_pos _ h

/-- The tail restriction fixes a one-site generator at or beyond the cut. -/
theorem configurationTail_bit_of_le (n i : ℕ) (h : n ≤ i) :
    configurationTail n (configurationBit i) = configurationBit i := by
  show ((configurationBit i).filter fun j => n ≤ j) = configurationBit i
  exact Finsupp.filter_single_of_pos _ h

end FiniteFiber
